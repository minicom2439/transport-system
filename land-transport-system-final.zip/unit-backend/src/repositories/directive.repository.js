const knex = require('../db/knex');
const { applyFiltersAndSearch, applySort } = require('./list-query');
const CFG = {
  columns: { order_date: 'command_orders.order_date', instruction_category: 'command_orders.instruction_category', order_number: 'command_orders.order_number', title: 'command_orders.title', receipt_status: 'command_orders.receipt_status', execution_status: 'command_orders.execution_status', order_classification: 'command_orders.order_classification', unit: 'u.name', target_unit_id: 'command_orders.target_unit_id' },
  sortable: ['order_date', 'instruction_category', 'order_number', 'title', 'receipt_status', 'execution_status'],
  filterable: { instruction_category: ['eq'], receipt_status: ['eq'], execution_status: ['eq'], order_classification: ['eq'], target_unit_id: ['eq'], title: ['contains'] },
  searchable: ['command_orders.title', 'command_orders.short_title', 'command_orders.order_number', 'command_orders.body'],
  defaultSort: 'order_date',
};
async function list(params, scope) {
  let qb = knex('command_orders').leftJoin('units as u', 'u.id', 'command_orders.target_unit_id');
  if (typeof scope === 'function') qb = scope(qb);
  applyFiltersAndSearch(qb, params, CFG);
  const c = await qb.clone().clearSelect().clearOrder().count({ n: '*' }).first();
  qb.select('command_orders.*', 'u.name as unit_name'); applySort(qb, params, CFG); qb.limit(params.limit).offset(params.offset);
  const rows = await qb;
  const ids = rows.map((r) => r.id);
  const counts = {};
  if (ids.length) { (await knex('command_order_attachments').whereIn('command_order_id', ids).select('command_order_id').count({ n: '*' }).groupBy('command_order_id')).forEach((x) => { counts[x.command_order_id] = Number(x.n); }); }
  rows.forEach((r) => { r.attachment_count = counts[r.id] || 0; });
  return { data: rows, total: Number(c.n) };
}
async function detail(id, scope) {
  let qb = knex('command_orders').leftJoin('units as u', 'u.id', 'command_orders.target_unit_id').where('command_orders.id', id);
  if (typeof scope === 'function') qb = scope(qb);
  const row = await qb.select('command_orders.*', 'u.name as unit_name').first();
  if (!row) return null;
  row.attachments = await knex('command_order_attachments').where({ command_order_id: id }).select('id', 'file_name', 'file_path', 'file_size', 'content_type', 'uploaded_at');
  return row;
}
async function markReceived(id, userId) { await knex('command_orders').where({ id }).update({ receipt_status: 'received', received_at: knex.fn.now(), received_by: userId, updated_at: knex.fn.now() }); }
async function saveExecution(id, { execution_report, execution_status }, userId) {
  const patch = { execution_report: execution_report ?? null, execution_status, updated_at: knex.fn.now() };
  if (execution_status === 'submitted') { patch.execution_reported_at = knex.fn.now(); patch.execution_reported_by = userId; }
  await knex('command_orders').where({ id }).update(patch);
}
async function attachment(orderId, attId) { return knex('command_order_attachments').where({ id: attId, command_order_id: orderId }).first(); }
module.exports = { list, detail, markReceived, saveExecution, attachment };
