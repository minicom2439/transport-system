const knex = require('../db/knex');
const pad = (n) => String(n).padStart(2, '0');
const STAT = ['present', 'absent', 'leave', 'trip', 'sick'];
async function grid(year, month, scope) {
  const start = `${year}-${pad(month)}-01`;
  const dim = new Date(year, month, 0).getDate();
  const end = `${year}-${pad(month)}-${pad(dim)}`;
  let sq = knex('staff as s').leftJoin('staff_org as dep', 'dep.id', 's.department_id').where('s.is_active', 1);
  if (typeof scope === 'function') sq = scope(sq);
  const staff = await sq.select('s.id', 's.full_name', 's.staff_no', 'dep.name as department_name').orderBy('s.full_name');
  const ids = staff.map((s) => s.id);
  const recs = ids.length ? await knex('attendance_records').whereIn('staff_id', ids).andWhere('attend_date', '>=', start).andWhere('attend_date', '<=', end).select('staff_id', 'attend_date', 'status') : [];
  const byStaff = {};
  recs.forEach((r) => { const d = String(r.attend_date).slice(0, 10); (byStaff[r.staff_id] = byStaff[r.staff_id] || {})[d] = r.status; });
  return { year, month, daysInMonth: dim, staff: staff.map((s) => ({ ...s, records: byStaff[s.id] || {} })) };
}
async function upsert({ staff_id, attend_date, status, unit_id, userId }) {
  const existing = await knex('attendance_records').where({ staff_id, attend_date }).first();
  if (!status) { if (existing) await knex('attendance_records').where({ id: existing.id }).del(); return { deleted: true }; }
  if (existing) { await knex('attendance_records').where({ id: existing.id }).update({ status, updated_by: userId, updated_at: knex.fn.now() }); return { id: existing.id }; }
  const [id] = await knex('attendance_records').insert({ staff_id, attend_date, status, unit_id, created_by: userId });
  return { id };
}
async function summary(year, month, scope) {
  const g = await grid(year, month, scope);
  let totPresent = 0, totRecorded = 0;
  const staff = g.staff.map((s) => {
    const counts = { present: 0, absent: 0, leave: 0, trip: 0, sick: 0 };
    Object.values(s.records).forEach((v) => { if (counts[v] != null) counts[v]++; });
    const recorded = STAT.reduce((a, k) => a + counts[k], 0);
    const rate = recorded ? Math.round((counts.present / recorded) * 1000) / 10 : 0;
    totPresent += counts.present; totRecorded += recorded;
    return { id: s.id, full_name: s.full_name, department_name: s.department_name, ...counts, recorded, rate };
  });
  return { year, month, daysInMonth: g.daysInMonth, staff, overall_rate: totRecorded ? Math.round((totPresent / totRecorded) * 1000) / 10 : 0 };
}
module.exports = { grid, upsert, summary };
