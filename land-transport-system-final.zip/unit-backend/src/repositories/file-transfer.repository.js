const BaseRepository = require('./base.repository');
const knex = require('../db/knex');
const likeSearch = (qb, q) => qb.where((b) => b.where('f.file_name', 'like', `%${q}%`).orWhere('f.title', 'like', `%${q}%`).orWhere('f.report_title', 'like', `%${q}%`));
class R extends BaseRepository {
  constructor() { super('file_transfers', { softDelete: true, timestamps: true }); }
  async received(params, unitId) {
    let qb = knex('file_transfer_recipients as r').join('file_transfers as f', 'f.id', 'r.file_id').leftJoin('units as su', 'su.id', 'f.sender_unit_id').where('f.is_active', 1).andWhere('r.unit_id', unitId);
    if (params.q) qb = likeSearch(qb, params.q);
    const c = await qb.clone().clearSelect().clearOrder().count({ n: '*' }).first();
    const data = await qb.select('f.*', 'su.name as sender_unit_name', 'r.received_at', 'r.id as recipient_id').orderBy('f.sent_at', 'desc').limit(params.limit).offset(params.offset);
    return { data, total: Number(c.n) };
  }
  async sent(params, unitId) {
    let qb = knex('file_transfers as f').leftJoin('units as su', 'su.id', 'f.sender_unit_id').where('f.is_active', 1);
    if (unitId) qb = qb.andWhere('f.sender_unit_id', unitId);
    if (params.q) qb = likeSearch(qb, params.q);
    const c = await qb.clone().clearSelect().clearOrder().count({ n: '*' }).first();
    const rows = await qb.select('f.*', 'su.name as sender_unit_name').orderBy('f.sent_at', 'desc').limit(params.limit).offset(params.offset);
    for (const r of rows) {
      const recs = await knex('file_transfer_recipients as x').leftJoin('units as u', 'u.id', 'x.unit_id').where('x.file_id', r.id).select('u.name as unit_name', 'x.received_at');
      r.recipient_count = recs.length;
      r.not_received = recs.filter((x) => !x.received_at).map((x) => x.unit_name);
    }
    return { data: rows, total: Number(c.n) };
  }
  recipientsOf(fileId) { return knex('file_transfer_recipients as x').leftJoin('units as u', 'u.id', 'x.unit_id').where('x.file_id', fileId).select('x.*', 'u.name as unit_name'); }
  addRecipients(fileId, unitIds) { return knex('file_transfer_recipients').insert(unitIds.map((uid) => ({ file_id: fileId, unit_id: uid }))); }
  markReceived(fileId, unitId) { return knex('file_transfer_recipients').where({ file_id: fileId, unit_id: unitId }).whereNull('received_at').update({ received_at: knex.fn.now() }); }
  deleteRecipient(fileId, unitId) { return knex('file_transfer_recipients').where({ file_id: fileId, unit_id: unitId }).del(); }
}
module.exports = new R();
