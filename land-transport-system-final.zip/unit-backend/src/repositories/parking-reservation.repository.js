const BaseRepository = require('./base.repository');
const { applyFiltersAndSearch, applySort } = require('./list-query');
const CFG = {
  columns: { reserver_name: 'parking_reservations.reserver_name', vehicle_plate: 'parking_reservations.vehicle_plate', status: 'parking_reservations.status', reserved_from: 'parking_reservations.reserved_from', park: 'pk.name', park_id: 'parking_reservations.park_id', unit: 'u.name', unit_id: 'parking_reservations.unit_id' },
  sortable: ['reserver_name', 'status', 'park', 'reserved_from'],
  filterable: { status: ['eq'], park_id: ['eq'], unit_id: ['eq'], reserver_name: ['contains'] },
  searchable: ['parking_reservations.reserver_name', 'parking_reservations.vehicle_plate', 'parking_reservations.slot_no'],
  defaultSort: 'reserved_from',
};
class R extends BaseRepository {
  constructor() { super('parking_reservations', { softDelete: true, timestamps: true }); }
  base() { return this.qb().leftJoin('parks as pk', 'pk.id', 'parking_reservations.park_id').leftJoin('units as u', 'u.id', 'parking_reservations.unit_id').where('parking_reservations.is_active', 1); }
  async search(params, scope) {
    let qb = this.base(); if (typeof scope === 'function') qb = scope(qb);
    applyFiltersAndSearch(qb, params, CFG);
    const c = await qb.clone().clearSelect().clearOrder().count({ n: '*' }).first();
    qb.select('parking_reservations.*', 'pk.name as park_name', 'u.name as unit_name'); applySort(qb, params, CFG); qb.limit(params.limit).offset(params.offset);
    return { data: await qb, total: Number(c.n) };
  }
}
module.exports = new R();
