const BaseRepository = require('./base.repository');
const { applyFiltersAndSearch, applySort } = require('./list-query');
const CFG = {
  columns: { name: 'staff_org.name', code: 'staff_org.code', org_type: 'staff_org.org_type', unit: 'u.name', unit_id: 'staff_org.unit_id' },
  sortable: ['name', 'code', 'org_type', 'unit'],
  filterable: { name: ['contains'], org_type: ['eq'], unit_id: ['eq'] },
  searchable: ['staff_org.name', 'staff_org.code'],
  defaultSort: 'name',
};
class R extends BaseRepository {
  constructor() { super('staff_org', { softDelete: true, timestamps: true }); }
  base() { return this.qb().leftJoin('units as u', 'u.id', 'staff_org.unit_id').where('staff_org.is_active', 1); }
  async search(params, scope) {
    let qb = this.base(); if (typeof scope === 'function') qb = scope(qb);
    applyFiltersAndSearch(qb, params, CFG);
    const c = await qb.clone().clearSelect().clearOrder().count({ n: '*' }).first();
    qb.select('staff_org.*', 'u.name as unit_name'); applySort(qb, params, CFG); qb.limit(params.limit).offset(params.offset);
    return { data: await qb, total: Number(c.n) };
  }
}
module.exports = new R();
