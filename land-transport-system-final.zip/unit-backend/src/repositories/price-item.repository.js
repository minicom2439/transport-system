const BaseRepository = require('./base.repository');
const { applyFiltersAndSearch, applySort } = require('./list-query');
const CFG = {
  columns: { name: 'price_items.name', category: 'price_items.category', amount: 'price_items.amount' },
  sortable: ['name', 'category', 'amount'],
  filterable: { name: ['contains'], category: ['eq'] },
  searchable: ['price_items.name', 'price_items.description'],
  defaultSort: 'category',
};
class R extends BaseRepository {
  constructor() { super('price_items', { softDelete: true, timestamps: true }); }
  base() { return this.qb().where('price_items.is_active', 1); }
  async search(params, scope) {
    let qb = this.base(); if (typeof scope === 'function') qb = scope(qb);
    applyFiltersAndSearch(qb, params, CFG);
    const c = await qb.clone().clearSelect().clearOrder().count({ n: '*' }).first();
    qb.select('price_items.*'); applySort(qb, params, CFG); qb.limit(params.limit).offset(params.offset);
    return { data: await qb, total: Number(c.n) };
  }
}
module.exports = new R();
