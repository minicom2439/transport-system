const knex = require('../db/knex');
const pad = (n) => String(n).padStart(2, '0');
const PLAN_FIELDS = ['route_id', 'route_no', 'vehicle_status', 'operational_status', 'departure_point', 'arrival_point', 'distance_km', 'out_passengers', 'out_tons', 'in_passengers', 'in_tons', 'trips', 'transport_category', 'remarks', 'status'];

async function scopedVehicles(scope) {
  let vq = knex('vehicles as v').leftJoin('vehicle_types as vt', 'vt.id', 'v.vehicle_type_id').where('v.is_active', 1);
  if (typeof scope === 'function') vq = scope(vq);
  return vq.select('v.id as vehicle_id', 'v.plate_no', 'vt.name as vehicle_type', 'v.load_capacity', 'v.unit_id').orderBy('v.plate_no');
}
async function monthOverview(year, month, scope) {
  const start = `${year}-${pad(month)}-01`;
  const dim = new Date(year, month, 0).getDate();
  const end = `${year}-${pad(month)}-${pad(dim)}`;
  const vehicles = await scopedVehicles(scope);
  const ids = vehicles.map((v) => v.vehicle_id);
  const rows = ids.length ? await knex('transport_plans').whereIn('vehicle_id', ids).andWhere('is_active', 1).andWhere('plan_date', '>=', start).andWhere('plan_date', '<=', end).select('plan_date') : [];
  const map = {};
  rows.forEach((r) => { const d = String(r.plan_date).slice(0, 10); map[d] = (map[d] || 0) + 1; });
  const days = [];
  for (let d = 1; d <= dim; d += 1) { const date = `${year}-${pad(month)}-${pad(d)}`; days.push({ date, planned: map[date] || 0 }); }
  return { year, month, daysInMonth: dim, totalVehicles: vehicles.length, days };
}
async function dayGrid(date, scope) {
  const vehicles = await scopedVehicles(scope);
  const ids = vehicles.map((v) => v.vehicle_id);
  const plans = ids.length ? await knex('transport_plans as p').leftJoin('routes as r', 'r.id', 'p.route_id').whereIn('p.vehicle_id', ids).andWhere('p.plan_date', date).andWhere('p.is_active', 1).select('p.*', 'r.route_no') : [];
  const byVeh = {}; plans.forEach((p) => { byVeh[p.vehicle_id] = p; });
  return vehicles.map((v) => {
    const p = byVeh[v.vehicle_id] || {};
    const row = { ...v, plan_id: p.id || null };
    PLAN_FIELDS.forEach((k) => { row[k] = p[k] != null ? p[k] : null; });
    return row;
  });
}
async function upsert(plan) {
  const { created_by, ...rest } = plan;
  const ex = await knex('transport_plans').where({ vehicle_id: plan.vehicle_id, plan_date: plan.plan_date }).first();
  if (ex) { await knex('transport_plans').where({ id: ex.id }).update({ ...rest, updated_at: knex.fn.now() }); return { id: ex.id }; }
  const [id] = await knex('transport_plans').insert(plan); return { id };
}
module.exports = { monthOverview, dayGrid, upsert };
