const BaseRepository = require('./base.repository');
const { applyFiltersAndSearch, applySort } = require('./list-query');
const CFG = {
  columns: { name: 'place_names.name', code: 'place_names.code', category: 'place_names.category' },
  sortable: ['name', 'category', 'code'],
  filterable: { name: ['contains'], category: ['eq'] },
  searchable: ['place_names.name', 'place_names.code', 'place_names.description'],
  defaultSort: 'name',
};
class R extends BaseRepository {
  constructor() { super('place_names', { softDelete: true, timestamps: true }); }
  base() { return this.qb().where('place_names.is_active', 1); }
  async search(params, scope) {
    let qb = this.base(); if (typeof scope === 'function') qb = scope(qb);
    applyFiltersAndSearch(qb, params, CFG);
    const c = await qb.clone().clearSelect().clearOrder().count({ n: '*' }).first();
    qb.select('place_names.*'); applySort(qb, params, CFG); qb.limit(params.limit).offset(params.offset);
    return { data: await qb, total: Number(c.n) };
  }
}
module.exports = new R();
