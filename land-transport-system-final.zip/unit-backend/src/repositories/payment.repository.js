const BaseRepository = require('./base.repository');
const { applyFiltersAndSearch, applySort } = require('./list-query');
const CFG = {
  columns: { payment_date: 'payments.payment_date', category: 'payments.category', amount: 'payments.amount', reference_no: 'payments.reference_no', status: 'payments.status', unit: 'u.name', unit_id: 'payments.unit_id' },
  sortable: ['payment_date', 'category', 'amount', 'unit', 'status'],
  filterable: { category: ['eq'], status: ['eq'], unit_id: ['eq'], reference_no: ['contains'] },
  searchable: ['payments.description', 'payments.reference_no', 'u.name'],
  defaultSort: 'payment_date',
};
class R extends BaseRepository {
  constructor() { super('payments', { softDelete: true, timestamps: true }); }
  base() { return this.qb().leftJoin('units as u', 'u.id', 'payments.unit_id').where('payments.is_active', 1); }
  async search(params, scope) {
    let qb = this.base(); if (typeof scope === 'function') qb = scope(qb);
    applyFiltersAndSearch(qb, params, CFG);
    const c = await qb.clone().clearSelect().clearOrder().count({ n: '*' }).first();
    qb.select('payments.*', 'u.name as unit_name'); applySort(qb, params, CFG); qb.limit(params.limit).offset(params.offset);
    return { data: await qb, total: Number(c.n) };
  }
}
module.exports = new R();
