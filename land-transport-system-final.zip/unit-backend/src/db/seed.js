// src/db/seed.js
// Seeds the minimum data needed to log in and exercise the permission model:
// the 7 actions, approval statuses, the 5 top-level system sections (+ a few
// screen nodes used by the sample routes), an Administrator role wired to those
// screens, and one super-admin user.
const knex = require('./knex');
const { hashPassword } = require('../services/auth.service');

async function seed() {
  const SYS = 'unit';  // system_code stamped on this app's nav nodes
  // --- actions -----------------------------------------------------------
  const actions = ['view', 'add', 'edit', 'remove', 'export', 'approve', 'reject'];
  for (const code of actions) {
    const exists = await knex('actions').where({ code }).first();
    if (!exists) await knex('actions').insert({ name: code, code });
  }

  // --- approval statuses --------------------------------------------------
  const statuses = ['draft', 'submitted', 'approved', 'rejected', 'cancelled'];
  for (const code of statuses) {
    const exists = await knex('approval_statuses').where({ code }).first();
    if (!exists) await knex('approval_statuses').insert({ name: code, code });
  }

  // --- sample regions (neutral placeholders) -----------------------------
  // Province level (level 1) with a city (level 2) beneath each. Replace with
  // your real administrative geography.
  async function ensureRegion(name, level, parentId = null) {
    let row = await knex('regions').where({ name }).first();
    if (!row) {
      const [id] = await knex('regions').insert({ name, level, parent_id: parentId });
      row = { id };
    }
    return row.id;
  }
  const regionAId = await ensureRegion('Region A', 1);
  await ensureRegion('City A', 2, regionAId);
  const regionBId = await ensureRegion('Region B', 1);
  await ensureRegion('City B', 2, regionBId);

  // --- system sections (5 roots) -----------------------------------------
  const roots = [
    { code: 'operations_mgmt', name: 'Operations Management', node_type: 1, sort_order: 0 },
    { code: 'land_ops', name: 'Land transport operations system', node_type: 1, sort_order: 1 },
    { code: 'vehicle_admin', name: 'Vehicle Transport Administration System', node_type: 1, sort_order: 2 },
    { code: 'planning_prod', name: 'Planning and Production Department', node_type: 1, sort_order: 3 },
    { code: 'sci_tech', name: 'Science and Technology Department', node_type: 1, sort_order: 4 },
    { code: 'effort_manage', name: 'Effort Manage Department', node_type: 1, sort_order: 5 },
    { code: 'equipment_reg', name: 'Equipment Register Department', node_type: 1, sort_order: 6 },
    { code: 'financial', name: 'Financial Department', node_type: 1, sort_order: 7 },
    { code: 'first_business', name: 'First Business Comprehensive Department', node_type: 1, sort_order: 8 },
    { code: 'comprehensive', name: 'Comprehensive Department', node_type: 1, sort_order: 9 },
    { code: 'other_work', name: 'Other Work Systems', node_type: 1, sort_order: 10 },
    { code: 'integration', name: 'Integration Management', node_type: 1, sort_order: 11 },
    { code: 'info_service', name: 'Information Service', node_type: 1, sort_order: 12 },
    { code: 'administration', name: 'Administration', node_type: 1, sort_order: 20 },
  ];
  const rootIds = {};
  for (const r of roots) {
    let row = await knex('system_sections').where({ code: r.code, system_code: SYS }).first();
    if (!row) {
      const [id] = await knex('system_sections').insert({ ...r, system_code: SYS });
      row = { id };
    } else {
      await knex('system_sections').where({ id: row.id }).update({ name: r.name, sort_order: r.sort_order, node_type: 1 });
    }
    rootIds[r.code] = row.id;
  }

  // intermediate GROUP nodes (node_type 2) — parents may be a root or another group.
  // Ordered so a parent group is created before its child group.
  const groups = [
    { code: 'ops_system', name: 'System Management', parent: 'operations_mgmt' },
    { code: 'ops_employee', name: 'Employee Management', parent: 'operations_mgmt' },
    { code: 'ops_transport', name: 'Transport Command', parent: 'operations_mgmt' },
    { code: 'ops_payment', name: 'Payment Management', parent: 'operations_mgmt' },
    { code: 'ops_other', name: 'Other Work Systems', parent: 'operations_mgmt' },
    { code: 'admin_duties', name: 'Administrator Duties', parent: 'operations_mgmt' },
    { code: 'ops_data', name: 'Data Transfer', parent: 'operations_mgmt' },
    { code: 'lo_business', name: 'Business Report', parent: 'land_ops' },
    { code: 'lo_review', name: 'Traveler Pass Review', parent: 'land_ops' },
    { code: 'lo_park', name: 'Parking Lot Information', parent: 'lo_review' },
    { code: 'lo_transfer', name: 'Freight Transfer', parent: 'land_ops' },
    { code: 'lo_stats', name: 'Comprehensive Statistics', parent: 'land_ops' },
    { code: 'lo_finance', name: 'Finance', parent: 'land_ops' },
    { code: 'lo_command', name: 'Transport Command', parent: 'land_ops' },
    { code: 'va_certs', name: 'Route Certificate Management', parent: 'vehicle_admin' },
    { code: 'va_command', name: 'Transport Command', parent: 'vehicle_admin' },
    { code: 'is_notice', name: 'Public Notice', parent: 'info_service' },
    { code: 'is_service', name: 'Service Data', parent: 'info_service' },
    { code: 'ig_traveler', name: 'Traveler Transport', parent: 'integration' },
    { code: 'ig_thing', name: 'Thing Transport', parent: 'integration' },
    { code: 'ig_office', name: 'Transportation Office', parent: 'integration' },
  ];
  const nodeIds = { ...rootIds };
  for (const g of groups) {
    let row = await knex('system_sections').where({ code: g.code, system_code: SYS }).first();
    if (!row) {
      const [id] = await knex('system_sections').insert({ code: g.code, name: g.name, node_type: 2, parent_id: nodeIds[g.parent], sort_order: 1, system_code: SYS });
      row = { id };
    }
    nodeIds[g.code] = row.id;
  }

  // a few screen nodes the sample routes reference
  const screens = [
    // Operations Management (unit system core)
    { code: 'ops_program', name: 'Program Registration Management', parent: 'ops_system' },
    { code: 'ops_files', name: 'File Management', parent: 'ops_data' },
    { code: 'ops_history', name: 'View History', parent: 'ops_data' },
    { code: 'ops_connection', name: 'Connection Status', parent: 'ops_data' },
    { code: 'ops_emp_org', name: 'Department/Job Management', parent: 'ops_employee' },
    { code: 'ops_emp_attendance', name: 'Daily Attendance Report', parent: 'ops_employee' },
    { code: 'ops_emp_summary', name: 'Monthly Summary', parent: 'ops_employee' },
    { code: 'ops_transport_planning', name: 'Daily Planning Report', parent: 'ops_transport' },
    { code: 'ops_transport_status', name: 'Daily Report Status', parent: 'ops_transport' },
    { code: 'ops_directive', name: 'Transport Command — Directive', parent: 'ops_transport' },
    { code: 'ops_pay_price', name: 'Price Information', parent: 'ops_payment' },
    { code: 'ops_pay_history', name: 'Payment History', parent: 'ops_payment' },
    { code: 'ops_reservation', name: 'Reservation Status', parent: 'operations_mgmt' },
    { code: 'ow_rr_report', name: 'Route Review — Business Report', parent: 'ops_other' },
    { code: 'ow_rr_parks', name: 'Route Review — Parking Lot Data', parent: 'ops_other' },
    { code: 'ow_rr_monthly', name: 'Route Review — Monthly Review Data', parent: 'ops_other' },
    { code: 'ow_water_bureau', name: 'Water Transport Bureau — Business Report', parent: 'ops_other' },
    { code: 'admin_places', name: 'Place Name Management', parent: 'admin_duties' },
    { code: 'admin_gps', name: 'GPS-Communications View', parent: 'admin_duties' },
    { code: 'admin_news', name: 'Notices (Ssangmai-dong)', parent: 'admin_duties' },
    // Land transport operations — nested per the source document
    { code: 'land_ops_conditions', name: 'Operating Conditions', parent: 'land_ops' },
    { code: 'land_ops_units', name: 'Unit Name Management', parent: 'land_ops' },
    { code: 'land_ops_reports', name: 'Business Reports', parent: 'lo_business' },
    { code: 'land_ops_routes', name: 'Routes', parent: 'lo_review' },
    { code: 'land_ops_schedules', name: 'Bus Schedules', parent: 'lo_park' },
    { code: 'land_ops_park_vehicles', name: 'Vehicle Information (per Parking Lot)', parent: 'lo_park' },
    { code: 'land_ops_warehouses', name: 'Warehouses', parent: 'lo_transfer' },
    { code: 'land_ops_transfer_sections', name: 'Transfer Sections', parent: 'lo_transfer' },
    { code: 'land_ops_orders', name: 'Freight Transport Orders', parent: 'lo_transfer' },
    { code: 'land_ops_unit_stats', name: 'Statistics per Unit', parent: 'lo_stats' },
    { code: 'land_ops_ultimate_stats', name: 'Ultimate Statistics', parent: 'lo_stats' },
    { code: 'land_ops_finance', name: 'Finance Management', parent: 'lo_finance' },
    { code: 'land_ops_licenses', name: 'License Management', parent: 'lo_finance' },
    { code: 'land_ops_indicators', name: 'Transport Ledger', parent: 'lo_command' },
    { code: 'land_ops_online', name: 'Network Connection Status', parent: 'lo_command' },
    { code: 'land_ops_route_certs', name: 'Route Certificates', parent: 'va_certs' },
    // Vehicle Transport Administration
    { code: 'vehicle_admin_register', name: 'Vehicle Registration', parent: 'vehicle_admin' },
    { code: 'other_staff', name: 'Employee Registration', parent: 'ops_employee' },
    { code: 'vehicle_admin_basic_data', name: 'Basic Data', parent: 'vehicle_admin' },
    { code: 'vehicle_admin_invoices', name: 'Invoice Management', parent: 'vehicle_admin' },
    { code: 'vehicle_admin_accidents', name: 'Accident Notification', parent: 'vehicle_admin' },
    { code: 'vehicle_admin_parks', name: 'Parking Lots', parent: 'vehicle_admin' },
    { code: 'vehicle_admin_command_orders', name: 'Command Orders', parent: 'va_command' },
    // Science and Technology Department
    { code: 'sci_gps', name: 'GPS Registration', parent: 'sci_tech' },
    { code: 'sci_location', name: 'Search Vehicle Location', parent: 'sci_tech' },
    // Planning and Production Department
    { code: 'pp_monthly', name: 'Monthly Reports', parent: 'planning_prod' },
    { code: 'pp_effort', name: 'Effort Plans', parent: 'planning_prod' },
    { code: 'pp_electricity', name: 'Power Daily Report', parent: 'planning_prod' },
    // Equipment Register Department
    { code: 'eqr_equipment', name: 'Equipment', parent: 'equipment_reg' },
    { code: 'eqr_inspections', name: 'Equipment Inspections', parent: 'equipment_reg' },
    { code: 'eqr_no_accident', name: 'Accident-Free Registration', parent: 'equipment_reg' },
    // Comprehensive Department
    { code: 'cmp_daily_reports', name: 'Business Daily Reports', parent: 'comprehensive' },
    { code: 'cmp_weekly', name: 'Weekly Work Schedule', parent: 'comprehensive' },
    { code: 'cmp_defense', name: 'Security Guard Duty', parent: 'comprehensive' },
    { code: 'ow_water', name: 'Water Transport Daily Report', parent: 'other_work' },
    { code: 'ow_revenue', name: 'Revenue Examination Daily Report', parent: 'other_work' },
    { code: 'em_daily', name: 'Business Daily Report', parent: 'effort_manage' },
    { code: 'fbc_daily', name: 'Business Daily Report', parent: 'first_business' },
    { code: 'info_search', name: 'Integrated Search', parent: 'info_service' },
    { code: 'fin_stats', name: 'Finance Statistics', parent: 'financial' },
    // Information Service
    { code: 'info_notices', name: 'Notices', parent: 'is_notice' },
    { code: 'info_programs', name: 'Relevant Programs', parent: 'is_service' },
    { code: 'info_faqs', name: 'FAQ', parent: 'is_service' },
    { code: 'info_submissions', name: 'Data Submissions', parent: 'is_service' },
    { code: 'info_feedback', name: 'Feedback Box', parent: 'is_service' },
    // Other systems
    // Integration Management (HQ read-only oversight via shared DB)
    { code: 'integration_traveler_stats', name: 'Traveler Transport — View Data', parent: 'ig_traveler' },
    { code: 'integration_thing_stats', name: 'Thing Transport — View Data', parent: 'ig_thing' },
    { code: 'integration_einvoice', name: 'Electronic Invoice', parent: 'integration' },
    { code: 'integration_parks', name: 'Park', parent: 'integration' },
    { code: 'integration_accidents', name: 'Accident Notification', parent: 'ig_office' },
    { code: 'integration_locations', name: 'Vehicle Location Data', parent: 'ig_office' },
    { code: 'admin_users', name: 'Users', parent: 'administration' },
    { code: 'admin_roles', name: 'Roles & Permissions', parent: 'administration' },
    { code: 'admin_requests', name: 'Account Requests', parent: 'administration' },
  ];
  const screenIds = {};
  for (const s of screens) {
    let row = await knex('system_sections').where({ code: s.code, system_code: SYS }).first();
    if (!row) {
      const [id] = await knex('system_sections').insert({
        code: s.code, name: s.name, node_type: 4, parent_id: nodeIds[s.parent], sort_order: 1, system_code: SYS,
      });
      row = { id };
    } else if (row.parent_id !== nodeIds[s.parent]) {
      // keep hierarchy in sync if a node was reparented in this revision
      await knex('system_sections').where({ id: row.id }).update({ name: s.name, parent_id: nodeIds[s.parent] });
    }
    screenIds[s.code] = row.id;
  }

  // --- Administrator role with full rights on those screens --------------
  let adminRole = await knex('roles').where({ code: 'administrator' }).first();
  if (!adminRole) {
    const [id] = await knex('roles').insert({ name: 'Administrator', code: 'administrator' });
    adminRole = { id };
  }
  const actionRows = await knex('actions').select('id', 'code');
  for (const sCode of Object.keys(screenIds)) {
    for (const a of actionRows) {
      const exists = await knex('role_permissions')
        .where({ role_id: adminRole.id, section_id: screenIds[sCode], action_id: a.id }).first();
      if (!exists) {
        await knex('role_permissions').insert({
          role_id: adminRole.id, section_id: screenIds[sCode], action_id: a.id,
        });
      }
    }
  }

  // --- super admin user --------------------------------------------------
  let admin = await knex('users').where({ username: 'admin' }).first();
  if (!admin) {
    const password_hash = await hashPassword('admin123'); // CHANGE in real use
    const [id] = await knex('users').insert({
      username: 'admin', password_hash, full_name: 'System Administrator', is_super_admin: 1,
    });
    admin = { id };
    await knex('user_roles').insert({ user_id: id, role_id: adminRole.id });
  }

  // --- test users with varied roles -------------------------------------
  // Lets you see the nav rail and action buttons change per role, and watch
  // data-scope filtering. All test users share the password "test123".
  const actionId = Object.fromEntries(actionRows.map((a) => [a.code, a.id]));

  async function ensureRole(code, name) {
    let row = await knex('roles').where({ code }).first();
    if (!row) { const [id] = await knex('roles').insert({ name, code }); row = { id }; }
    return row.id;
  }
  async function grant(roleId, sectionCode, actionCodes) {
    const sectionId = screenIds[sectionCode];
    for (const ac of actionCodes) {
      const exists = await knex('role_permissions')
        .where({ role_id: roleId, section_id: sectionId, action_id: actionId[ac] }).first();
      if (!exists) {
        await knex('role_permissions').insert({ role_id: roleId, section_id: sectionId, action_id: actionId[ac] });
      }
    }
  }
  async function ensureUser(username, fullName, roleId, scopes = []) {
    let u = await knex('users').where({ username }).first();
    if (!u) {
      const ph = await hashPassword('test123');
      const unitScope = scopes.find((sc) => sc.type === 1);
      const [id] = await knex('users').insert({ username, password_hash: ph, full_name: fullName, is_super_admin: 0, unit_id: unitScope ? unitScope.id : null });
      u = { id };
      await knex('user_roles').insert({ user_id: id, role_id: roleId });
      for (const s of scopes) {
        await knex('user_data_scopes').insert({ user_id: id, scope_type: s.type, scope_id: s.id });
      }
    }
    return u.id;
  }

  const rOps = await ensureRole('ops_manager', 'Operations Manager');
  await grant(rOps, 'land_ops_units', ['view', 'add', 'edit', 'remove', 'export']);
  await grant(rOps, 'land_ops_routes', ['view', 'add', 'edit', 'remove', 'export']);
  await grant(rOps, 'land_ops_conditions', ['view', 'add', 'edit']);
  await grant(rOps, 'cmp_daily_reports', ['view', 'add', 'edit']);
  await grant(rOps, 'land_ops_reports', ['view', 'add', 'edit']);
  await grant(rOps, 'pp_monthly', ['view', 'add', 'edit']);
  await grant(rOps, 'pp_effort', ['view', 'add', 'edit']);
  await grant(rOps, 'info_submissions', ['view', 'add', 'edit']);

  const rVeh = await ensureRole('vehicle_clerk', 'Vehicle Clerk');
  await grant(rVeh, 'vehicle_admin_register', ['view', 'add']);

  const rAnalyst = await ensureRole('analyst', 'Transport Analyst');
  await grant(rAnalyst, 'integration_traveler_stats', ['view']);

  const rUnitsView = await ensureRole('units_viewer', 'Units Viewer');
  await grant(rUnitsView, 'land_ops_units', ['view']);

  const rMulti = await ensureRole('multi_role', 'Multi-System User');
  await grant(rMulti, 'land_ops_units', ['view', 'add', 'edit']);
  await grant(rMulti, 'vehicle_admin_register', ['view', 'add']);

  await grant(rOps, 'ops_files', ['view', 'add', 'edit', 'remove']);
  await grant(rOps, 'ops_history', ['view']);
  await grant(rOps, 'ops_connection', ['view']);

  // ---- Unit-type role profiles: each unit type sees only its relevant screens ----
  const profileRoleIds = {};
  const UNIT_PROFILES = {
    unit_mgmt_bureau:       { name: 'Unit — Management Bureau', ops: ['land_ops_reports', 'land_ops_conditions', 'vehicle_admin_register', 'land_ops_park_vehicles', 'other_staff', 'ops_emp_org', 'ops_emp_attendance', 'ops_emp_summary', 'land_ops_route_certs', 'vehicle_admin_invoices', 'vehicle_admin_command_orders', 'ops_transport_planning', 'ops_transport_status', 'cmp_daily_reports', 'pp_electricity', 'eqr_inspections', 'eqr_equipment', 'eqr_no_accident', 'land_ops_finance', 'vehicle_admin_accidents', 'land_ops_unit_stats'] },
    unit_provincial_bureau: { name: 'Unit — Provincial Transport Bureau', ops: ['cmp_daily_reports', 'land_ops_conditions', 'vehicle_admin_register', 'land_ops_route_certs', 'land_ops_finance', 'vehicle_admin_accidents', 'vehicle_admin_command_orders', 'ops_transport_planning', 'ops_transport_status'] },
    unit_supervision:       { name: 'Unit — Supervision', ops: ['land_ops_reports', 'vehicle_admin_basic_data', 'other_staff', 'ops_emp_org', 'ops_emp_attendance', 'ops_emp_summary', 'vehicle_admin_parks', 'land_ops_unit_stats', 'land_ops_conditions', 'cmp_daily_reports', 'land_ops_route_certs', 'land_ops_park_vehicles'] },
    unit_parking_lot:       { name: 'Unit — Parking Lot', ops: ['land_ops_reports', 'land_ops_conditions', 'vehicle_admin_parks', 'land_ops_finance'] },
    unit_transport_station: { name: 'Unit — Transportation Station', ops: ['land_ops_reports', 'land_ops_conditions', 'other_staff', 'ops_emp_org', 'ops_emp_attendance', 'ops_emp_summary', 'land_ops_route_certs', 'vehicle_admin_invoices', 'vehicle_admin_register', 'land_ops_warehouses', 'land_ops_orders', 'vehicle_admin_command_orders', 'ops_transport_planning', 'ops_transport_status', 'pp_electricity', 'eqr_inspections'] },
    unit_operating:         { name: 'Unit — Operating Unit', ops: ['land_ops_reports', 'land_ops_conditions', 'vehicle_admin_register', 'land_ops_route_certs', 'vehicle_admin_invoices', 'vehicle_admin_accidents', 'vehicle_admin_command_orders', 'ops_transport_planning', 'ops_transport_status', 'cmp_daily_reports'] },
    unit_city_county:       { name: 'Unit — City/County Transport Office', ops: ['land_ops_reports', 'land_ops_conditions', 'other_staff', 'ops_emp_org', 'ops_emp_attendance', 'ops_emp_summary', 'land_ops_warehouses', 'vehicle_admin_register', 'land_ops_route_certs', 'vehicle_admin_invoices', 'vehicle_admin_command_orders', 'ops_transport_planning', 'ops_transport_status', 'vehicle_admin_accidents', 'land_ops_orders'] },
    unit_warehouse:         { name: 'Unit — Warehouse Management', ops: ['vehicle_admin_basic_data', 'land_ops_warehouses'] },
    unit_city_county_dept:  { name: 'Unit — City/County Transport Dept', ops: ['land_ops_reports', 'land_ops_conditions', 'vehicle_admin_register', 'land_ops_route_certs', 'vehicle_admin_parks', 'vehicle_admin_accidents', 'vehicle_admin_command_orders', 'ops_transport_planning', 'ops_transport_status'] },
    unit_other_supervisory: { name: 'Unit — Other Supervisory Units', ops: ['land_ops_reports', 'vehicle_admin_register', 'pp_effort', 'land_ops_route_certs', 'sci_location', 'land_ops_unit_stats'] },
  };
  const VIEW_ONLY = new Set(['land_ops_unit_stats', 'sci_location', 'ops_emp_summary', 'ops_transport_status']);
  for (const [code, p] of Object.entries(UNIT_PROFILES)) {
    const rid = await ensureRole(code, p.name);
    await grant(rid, 'ops_files', ['view', 'add', 'edit', 'remove']); // every unit can exchange files
    await grant(rid, 'ops_connection', ['view']);
    for (const sec of p.ops) await grant(rid, sec, VIEW_ONLY.has(sec) ? ['view'] : ['view', 'add', 'edit']);
    profileRoleIds[code] = rid;
  }
  // Payment Management to the unit types that include it (Mgmt Bureau, Provincial Bureau, Parking Lot)
  for (const code of ['unit_mgmt_bureau', 'unit_provincial_bureau', 'unit_parking_lot']) {
    await grant(profileRoleIds[code], 'ops_pay_price', ['view']);
    await grant(profileRoleIds[code], 'ops_pay_history', ['view', 'add', 'edit']);
  }
  await grant(profileRoleIds.unit_parking_lot, 'ops_reservation', ['view', 'add', 'edit', 'remove']);
  for (const code of ['unit_mgmt_bureau', 'unit_provincial_bureau', 'unit_supervision', 'unit_other_supervisory']) {
    await grant(profileRoleIds[code], 'ow_rr_report', ['view']);
    await grant(profileRoleIds[code], 'ow_rr_parks', ['view']);
    await grant(profileRoleIds[code], 'ow_rr_monthly', ['view']);
    await grant(profileRoleIds[code], 'ow_water_bureau', ['view']);
  }
  await grant(profileRoleIds.unit_mgmt_bureau, 'admin_places', ['view', 'add', 'edit', 'remove']);
  await grant(profileRoleIds.unit_mgmt_bureau, 'admin_news', ['view', 'add', 'edit', 'remove']);
  await grant(profileRoleIds.unit_mgmt_bureau, 'admin_gps', ['view']);
  for (const code of ['unit_supervision', 'unit_other_supervisory']) {
    await grant(profileRoleIds[code], 'admin_places', ['view']);
    await grant(profileRoleIds[code], 'admin_gps', ['view']);
    await grant(profileRoleIds[code], 'admin_news', ['view']);
  }
  // Integrated Management — oversight analytics for management/supervisory unit types
  const INTEG = ['integration_traveler_stats', 'integration_thing_stats', 'integration_einvoice', 'integration_parks', 'integration_accidents', 'integration_locations'];
  for (const code of ['unit_mgmt_bureau', 'unit_provincial_bureau', 'unit_supervision', 'unit_other_supervisory']) {
    for (const sec of INTEG) await grant(profileRoleIds[code], sec, ['view']);
  }
  // Information Services — available to every unit type
  const INFO_VIEW = ['info_search', 'info_notices', 'info_programs', 'info_faqs'];
  const INFO_RW = ['info_submissions', 'info_feedback'];
  for (const code of Object.keys(profileRoleIds)) {
    for (const sec of INFO_VIEW) await grant(profileRoleIds[code], sec, ['view']);
    for (const sec of INFO_RW) await grant(profileRoleIds[code], sec, ['view', 'add']);
  }
  // Write Notices — management profiles may post notices
  for (const code of ['unit_mgmt_bureau', 'unit_provincial_bureau']) {
    await grant(profileRoleIds[code], 'info_notices', ['view', 'add', 'edit']);
  }
  // Transport Command — Directive (unit-facing receive/respond) for command-order unit types
  for (const code of ['unit_mgmt_bureau', 'unit_provincial_bureau', 'unit_transport_station', 'unit_operating', 'unit_city_county', 'unit_city_county_dept']) {
    await grant(profileRoleIds[code], 'ops_directive', ['view', 'edit']);
  }
  await ensureUser('ops_manager', 'Ops Manager', rOps);
  await ensureUser('vehicle_clerk', 'Vehicle Clerk', rVeh);
  await ensureUser('analyst', 'Transport Analyst', rAnalyst);
  await ensureUser('region_a_viewer', 'Region A Viewer', rUnitsView, [{ type: 2, id: regionAId }]);
  await ensureUser('multi', 'Multi-System User', rMulti);

  // --- sample operational data (so the screens show rows) ----------------
  const haveUnits = await knex('units').first();
  if (!haveUnits) {
    const regionA = await knex('regions').orderBy('id').first();
    const regions = await knex('regions').orderBy('id').limit(2);
    const rA = regions[0] ? regions[0].id : null;
    const rB = regions[1] ? regions[1].id : rA;
    const [uA] = await knex('units').insert({ name: 'Unit Alpha', code: 'UA-1', region_id: rA });
    const [uB] = await knex('units').insert({ name: 'Unit Beta', code: 'UB-1', region_id: rB });
    // create a workflow row at a target status (draft/submitted/approved), optionally with a command
    const draftStatus = await knex('approval_statuses').where({ code: 'draft' }).first();
    const adminForSeed = await knex('users').where({ username: 'admin' }).first();
    // Unit system: attach users to units, seed inter-unit file transfers + signup history
    await knex('users').where({ username: 'admin' }).update({ unit_id: uB, position: 'System Administrator', mobile_phone: '010-0000-0000' });
    await knex('users').where({ username: 'ops_manager' }).update({ unit_id: uA, position: 'Operations Manager' });
    // a couple of extra unit users with varied signup dates (for View History)
    const uhash = adminForSeed.password_hash;
    await knex('users').insert([
      { username: 'alpha_clerk', full_name: 'Alpha Clerk', password_hash: uhash, unit_id: uA, position: 'Clerk', created_at: '2026-06-02 09:10:00' },
      { username: 'beta_clerk', full_name: 'Beta Clerk', password_hash: uhash, unit_id: uB, position: 'Clerk', created_at: '2026-06-02 14:20:00' },
      { username: 'alpha_dispatch', full_name: 'Alpha Dispatch', password_hash: uhash, unit_id: uA, position: 'Dispatcher', created_at: '2026-06-09 11:00:00' },
    ]).catch(() => {});
    // file transfers: Unit Alpha sends two files; Unit Beta is a recipient
    const bufA = Buffer.from('May operations report — sample file content stored in the shared database.');
    const [blobAId] = await knex('file_blobs').insert({ byte_size: bufA.length, content_type: 'application/pdf', content: bufA, created_by: adminForSeed.id });
    const [f1] = await knex('file_transfers').insert({ sender_unit_id: uA, title: 'May operations report', report_title: 'Monthly operations', file_name: 'may-ops.pdf', file_size: bufA.length, content_type: 'application/pdf', blob_id: blobAId, sent_at: '2026-06-03 10:00:00', created_by: adminForSeed.id });
    await knex('file_transfer_recipients').insert([{ file_id: f1, unit_id: uB, received_at: '2026-06-03 12:30:00' }]);
    const bufB = Buffer.from('Vehicle roster update — sample spreadsheet content stored in the shared database.');
    const [blobBId] = await knex('file_blobs').insert({ byte_size: bufB.length, content_type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', content: bufB, created_by: adminForSeed.id });
    const [f2] = await knex('file_transfers').insert({ sender_unit_id: uA, title: 'Vehicle roster update', report_title: 'Roster', file_name: 'roster.xlsx', file_size: bufB.length, content_type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', blob_id: blobBId, sent_at: '2026-06-15 09:00:00', created_by: adminForSeed.id });
    await knex('file_transfer_recipients').insert([{ file_id: f2, unit_id: uB }]);  // not yet received
    // sample unit-type users (scoped to their unit) for testing the profiles
    await ensureUser('park_user', 'Parking Lot User', profileRoleIds.unit_parking_lot, [{ type: 1, id: uA }]);
    await ensureUser('station_user', 'Transport Station User', profileRoleIds.unit_transport_station, [{ type: 1, id: uB }]);
    await ensureUser('review_user', 'Route Review User', profileRoleIds.unit_supervision, [{ type: 1, id: uA }]);
    // Employee Management sample data (departments/jobs, employees, attendance)
    const [depOps] = await knex('staff_org').insert({ unit_id: uA, org_type: 1, name: 'Operations Dept', code: 'OPS' });
    const [depMaint] = await knex('staff_org').insert({ unit_id: uA, org_type: 1, name: 'Maintenance Dept', code: 'MNT' });
    const [jobDriver] = await knex('staff_org').insert({ unit_id: uA, org_type: 2, name: 'Driver', code: 'DRV' });
    const [jobClerk] = await knex('staff_org').insert({ unit_id: uA, org_type: 2, name: 'Clerk', code: 'CLK' });
    const empIds = [];
    for (const e of [
      { unit_id: uA, full_name: 'Kim Operator', staff_no: 'A-001', department_id: depOps, job_id: jobDriver, position: 'Driver' },
      { unit_id: uA, full_name: 'Lee Mechanic', staff_no: 'A-002', department_id: depMaint, job_id: jobClerk, position: 'Clerk' },
      { unit_id: uA, full_name: 'Pak Dispatcher', staff_no: 'A-003', department_id: depOps, job_id: jobClerk, position: 'Dispatcher' },
    ]) { const [id] = await knex('staff').insert(e); empIds.push(id); }
    const now = new Date(); const Y = now.getFullYear(); const Mo = String(now.getMonth() + 1).padStart(2, '0');
    const statuses = ['present', 'present', 'present', 'leave', 'present', 'absent', 'present'];
    const att = [];
    empIds.forEach((sid, si) => { for (let d = 1; d <= 7; d += 1) att.push({ unit_id: uA, staff_id: sid, attend_date: `${Y}-${Mo}-${String(d).padStart(2, '0')}`, status: statuses[(d + si) % statuses.length] }); });
    await knex('attendance_records').insert(att);
    const mkWf = async (table, entityType, row, statusCode, command = null) => {
      const st = await knex('approval_statuses').where({ code: statusCode }).first();
      const [id] = await knex(table).insert(command === null ? row : { ...row, command });
      const [apprId] = await knex('approvals').insert({ entity_type: entityType, entity_id: id, status_id: st.id });
      await knex('approval_history').insert({ approval_id: apprId, from_status_id: null, to_status_id: st.id, changed_by: adminForSeed.id, comment: 'seed' });
      await knex(table).where({ id }).update({ approval_id: apprId });
      return id;
    };
    await knex('parks').insert([
      { unit_id: uA, region_id: rA, name: 'Central Depot', code: 'CD-1', capacity: 40 },
      { unit_id: uB, region_id: rB, name: 'East Depot', code: 'ED-1', capacity: 25 },
    ]);
    await knex('staff').insert([
      { unit_id: uA, full_name: 'Operator One', staff_no: 'S-1001', position: 'Driver', date_joined: '2024-03-01' },
      { unit_id: uA, full_name: 'Dispatcher Two', staff_no: 'S-1002', position: 'Dispatcher', date_joined: '2023-09-15' },
      { unit_id: uB, full_name: 'Operator Three', staff_no: 'S-2001', position: 'Driver', date_joined: '2025-01-20' },
    ]);
    const [routeId] = await knex('routes').insert({ unit_id: uA, route_no: 'R-100', name: 'City A — City B', start_region_id: rA, end_region_id: rB, distance_km: 120 });
    await knex('routes').insert({ unit_id: uA, route_no: 'R-101', name: 'City A loop', start_region_id: rA, end_region_id: rA, distance_km: 35 });

    // lookups used by the new land-ops screens
    const [rptType] = await knex('report_types').insert({ name: 'Daily operations', code: 'daily' });
    await knex('report_types').insert({ name: 'Monthly summary', code: 'monthly' });
    const [schType] = await knex('schedule_types').insert({ name: 'Daily schedule', code: 'day' });
    await knex('schedule_types').insert({ name: 'Fixed schedule', code: 'fixed' });
    const [certType] = await knex('route_types').insert({ name: 'Traveler bus', code: 'traveler' });
    await knex('route_types').insert({ name: 'Small bus', code: 'small' });
    const [osNew] = await knex('order_statuses').insert({ name: 'New', code: 'new' });
    const [osDone] = await knex('order_statuses').insert({ name: 'Completed', code: 'done' });
    const [otType] = await knex('order_types').insert({ name: 'Parcel', code: 'parcel' });

    // sample rows
    await mkWf('reports', 'business_report', { report_type_id: rptType, scope_type: 1, scope_id: uA, report_date: '2026-06-01', period: '2026-06', title: 'June business report', content: 'Operations within plan.' }, 'submitted');
    await mkWf('reports', 'business_report', { report_type_id: rptType, scope_type: 1, scope_id: uA, report_date: '2026-05-01', period: '2026-05', title: 'May business report', content: 'Closed out.' }, 'approved', 'Acknowledged. Prioritise R-100 maintenance next month.');
    await knex('schedules').insert({ schedule_type_id: schType, unit_id: uA, route_id: routeId, schedule_date: '2026-06-15', start_time: '06:00', end_time: '22:00', notes: 'Peak service' });
    await knex('transfer_sections').insert({ name: 'A → B corridor', start_region_id: rA, end_region_id: rB });
    await knex('warehouses').insert({ unit_id: uA, region_id: rA, name: 'Main Transfer Warehouse', code: 'W-1', capacity: 500, capacity_unit: 'tonnes' });
    await knex('transport_orders').insert([
      { order_no: 'ORD-1001', order_type_id: otType, unit_id: uA, origin_region_id: rA, dest_region_id: rB, order_date: '2026-06-10', status_id: osNew, amount: 1200, details: 'Sample parcel order' },
      { order_no: 'ORD-1002', order_type_id: otType, unit_id: uB, origin_region_id: rB, dest_region_id: rA, order_date: '2026-06-11', status_id: osDone, amount: 800 },
    ]);
    await knex('stat_transport_monthly').insert([
      { stat_year: 2026, stat_month: 5, unit_id: uA, trips: 320, distance_km: 18400, passengers_carried: 9800, cargo_weight: 240, cargo_volume: 0, revenue: 152000 },
      { stat_year: 2026, stat_month: 5, unit_id: uB, trips: 210, distance_km: 11200, passengers_carried: 6100, cargo_weight: 180, cargo_volume: 0, revenue: 98000 },
    ]);

    // vehicle-admin basic-data lookups + sample vehicles/accidents/invoices
    const ins = async (table, rows) => { const ids = []; for (const r of rows) { const [id] = await knex(table).insert(r); ids.push(id); } return ids; };
    const [vtBus, vtTruck] = await ins('vehicle_types', [{ name: 'Bus', code: 'BUS' }, { name: 'Truck', code: 'TRK' }, { name: 'Minibus', code: 'MIN' }]);
    const [vsService] = await ins('vehicle_statuses', [{ name: 'In service', code: 'svc' }, { name: 'Maintenance', code: 'mnt' }, { name: 'Retired', code: 'ret' }]);
    await ins('technical_statuses', [{ name: 'Good', code: 'good' }, { name: 'Needs repair', code: 'rep' }]);
    await ins('vehicle_forms', [{ name: 'Standard', code: 'std' }, { name: 'Articulated', code: 'art' }]);
    await ins('vehicle_uses', [{ name: 'Passenger', code: 'pax' }, { name: 'Cargo', code: 'crg' }]);
    await ins('equipment_categories', [{ name: 'Category A', code: 'A' }, { name: 'Category B', code: 'B' }]);
    await ins('register_categories', [{ name: 'Normal', code: 'normal' }, { name: 'Other', code: 'other' }]);
    await ins('structural_features', [{ name: '2-axle', code: '2ax' }, { name: '3-axle', code: '3ax' }]);
    await ins('real_move_states', [{ name: 'Running', code: 'run' }, { name: 'Idle', code: 'idle' }, { name: 'In repair', code: 'rep' }]);
    await ins('safety_directives', [{ name: 'SD-1 General safety', code: 'SD1' }]);
    const [sevMinor, sevMajor] = await ins('accident_severities', [{ name: 'Minor', code: 'min' }, { name: 'Major', code: 'maj' }, { name: 'Fatal', code: 'fatal' }]);
    const [vh1] = await ins('vehicles', [
      { unit_id: uA, plate_no: 'BUS-001', vehicle_type_id: vtBus, vehicle_status_id: vsService, seat_count: 45 },
      { unit_id: uA, plate_no: 'TRK-014', vehicle_type_id: vtTruck, vehicle_status_id: vsService, load_capacity: 12 },
      { unit_id: uB, plate_no: 'BUS-205', vehicle_type_id: vtBus, vehicle_status_id: vsService, seat_count: 30 },
    ]);
    await knex('accident_notifications').insert({ unit_id: uA, vehicle_id: vh1, occurred_at: '2026-05-22 14:30', location: 'City A junction', severity_id: sevMinor, description: 'Minor side-swipe, no injuries.' });
    await knex('invoices').insert({ invoice_no: 'INV-2026-001', unit_id: uA, amount: 4200, issued_at: '2026-06-01' });
    await knex('price_items').insert([
      { category: 'route_cert_fee', name: 'Passenger route certificate issuance', amount: 15000, unit_of_measure: 'per cert' },
      { category: 'route_cert_fee', name: 'Freight route certificate issuance', amount: 22000, unit_of_measure: 'per cert' },
      { category: 'network_usage_fee', name: 'Monthly network usage', amount: 8000, unit_of_measure: 'per month' },
      { category: 'invoice_price', name: 'Electronic invoice', amount: 500, unit_of_measure: 'per invoice' },
    ]);
    await knex('payments').insert([
      { unit_id: uA, payment_date: '2026-06-05', category: 'route_cert_fee', description: 'Passenger cert renewal', amount: 15000, reference_no: 'PAY-001', status: 'paid', created_by: adminForSeed.id },
      { unit_id: uA, payment_date: '2026-06-12', category: 'network_usage_fee', description: 'June network fee', amount: 8000, reference_no: 'PAY-002', status: 'pending', created_by: adminForSeed.id },
    ]);
    let resvPark = await knex('parks').where({ unit_id: uA }).first();
    if (!resvPark) { const [pid] = await knex('parks').insert({ unit_id: uA, name: 'Central Parking Lot', capacity: 120 }); resvPark = { id: pid }; }
    await knex('parking_reservations').insert([
      { unit_id: uA, park_id: resvPark.id, reserver_name: 'Kim Reserver', contact: '010-222-3333', vehicle_plate: 'BUS-001', slot_no: 'A-12', reserved_from: `${Y}-${Mo}-18 08:00:00`, reserved_to: `${Y}-${Mo}-18 18:00:00`, status: 'reserved', created_by: adminForSeed.id },
      { unit_id: uA, park_id: resvPark.id, reserver_name: 'Lee Customer', contact: '010-444-5555', vehicle_plate: 'TRK-014', slot_no: 'B-03', reserved_from: `${Y}-${Mo}-15 09:00:00`, reserved_to: `${Y}-${Mo}-15 12:00:00`, status: 'checked_out', created_by: adminForSeed.id },
    ]);
    const [cmd1] = await knex('command_orders').insert({ target_unit_id: uA, title: 'Q3 service readiness', short_title: 'Q3 readiness', body: 'Prepare all vehicles for Q3 inspection. Submit a readiness confirmation by 2026-06-20.', instruction_category: 'maintenance', order_number: 'TC-2026-0142', order_classification: 'routine', order_date: '2026-06-10', status_id: osNew });
    const mkBlob = async (text, ct) => { const buf = Buffer.from(text); const sha = require('crypto').createHash('sha256').update(buf).digest('hex'); const [bid] = await knex('file_blobs').insert({ sha256: sha, byte_size: buf.length, content_type: ct, content: buf, created_by: adminForSeed.id }); return { id: bid, size: buf.length }; };
    const ab1 = await mkBlob('Q3 inspection checklist\n- Brakes\n- Tyres\n- Lights\nSample directive attachment stored in the shared database.', 'text/plain');
    const ab2 = await mkBlob('vehicle,status\nBUS-001,ready\nTRK-014,ready\n', 'text/csv');
    await knex('command_order_attachments').insert([
      { command_order_id: cmd1, file_name: 'Q3_inspection_checklist.txt', blob_id: ab1.id, file_size: ab1.size, content_type: 'text/plain', uploaded_by: adminForSeed.id },
      { command_order_id: cmd1, file_name: 'vehicle_roster.csv', blob_id: ab2.id, file_size: ab2.size, content_type: 'text/csv', uploaded_by: adminForSeed.id },
    ]);
    await knex('command_orders').insert({ target_unit_id: uA, title: 'Fuel rationing directive', short_title: 'Fuel rationing', body: 'Apply the fuel rationing schedule effective immediately and report compliance.', instruction_category: 'operations', order_number: 'TC-2026-0151', order_classification: 'urgent', order_date: '2026-06-12', status_id: osNew, receipt_status: 'received', received_at: knex.fn.now(), received_by: adminForSeed.id, execution_status: 'submitted', execution_report: 'Rationing schedule applied across all depots; compliance confirmed by 14:00.', execution_reported_at: knex.fn.now(), execution_reported_by: adminForSeed.id });
    // Transport daily planning sample (a couple of plans for unit A vehicles)
    const planVeh = await knex('vehicles').where({ unit_id: uA }).orderBy('id').limit(3);
    if (planVeh.length) {
      const rt = await knex('routes').where({ unit_id: uA }).first();
      const plans = [];
      planVeh.forEach((v, i) => {
        plans.push({ unit_id: uA, vehicle_id: v.id, plan_date: `${Y}-${Mo}-01`, route_id: rt ? rt.id : null, vehicle_status: 'operational', operational_status: 'in service', departure_point: 'Depot A', arrival_point: 'City center', distance_km: 42 + i * 5, out_passengers: 30 + i * 4, out_tons: 0, in_passengers: 28 + i * 3, in_tons: 0, trips: 2, transport_category: 'passenger', status: i === 0 ? 'approved' : 'draft', created_by: adminForSeed.id });
      });
      await knex('transport_plans').insert(plans);
    }
    await knex('gps_devices').insert({ vehicle_id: vh1, device_no: 'GPS-0001', installed_on: '2026-03-01' });
    await knex('vehicle_locations').insert([
      { vehicle_id: vh1, recorded_at: '2026-06-14 08:00', latitude: 39.0392, longitude: 125.7625, speed: 0 },
      { vehicle_id: vh1, recorded_at: '2026-06-14 09:15', latitude: 39.1100, longitude: 125.8000, speed: 54 },
    ]);
    // information service content
    await knex('notices').insert([
      { title: 'System maintenance window', body: 'The system will be offline Sunday 02:00–03:00.', published_at: '2026-06-10', is_published: 1, author_id: adminForSeed ? adminForSeed.id : null },
      { title: 'New reporting guidelines (draft)', body: 'Draft guidelines pending approval.', is_published: 0, author_id: adminForSeed ? adminForSeed.id : null },
    ]);
    await knex('programs').insert([
      { name: 'Fleet client', version: '2.4.0', description: 'Desktop client for depot operators.' },
      { name: 'GPS sync tool', version: '1.1.3', description: 'Synchronizes location pings to the central DB.' },
    ]);
    await knex('faqs').insert([
      { question: 'How do I reset my password?', answer: 'Contact your unit administrator.', sort_order: 1 },
      { question: 'Who approves route certificates?', answer: 'The Vehicle Administration department.', sort_order: 2 },
    ]);
    await knex('feedback').insert([
      { subject: 'Schedule screen', body: 'Could we filter schedules by route as well?', submitted_by: adminForSeed ? adminForSeed.id : null, is_read: 0 },
    ]);
    await mkWf('tech_data_submissions', 'tech_data_submission', { title: 'May telemetry export', unit_id: uA, submitted_by: adminForSeed.id, submitted_at: '2026-06-01' }, 'submitted');
    await mkWf('tech_data_submissions', 'tech_data_submission', { title: 'Engine diagnostics dataset', unit_id: uB, submitted_by: adminForSeed.id, submitted_at: '2026-05-20' }, 'approved', 'Data accepted. Re-export with GPS columns next time.');
    // department operations
    await mkWf('monthly_reports', 'monthly_report', { unit_id: uA, stat_year: 2026, stat_month: 5, title: 'May production summary', content: 'Targets met.' }, 'submitted');
    await mkWf('monthly_reports', 'monthly_report', { unit_id: uB, stat_year: 2026, stat_month: 5, title: 'May production summary', content: 'Below target on cargo.' }, 'approved', 'Submit a recovery plan for cargo shortfall.');
    await mkWf('effort_plans', 'effort_plan', { unit_id: uA, period: '2026-Q3', title: 'Q3 passenger volume', target_value: 100000, actual_value: 0, notes: 'Quarterly target' }, 'submitted');
    await mkWf('effort_plans', 'effort_plan', { unit_id: uB, period: '2026-Q2', title: 'Q2 cargo tonnage', target_value: 5000, actual_value: 4200, notes: 'Quarterly target' }, 'approved', 'Plan approved. Raise Q3 target by 10%.');
    await knex('electricity_reports').insert([
      { unit_id: uA, report_date: '2026-06-13', consumption_kwh: 1240.5, peak_kwh: 88.2 },
      { unit_id: uA, report_date: '2026-06-14', consumption_kwh: 1190.0, peak_kwh: 81.0 },
    ]);
    const [eq1] = await knex('equipment').insert({ unit_id: uA, name: 'Diagnostic lift #1', code: 'EQ-001', category: 'Workshop', serial_no: 'SN-12345', status: 'in service', registered_on: '2025-09-10' });
    await knex('equipment').insert({ unit_id: uA, name: 'Tyre balancer', code: 'EQ-002', category: 'Workshop', status: 'in service' });
    await knex('equipment_inspections').insert([
      { equipment_id: eq1, unit_id: uA, inspection_date: '2026-06-01', inspection_type: 'normal', result: 'pass', inspector: 'J. Kim' },
      { equipment_id: eq1, unit_id: uA, inspection_date: '2026-06-12', inspection_type: 'comprehensive', result: 'needs-repair', inspector: 'J. Kim', notes: 'Hydraulic seal wear.' },
    ]);
    await knex('no_accident_records').insert([
      { unit_id: uA, as_of_date: '2026-06-14', accident_free_days: 145 },
      { unit_id: uB, as_of_date: '2026-06-14', accident_free_days: 32 },
    ]);
    await knex('weekly_schedules').insert([
      { unit_id: uA, week_start: '2026-06-15', title: 'Week 25 plan', content: 'Maintenance focus week.' },
    ]);
    // Business daily reports through the submit/review workflow
    await mkWf('business_daily_reports', 'business_daily_report', { department: 'comprehensive', unit_id: uA, report_date: '2026-06-14', title: 'Daily comprehensive report', content: 'All operations normal.' }, 'submitted');
    await mkWf('business_daily_reports', 'business_daily_report', { department: 'disinfection', unit_id: uA, report_date: '2026-06-13', title: 'Daily disinfection report', content: 'Depots disinfected.' }, 'approved', 'Maintain the schedule; report any shortfall by 17:00.');
    await mkWf('business_daily_reports', 'business_daily_report', { department: 'financial', unit_id: uB, report_date: '2026-06-14', title: 'Daily financial report', content: 'Revenue on track.' }, 'draft');
    // consolidation-department daily reports (surfaced as dashboards under their departments)
    await mkWf('business_daily_reports', 'business_daily_report', { department: 'water', unit_id: uA, report_date: '2026-06-14', title: 'Water transport daily', content: 'River route on schedule.' }, 'submitted');
    await mkWf('business_daily_reports', 'business_daily_report', { department: 'revenue', unit_id: uB, report_date: '2026-06-14', title: 'Revenue examination daily', content: 'Ticket audit complete.' }, 'approved', 'Flag the two mismatched receipts for follow-up.');
    await mkWf('business_daily_reports', 'business_daily_report', { department: 'effort', unit_id: uA, report_date: '2026-06-14', title: 'Effort daily', content: 'Crews at full strength.' }, 'submitted');
    await mkWf('business_daily_reports', 'business_daily_report', { department: 'first_business', unit_id: uB, report_date: '2026-06-14', title: 'First business daily', content: 'No exceptions.' }, 'submitted');
    await mkWf('business_daily_reports', 'business_daily_report', { department: 'route_review', unit_id: uA, report_date: '2026-06-14', title: 'Route review office daily', content: 'Route certificate reviews completed.' }, 'submitted');
    await mkWf('business_daily_reports', 'business_daily_report', { department: 'water_transport', unit_id: uA, report_date: '2026-06-14', title: 'Water transport bureau daily', content: 'Ferry operations normal.' }, 'approved', 'Confirm next week schedule.');
    await knex('place_names').insert([
      { name: 'Central Province', code: 'CP', category: 'province' },
      { name: 'Riverside City', code: 'RC', category: 'city', latitude: 37.550000, longitude: 126.990000 },
      { name: 'Ssangmai-dong', code: 'SMD', category: 'district', latitude: 37.561000, longitude: 126.982000, description: 'District served by the unit.' },
    ]);
    const haveNotice = await knex('notices').first();
    if (!haveNotice) await knex('notices').insert({ title: 'Ssangmai-dong service notice', body: 'Routine maintenance scheduled this weekend.', is_published: 1, published_at: knex.fn.now(), author_id: adminForSeed.id });
    // security guard duty roster (Defense table)
    await knex('guard_duties').insert([
      { unit_id: uA, duty_date: '2026-06-15', shift: 'Day', post: 'Main gate', guard_name: 'P. Han', created_by: adminForSeed.id },
      { unit_id: uA, duty_date: '2026-06-15', shift: 'Night', post: 'Depot perimeter', guard_name: 'S. Ryu', created_by: adminForSeed.id },
      { unit_id: uB, duty_date: '2026-06-15', shift: 'Day', post: 'Fuel store', guard_name: 'J. Oh', created_by: adminForSeed.id },
    ]);

    // finance, indicators, online status, licenses
    const [fcFuel, fcRev] = await ins('finance_categories', [{ name: 'Fuel', code: 'fuel' }, { name: 'Revenue', code: 'rev' }, { name: 'Maintenance', code: 'mnt' }]);
    const [ltOp] = await ins('license_types', [{ name: 'Operating license', code: 'op' }, { name: 'Safety license', code: 'safe' }]);
    await knex('finance_records').insert([
      { unit_id: uA, record_date: '2026-06-02', category_id: fcRev, direction: 1, amount: 152000, note: 'May fares' },
      { unit_id: uA, record_date: '2026-06-03', category_id: fcFuel, direction: 2, amount: 38000, note: 'Fuel' },
    ]);
    await knex('transport_indicators').insert([
      { name: 'Passenger-kilometres', code: 'pkm', unit_of_measure: 'p·km' },
      { name: 'Tonne-kilometres', code: 'tkm', unit_of_measure: 't·km' },
    ]);
    await knex('unit_online_status').insert([
      { unit_id: uA, is_online: 1, last_seen_at: '2026-06-14 08:00' },
      { unit_id: uB, is_online: 0, last_seen_at: '2026-06-13 19:30' },
    ]);
    // a license in draft (workflow)
    const [licId] = await knex('licenses').insert({ unit_id: uA, license_no: 'LIC-0001', license_type_id: ltOp, valid_from: '2026-01-01', valid_to: '2026-12-31' });
    if (draftStatus && adminForSeed) {
      const [la] = await knex('approvals').insert({ entity_type: 'license', entity_id: licId, status_id: draftStatus.id });
      await knex('approval_history').insert({ approval_id: la, from_status_id: null, to_status_id: draftStatus.id, changed_by: adminForSeed.id, comment: 'created' });
      await knex('licenses').where({ id: licId }).update({ approval_id: la });
    }

    // a route certificate in draft (workflow demo)
    const [certId] = await knex('route_certificates').insert({ route_id: routeId, unit_id: uA, certificate_no: 'RC-0001', cert_type_id: certType, valid_from: '2026-01-01', valid_to: '2026-12-31' });
    if (draftStatus && adminForSeed) {
      const [apprId] = await knex('approvals').insert({ entity_type: 'route_certificate', entity_id: certId, status_id: draftStatus.id });
      await knex('approval_history').insert({ approval_id: apprId, from_status_id: null, to_status_id: draftStatus.id, changed_by: adminForSeed.id, comment: 'created' });
      await knex('route_certificates').where({ id: certId }).update({ approval_id: apprId });
    }
  }

  // --- sample notifications (so the header bell has content) -------------
  const adminUser = await knex('users').where({ username: 'admin' }).first();
  if (adminUser) {
    const existing = await knex('notifications').where({ user_id: adminUser.id }).first();
    if (!existing) {
      await knex('notifications').insert([
        { user_id: adminUser.id, type: 'approval', title: 'Operating condition awaiting approval', body: 'Unit Alpha submitted a condition for review.', link: '/units', is_read: 0 },
        { user_id: adminUser.id, type: 'accident', title: 'Accident reported', body: 'A vehicle accident was reported in Region A.', link: '/vehicles', is_read: 0 },
        { user_id: adminUser.id, type: 'system', title: 'Welcome to HQ Transport', body: 'Use the system rail to open a screen.', link: '/', is_read: 1 },
      ]);
    }
  }

  console.log('Seed complete.');
  console.log('  admin           / admin123  (super admin — sees all 5 systems)');
  console.log('  ops_manager     / test123   (Land transport ops only; full Unit rights)');
  console.log('  vehicle_clerk   / test123   (Vehicle admin only; view+add)');
  console.log('  analyst         / test123   (Integration only; view-only, no action buttons)');
  console.log('  region_a_viewer / test123   (Units, view-only, limited to Region A data)');
  console.log('  multi           / test123   (Land ops + Vehicle admin; other 3 hidden)');
}

seed().then(() => knex.destroy()).catch((e) => { console.error(e); knex.destroy(); process.exit(1); });
