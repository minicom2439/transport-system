// Program Registration Management: manage the hierarchical function tree
// (system_sections) for THIS app only — every query is scoped to the app's
// system_code by the repository, so the unit app can never alter HQ's menu.
const repo = require('../repositories/section.repository');
const { buildTree } = require('./meta.service');
const { ValidationError } = require('./errors');
const CODE_RE = /^[a-z0-9_]+$/;

async function tree() {
  const rows = await repo.adminList();
  return buildTree(rows.filter((r) => r.is_active));
}
async function create(body) {
  const name = String(body.name || '').trim();
  const code = String(body.code || '').trim();
  const fields = {};
  if (!name) fields.name = 'Name is required.';
  if (!code) fields.code = 'Code is required.';
  else if (!CODE_RE.test(code)) fields.code = 'Use lowercase letters, numbers and underscore only.';
  if (Object.keys(fields).length) throw new ValidationError(fields);
  if (await repo.codeExists(code)) throw new ValidationError({ code: 'That code already exists in this system.' });
  const parent_id = body.parent_id ? Number(body.parent_id) : null;
  let node_type = Number(body.node_type) || 0;
  if (!node_type) {
    if (!parent_id) node_type = 1;
    else { const p = await repo.findById(parent_id); node_type = p && p.node_type === 1 ? 2 : 4; }
  }
  return repo.createNode({ name, code, parent_id, node_type, sort_order: Number(body.sort_order) || 0 });
}
async function update(id, body) {
  const ex = await repo.findById(id);
  if (!ex) throw new ValidationError({ _: 'Section not found.' });
  const d = {};
  if (body.name != null) { const n = String(body.name).trim(); if (!n) throw new ValidationError({ name: 'Name is required.' }); d.name = n; }
  if (body.code != null) { const c = String(body.code).trim(); if (!CODE_RE.test(c)) throw new ValidationError({ code: 'Use lowercase letters, numbers and underscore only.' }); if (await repo.codeExists(c, id)) throw new ValidationError({ code: 'That code already exists.' }); d.code = c; }
  if (body.sort_order != null) d.sort_order = Number(body.sort_order) || 0;
  if (body.parent_id !== undefined) { const pid = body.parent_id ? Number(body.parent_id) : null; if (pid === id) throw new ValidationError({ _: 'A section cannot be its own parent.' }); d.parent_id = pid; }
  return repo.updateNode(id, d);
}
async function remove(id) {
  if (await repo.childCount(id) > 0) throw new ValidationError({ _: 'Remove or move the child items first.' });
  return repo.remove(id);
}
module.exports = { tree, create, update, remove };
