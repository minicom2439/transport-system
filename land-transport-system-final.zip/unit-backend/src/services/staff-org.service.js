const repo = require('../repositories/staff-org.repository');
const { makeService, requireFields } = require('./master-data.factory');
const validate = (b) => requireFields(b, {
  name: { label: 'Name', required: true },
  org_type: { label: 'Type', required: true, type: 'number' },
  unit_id: { label: 'Unit', type: 'number' },
  code: { label: 'Code' },
});
module.exports = makeService(repo, { scopeColumn: 'staff_org.unit_id', validate });
