const repo = require('../repositories/payment.repository');
const { makeService, requireFields } = require('./master-data.factory');
const validate = (b) => requireFields(b, {
  unit_id: { label: 'Unit', type: 'number' },
  payment_date: { label: 'Date', required: true },
  category: { label: 'Category' },
  description: { label: 'Description' },
  amount: { label: 'Amount', type: 'number' },
  reference_no: { label: 'Reference' },
  status: { label: 'Status' },
});
module.exports = makeService(repo, { scopeColumn: 'payments.unit_id', validate });
