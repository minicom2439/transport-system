const repo = require('../repositories/attendance.repository');
const knex = require('../db/knex');
const { dataScopeClause } = require('./permission.service');
const { ValidationError } = require('./errors');
const VALID = new Set(['present', 'absent', 'leave', 'trip', 'sick', '']);
const scopeOf = (req) => { const a = req.session.user.access; return dataScopeClause({ isSuperAdmin: a.isSuperAdmin, dataScopes: a.dataScopes }, { unitColumn: 's.unit_id' }); };
async function grid(req) { const y = Number(req.query.year), m = Number(req.query.month); if (!y || !m) throw new ValidationError({ _: 'year and month are required.' }); return repo.grid(y, m, scopeOf(req)); }
async function summary(req) { const y = Number(req.query.year), m = Number(req.query.month); if (!y || !m) throw new ValidationError({ _: 'year and month are required.' }); return repo.summary(y, m, scopeOf(req)); }
async function set(req) {
  const { staff_id, attend_date, status } = req.body || {};
  if (!staff_id || !attend_date) throw new ValidationError({ _: 'staff_id and attend_date are required.' });
  if (!VALID.has(status || '')) throw new ValidationError({ status: 'Invalid status.' });
  const st = await knex('staff').where({ id: staff_id }).first();
  return repo.upsert({ staff_id: Number(staff_id), attend_date, status: status || '', unit_id: st ? st.unit_id : null, userId: req.session.user.id });
}
module.exports = { grid, summary, set };
