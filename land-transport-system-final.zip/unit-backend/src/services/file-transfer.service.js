// Data Transfer / File Management: inter-unit file exchange. A unit sends a
// file to one or more recipient units; recipients see it in their inbox and
// mark it received. File BYTES are stored in the shared database (file_blobs),
// so any server sharing that DB can read them with no shared filesystem.
const repo = require('../repositories/file-transfer.repository');
const blobRepo = require('../repositories/file-blob.repository');
const config = require('../config');
const { parseListParams } = require('../repositories/list-query');
const { ValidationError, ForbiddenError } = require('./errors');
const { requireFields } = require('./master-data.factory');
const myUnit = (req) => req.session.user.unitId || null;
const notFound = () => { throw Object.assign(new Error('File not found'), { status: 404, publicMessage: 'File not found' }); };

async function list(req) {
  const params = parseListParams(req.query);
  const box = req.query.box === 'sent' ? 'sent' : 'received';
  if (box === 'received') {
    const unitId = myUnit(req);
    if (!unitId) return { data: [], total: 0, page: params.page, limit: params.limit, box };
    const { data, total } = await repo.received(params, unitId);
    return { data, total, page: params.page, limit: params.limit, box };
  }
  const { data, total } = await repo.sent(params, req.session.user.isSuperAdmin ? null : myUnit(req));
  return { data, total, page: params.page, limit: params.limit, box };
}

async function create(body, req) {
  const d = requireFields(body, { title: { label: 'Title', required: true }, report_title: { label: 'Report title' }, file_name: { label: 'File name', required: true } });
  const recipients = Array.isArray(body.recipient_unit_ids) ? body.recipient_unit_ids.map(Number).filter(Boolean) : [];
  if (!recipients.length) throw new ValidationError({ recipient_unit_ids: 'Select at least one recipient unit.' });
  Object.keys(d).forEach((k) => { if (d[k] === null) delete d[k]; });

  let blob = null;
  if (body.data_base64) {
    let buf;
    try { buf = Buffer.from(String(body.data_base64), 'base64'); } catch (e) { throw new ValidationError({ file: 'Invalid file data.' }); }
    if (!buf.length) throw new ValidationError({ file: 'The uploaded file is empty.' });
    if (buf.length > config.maxUploadBytes) throw new ValidationError({ file: `File exceeds the ${config.maxUploadMb} MB limit.` });
    blob = await blobRepo.insert({ buffer: buf, content_type: body.content_type, created_by: req.session.user.id });
  } else {
    throw new ValidationError({ file: 'Please attach a file to send.' });
  }

  const row = await repo.create({
    ...d,
    sender_unit_id: myUnit(req),
    created_by: req.session.user.id,
    sent_at: new Date().toISOString(),
    blob_id: blob.id,
    content_type: body.content_type || null,
    file_size: blob.byte_size,
  });
  await repo.addRecipients(row.id, recipients);
  return row;
}

function markReceived(fileId, req) { const u = myUnit(req); if (!u) throw new ValidationError({ _: 'Your account is not attached to a unit.' }); return repo.markReceived(fileId, u); }
function remove(fileId, req, box) { const u = myUnit(req); if (box === 'received' && u) return repo.deleteRecipient(fileId, u); return repo.remove(fileId); }
function recipients(fileId) { return repo.recipientsOf(fileId); }

// Access-checked binary fetch: only the sender unit, a recipient unit, or a
// super-admin may download. Recipients are marked received on download.
async function getForDownload(fileId, req) {
  const t = await repo.findById(fileId);
  if (!t || !t.is_active) notFound();
  const u = myUnit(req);
  const isSuper = req.session.user.isSuperAdmin;
  const recips = await repo.recipientsOf(fileId);
  const isRecipient = u && recips.some((r) => Number(r.unit_id) === Number(u));
  const isSender = u && Number(t.sender_unit_id) === Number(u);
  if (!isSuper && !isSender && !isRecipient) throw new ForbiddenError('You are not authorized to download this file.');
  if (isRecipient) await repo.markReceived(fileId, u);
  if (!t.blob_id) { throw Object.assign(new Error('No file content'), { status: 404, publicMessage: 'No file content is stored for this transfer.' }); }
  const blob = await blobRepo.get(t.blob_id);
  if (!blob) notFound();
  return { buffer: Buffer.from(blob.content), file_name: t.file_name, content_type: t.content_type || blob.content_type || 'application/octet-stream', byte_size: blob.byte_size };
}

module.exports = { list, create, markReceived, remove, getForDownload, recipients };
