const repo = require('../repositories/place-name.repository');
const { makeService, requireFields } = require('./master-data.factory');
const validate = (b) => requireFields(b, {
  name: { label: 'Name', required: true },
  code: { label: 'Code' },
  category: { label: 'Category' },
  latitude: { label: 'Latitude', type: 'number' },
  longitude: { label: 'Longitude', type: 'number' },
  description: { label: 'Description' },
});
module.exports = makeService(repo, { validate });   // global admin reference data
