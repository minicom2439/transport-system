const repo = require('../repositories/command-order.repository');
const { makeService, requireFields } = require('./master-data.factory');
const validate = (b) => requireFields(b, { target_unit_id: { label: 'Target unit', required: true, type: 'number' }, title: { label: 'Title', required: true }, body: { label: 'Body' }, order_date: { label: 'Date' }, status_id: { label: 'Status', type: 'number' } });
module.exports = makeService(repo, { scopeColumn: 'command_orders.target_unit_id', validate, updatedBy: false });
