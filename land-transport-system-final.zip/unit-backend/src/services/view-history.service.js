// View History: who signed up on a given date. Month view returns per-day
// signup counts; day view lists username, name, unit. Range-based queries so
// it works identically on SQLite (dev) and MySQL (prod).
const knex = require('../db/knex');
const pad = (n) => String(n).padStart(2, '0');
async function month(req) {
  const year = Number(req.query.year), m = Number(req.query.month);
  if (!year || !m) return { year, month: m, days: [] };
  const start = `${year}-${pad(m)}-01 00:00:00`;
  const next = m === 12 ? `${year + 1}-01-01 00:00:00` : `${year}-${pad(m + 1)}-01 00:00:00`;
  const rows = await knex('users').where('created_at', '>=', start).andWhere('created_at', '<', next).select('created_at');
  const map = {};
  rows.forEach((r) => { const d = String(r.created_at).slice(0, 10); map[d] = (map[d] || 0) + 1; });
  const days = Object.entries(map).map(([date, count]) => ({ date, count })).sort((a, b) => (a.date < b.date ? -1 : 1));
  return { year, month: m, days };
}
async function day(req) {
  const date = req.query.date;
  if (!date) return { date, data: [] };
  const rows = await knex('users as u').leftJoin('units as un', 'un.id', 'u.unit_id').where('u.created_at', '>=', `${date} 00:00:00`).andWhere('u.created_at', '<=', `${date} 23:59:59`).select('u.username', 'u.full_name', 'un.name as unit_name').orderBy('u.username');
  return { date, data: rows };
}
module.exports = { month, day };
