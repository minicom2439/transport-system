const repo = require('../repositories/transport-plans.repository');
const knex = require('../db/knex');
const { dataScopeClause } = require('./permission.service');
const { ValidationError } = require('./errors');
const scopeOf = (req) => { const a = req.session.user.access; return dataScopeClause({ isSuperAdmin: a.isSuperAdmin, dataScopes: a.dataScopes }, { unitColumn: 'v.unit_id' }); };
const NUM = ['route_id', 'distance_km', 'out_passengers', 'out_tons', 'in_passengers', 'in_tons', 'trips'];
const TXT = ['vehicle_status', 'operational_status', 'departure_point', 'arrival_point', 'transport_category', 'remarks', 'status'];
async function month(req) { const y = Number(req.query.year), m = Number(req.query.month); if (!y || !m) throw new ValidationError({ _: 'year and month are required.' }); return repo.monthOverview(y, m, scopeOf(req)); }
async function day(req) { const d = req.query.date; if (!d) throw new ValidationError({ _: 'date is required.' }); return { date: d, rows: await repo.dayGrid(d, scopeOf(req)) }; }
async function save(req) {
  const b = req.body || {};
  if (!b.vehicle_id || !b.plan_date) throw new ValidationError({ _: 'vehicle and date are required.' });
  const v = await knex('vehicles').where({ id: b.vehicle_id }).first();
  if (!v) throw new ValidationError({ _: 'Vehicle not found.' });
  const plan = { vehicle_id: Number(b.vehicle_id), plan_date: b.plan_date, unit_id: v.unit_id, created_by: req.session.user.id };
  NUM.forEach((k) => { if (b[k] !== undefined && b[k] !== '' && b[k] !== null) plan[k] = Number(b[k]); });
  TXT.forEach((k) => { if (b[k] !== undefined) plan[k] = b[k] === '' ? null : String(b[k]); });
  if (!plan.status) plan.status = 'draft';
  return repo.upsert(plan);
}
module.exports = { month, day, save };
