const repo = require('../repositories/parking-reservation.repository');
const { makeService, requireFields } = require('./master-data.factory');
const validate = (b) => requireFields(b, {
  unit_id: { label: 'Unit', type: 'number' },
  park_id: { label: 'Parking lot', type: 'number' },
  reserver_name: { label: 'Reserver', required: true },
  contact: { label: 'Contact' },
  vehicle_plate: { label: 'Vehicle plate' },
  slot_no: { label: 'Slot' },
  reserved_from: { label: 'From' },
  reserved_to: { label: 'To' },
  status: { label: 'Status' },
  notes: { label: 'Notes' },
});
module.exports = makeService(repo, { scopeColumn: 'parking_reservations.unit_id', validate });
