const repo = require('../repositories/price-item.repository');
const { makeService, requireFields } = require('./master-data.factory');
const validate = (b) => requireFields(b, {
  category: { label: 'Category', required: true },
  name: { label: 'Name', required: true },
  amount: { label: 'Amount', type: 'number' },
  unit_of_measure: { label: 'Unit' },
  description: { label: 'Description' },
});
module.exports = makeService(repo, { validate });   // global reference data (no unit scope)
