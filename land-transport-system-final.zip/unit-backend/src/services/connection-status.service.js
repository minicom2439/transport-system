// Connection Status: the structure of units that have joined the system, with
// their current online state (read-only).
const knex = require('../db/knex');
async function list() {
  const rows = await knex('units as u')
    .leftJoin('unit_online_status as o', 'o.unit_id', 'u.id')
    .leftJoin('regions as r', 'r.id', 'u.region_id')
    .where('u.is_active', 1)
    .select('u.id', 'u.name', 'u.code', 'u.parent_id', 'r.name as region_name', 'o.is_online', 'o.last_seen_at')
    .orderBy('u.name');
  return { data: rows.map((x) => ({ ...x, is_online: !!x.is_online })), total: rows.length };
}
module.exports = { list };
