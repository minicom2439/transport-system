// src/services/auth.service.js
const bcrypt = require('bcryptjs');
const userRepo = require('../repositories/user.repository');
const { loadAccess } = require('./permission.service');

// A precomputed hash of a random string. When the username doesn't exist we
// still run a compare against this so failed logins take ~the same time as
// successful ones — preventing username enumeration via timing.
const DUMMY_HASH = bcrypt.hashSync('a-non-matching-placeholder-password', 10);

async function authenticate(username, password) {
  const user = await userRepo.findByUsername(username);

  if (!user) {
    await bcrypt.compare(password, DUMMY_HASH); // equalize timing
    return null;
  }

  const ok = await bcrypt.compare(password, user.password_hash);
  if (!ok) return null;

  await userRepo.updateLastLogin(user.id);
  const access = await loadAccess(user);
  return {
    id: user.id,
    username: user.username,
    fullName: user.full_name,
    isSuperAdmin: !!user.is_super_admin,
    unitId: user.unit_id || null,
    position: user.position || null,
    access: {
      isSuperAdmin: access.isSuperAdmin,
      permissions: Array.from(access.permissions),
      dataScopes: access.dataScopes,
      managedSectionCodes: access.managedSectionCodes,
    },
  };
}

async function hashPassword(plain) {
  return bcrypt.hash(plain, 10);
}

module.exports = { authenticate, hashPassword };
