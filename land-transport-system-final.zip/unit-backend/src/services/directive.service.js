const repo = require('../repositories/directive.repository');
const blobRepo = require('../repositories/file-blob.repository');
const { parseListParams } = require('../repositories/list-query');
const { dataScopeClause } = require('./permission.service');
const { ValidationError } = require('./errors');
const notFound = () => { throw Object.assign(new Error('Directive not found'), { status: 404, publicMessage: 'Directive not found' }); };
const scopeOf = (req) => { const a = req.session.user.access; return dataScopeClause({ isSuperAdmin: a.isSuperAdmin, dataScopes: a.dataScopes }, { unitColumn: 'command_orders.target_unit_id' }); };
async function list(req) { const params = parseListParams(req.query); const { data, total } = await repo.list(params, scopeOf(req)); return { data, total, page: params.page, limit: params.limit, sort: params.sort, dir: params.dir }; }
async function detail(req) { const row = await repo.detail(Number(req.params.id), scopeOf(req)); if (!row) notFound(); return row; }
async function receive(req) { const row = await repo.detail(Number(req.params.id), scopeOf(req)); if (!row) notFound(); await repo.markReceived(row.id, req.session.user.id); return { id: row.id, receipt_status: 'received' }; }
async function saveExecution(req) {
  const row = await repo.detail(Number(req.params.id), scopeOf(req)); if (!row) notFound();
  const b = req.body || {};
  const status = b.execution_status === 'submitted' ? 'submitted' : 'drafting';
  if (status === 'submitted' && !String(b.execution_report || '').trim()) throw new ValidationError({ execution_report: 'A report is required before submitting.' });
  await repo.saveExecution(row.id, { execution_report: b.execution_report, execution_status: status }, req.session.user.id);
  return { id: row.id, execution_status: status };
}
async function downloadAttachment(req) {
  const row = await repo.detail(Number(req.params.id), scopeOf(req)); if (!row) notFound();
  const att = await repo.attachment(row.id, Number(req.params.attId)); if (!att) notFound();
  if (att.blob_id) {
    const blob = await blobRepo.get(att.blob_id);
    if (blob) return { stream: true, buffer: Buffer.from(blob.content), file_name: att.file_name, content_type: att.content_type || blob.content_type || 'application/octet-stream', byte_size: blob.byte_size };
  }
  return { stream: false, file_name: att.file_name, file_path: att.file_path, file_size: att.file_size, content_type: att.content_type, note: 'No file content is stored for this attachment.' };
}
module.exports = { list, detail, receive, saveExecution, downloadAttachment };
