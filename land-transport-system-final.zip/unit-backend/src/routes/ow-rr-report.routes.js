module.exports = require('./_dailyByDept.factory')('ow_rr_report', 'route_review');
