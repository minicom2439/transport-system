const express = require('express');
const svc = require('../services/view-history.service');
const { requireLogin } = require('../middleware/auth.middleware');
const { requirePermission } = require('../middleware/authorize.middleware');
const router = express.Router();
router.get('/', requireLogin, requirePermission('ops_history', 'view'), async (req, res, next) => { try { res.json(await svc.month(req)); } catch (e) { next(e); } });
router.get('/day', requireLogin, requirePermission('ops_history', 'view'), async (req, res, next) => { try { res.json(await svc.day(req)); } catch (e) { next(e); } });
module.exports = router;
