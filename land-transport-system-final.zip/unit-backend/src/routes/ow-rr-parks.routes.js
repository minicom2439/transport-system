module.exports = require('./_readonly.factory')(require('../services/park.service'), 'ow_rr_parks');
