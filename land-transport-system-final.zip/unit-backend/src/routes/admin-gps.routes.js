module.exports = require('./_readonly.factory')(require('../services/vehicle-location.service'), 'admin_gps');
