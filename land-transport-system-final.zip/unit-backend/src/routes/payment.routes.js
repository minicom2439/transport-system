module.exports = require('./_crud.factory')(require('../services/payment.service'), 'ops_pay_history', 'payments');
