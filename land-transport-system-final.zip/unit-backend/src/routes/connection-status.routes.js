const express = require('express');
const svc = require('../services/connection-status.service');
const { requireLogin } = require('../middleware/auth.middleware');
const { requirePermission } = require('../middleware/authorize.middleware');
const router = express.Router();
router.get('/', requireLogin, requirePermission('ops_connection', 'view'), async (req, res, next) => { try { res.json(await svc.list()); } catch (e) { next(e); } });
module.exports = router;
