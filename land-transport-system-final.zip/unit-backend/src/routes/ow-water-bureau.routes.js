module.exports = require('./_dailyByDept.factory')('ow_water_bureau', 'water_transport');
