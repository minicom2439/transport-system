const express = require('express');
const svc = require('../services/transport-plans.service');
const { requireLogin } = require('../middleware/auth.middleware');
const { requirePermission } = require('../middleware/authorize.middleware');
const { audit } = require('../middleware/audit.middleware');
const router = express.Router();
const P = 'ops_transport_planning';
router.get('/', requireLogin, requirePermission(P, 'view'), async (req, res, next) => { try { res.json(await svc.month(req)); } catch (e) { next(e); } });
router.get('/day', requireLogin, requirePermission(P, 'view'), async (req, res, next) => { try { res.json(await svc.day(req)); } catch (e) { next(e); } });
// Daily Report Status — same data, read-only, gated on its own section
router.get('/status', requireLogin, requirePermission('ops_transport_status', 'view'), async (req, res, next) => { try { res.json(await svc.day(req)); } catch (e) { next(e); } });
router.post('/', requireLogin, requirePermission(P, 'edit'), audit('update', 'transport_plans'), async (req, res, next) => { try { res.json({ data: await svc.save(req) }); } catch (e) { next(e); } });
module.exports = router;
