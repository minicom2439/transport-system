module.exports = require('./_crud.factory')(require('../services/notice.service'), 'admin_news', 'notices');
