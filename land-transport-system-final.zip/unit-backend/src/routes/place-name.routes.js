module.exports = require('./_crud.factory')(require('../services/place-name.service'), 'admin_places', 'place_names');
