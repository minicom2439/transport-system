const express = require('express');
const svc = require('../services/directive.service');
const { requireLogin } = require('../middleware/auth.middleware');
const { requirePermission } = require('../middleware/authorize.middleware');
const { audit } = require('../middleware/audit.middleware');
const router = express.Router();
const S = 'ops_directive';
router.get('/', requireLogin, requirePermission(S, 'view'), async (req, res, next) => { try { res.json(await svc.list(req)); } catch (e) { next(e); } });
router.get('/:id', requireLogin, requirePermission(S, 'view'), async (req, res, next) => { try { res.json({ data: await svc.detail(req) }); } catch (e) { next(e); } });
router.get('/:id/attachments/:attId/download', requireLogin, requirePermission(S, 'view'), async (req, res, next) => {
  try {
    const f = await svc.downloadAttachment(req);
    if (f.stream) {
      res.setHeader('Content-Type', f.content_type || 'application/octet-stream');
      res.setHeader('Content-Length', f.byte_size);
      res.setHeader('Content-Disposition', `attachment; filename*=UTF-8''${encodeURIComponent(f.file_name)}`);
      return res.send(f.buffer);
    }
    return res.json({ data: f });
  } catch (e) { next(e); }
});
router.post('/:id/receive', requireLogin, requirePermission(S, 'edit'), audit('update', 'command_orders'), async (req, res, next) => { try { res.json({ data: await svc.receive(req) }); } catch (e) { next(e); } });
router.put('/:id/execution', requireLogin, requirePermission(S, 'edit'), audit('update', 'command_orders'), async (req, res, next) => { try { res.json({ data: await svc.saveExecution(req) }); } catch (e) { next(e); } });
module.exports = router;
