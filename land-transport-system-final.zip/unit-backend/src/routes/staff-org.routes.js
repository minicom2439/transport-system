module.exports = require('./_crud.factory')(require('../services/staff-org.service'), 'ops_emp_org', 'staff_org');
