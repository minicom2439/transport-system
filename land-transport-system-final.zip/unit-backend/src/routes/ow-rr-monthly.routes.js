module.exports = require('./_readonly.factory')(require('../services/monthly-report.service'), 'ow_rr_monthly');
