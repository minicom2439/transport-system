module.exports = require('./_crud.factory')(require('../services/parking-reservation.service'), 'ops_reservation', 'parking_reservations');
