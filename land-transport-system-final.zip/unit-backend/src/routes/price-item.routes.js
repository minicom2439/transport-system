module.exports = require('./_crud.factory')(require('../services/price-item.service'), 'ops_pay_price', 'price_items');
