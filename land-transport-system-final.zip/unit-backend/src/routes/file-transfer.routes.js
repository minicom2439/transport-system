const express = require('express');
const svc = require('../services/file-transfer.service');
const { requireLogin } = require('../middleware/auth.middleware');
const { requirePermission } = require('../middleware/authorize.middleware');
const { audit } = require('../middleware/audit.middleware');
const S = 'ops_files', T = 'file_transfers';
const router = express.Router();
router.get('/', requireLogin, requirePermission(S, 'view'), async (req, res, next) => { try { res.json(await svc.list(req)); } catch (e) { next(e); } });
router.get('/:id/recipients', requireLogin, requirePermission(S, 'view'), async (req, res, next) => { try { res.json({ data: await svc.recipients(Number(req.params.id)) }); } catch (e) { next(e); } });
router.get('/:id/download', requireLogin, requirePermission(S, 'view'), async (req, res, next) => {
  try {
    const f = await svc.getForDownload(Number(req.params.id), req);
    res.setHeader('Content-Type', f.content_type || 'application/octet-stream');
    res.setHeader('Content-Length', f.byte_size);
    res.setHeader('Content-Disposition', `attachment; filename*=UTF-8''${encodeURIComponent(f.file_name)}`);
    res.send(f.buffer);
  } catch (e) { next(e); }
});
router.post('/', requireLogin, requirePermission(S, 'add'), audit('create', T), async (req, res, next) => { try { res.status(201).json({ data: await svc.create(req.body, req) }); } catch (e) { next(e); } });
router.post('/:id/received', requireLogin, requirePermission(S, 'edit'), audit('update', T), async (req, res, next) => { try { await svc.markReceived(Number(req.params.id), req); res.json({ ok: true }); } catch (e) { next(e); } });
router.delete('/:id', requireLogin, requirePermission(S, 'remove'), audit('delete', T), async (req, res, next) => { try { await svc.remove(Number(req.params.id), req, req.query.box === 'received' ? 'received' : 'sent'); res.json({ ok: true }); } catch (e) { next(e); } });
module.exports = router;
