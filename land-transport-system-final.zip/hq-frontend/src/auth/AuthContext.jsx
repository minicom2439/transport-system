// src/auth/AuthContext.jsx
import { createContext, useContext, useEffect, useState, useCallback } from 'react';
import * as authApi from '../api/auth';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [access, setAccess] = useState(null);
  const [loading, setLoading] = useState(true);

  // Restore session on first load.
  useEffect(() => {
    authApi.me()
      .then((res) => { setUser(res.user); setAccess(res.access); })
      .catch(() => { setUser(null); setAccess(null); })
      .finally(() => setLoading(false));
  }, []);

  const signIn = useCallback(async (username, password) => {
    await authApi.login(username, password);
    const res = await authApi.me();           // re-fetch to get access details
    setUser(res.user); setAccess(res.access);
    return res.user;
  }, []);

  const signOut = useCallback(async () => {
    try { await authApi.logout(); } finally { setUser(null); setAccess(null); }
  }, []);

  // Mirror of the backend permission check: super admin passes everything,
  // otherwise the "section:action" string must be present.
  const can = useCallback((section, action) => {
    if (!access) return false;
    if (access.isSuperAdmin) return true;
    return access.permissions?.includes(`${section}:${action}`) || false;
  }, [access]);

  return (
    <AuthContext.Provider value={{ user, access, loading, signIn, signOut, can }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
