import CrudScreen from '../components/CrudScreen';
import { financeApi } from '../api/landops';
import { useLookups } from '../utils/useLookups';
import { treeFromOptions } from '../utils/treeNodes';
const DIRECTION = [{ value: 1, label: 'Income' }, { value: 2, label: 'Expense' }];
export default function FinancePage() {
  const lookups = useLookups({ units: true, lookups: ['finance_categories'] });
  const n = (v) => (v == null ? '—' : Number(v).toLocaleString());
  return (<CrudScreen title="Manage Finance" subtitle="Financial records by unit." section="land_ops_finance" entityLabel="record" api={financeApi} initialSort="record_date" lookups={lookups}
    tree={{ filterKey: 'unit_id', title: 'Units', nodes: treeFromOptions(lookups.units, 'All units') }}
    columns={[
      { key: 'record_date', label: 'Date', width: 120, sortable: true },
      { key: 'unit_name', label: 'Unit', sortable: true, sortKey: 'unit', render: (r) => r.unit_name || '—' },
      { key: 'category_name', label: 'Category', sortable: true, sortKey: 'category', render: (r) => r.category_name || '—' },
      { key: 'direction', label: 'Type', width: 100, render: (r) => <span className={`pill ${r.direction === 2 ? 'pill-danger' : 'pill-ok'}`}>{r.direction === 2 ? 'Expense' : 'Income'}</span> },
      { key: 'amount', label: 'Amount', width: 130, align: 'right', sortable: true, render: (r) => n(r.amount) },
      { key: 'note', label: 'Note', render: (r) => r.note || '—' },
    ]}
    fields={[
      { key: 'unit_id', label: 'Unit', type: 'select', optionsKey: 'units' },
      { key: 'record_date', label: 'Date', type: 'date', required: true },
      { key: 'category_id', label: 'Category', type: 'select', optionsKey: 'finance_categories' },
      { key: 'direction', label: 'Type', type: 'select', options: DIRECTION },
      { key: 'amount', label: 'Amount', type: 'number', required: true },
      { key: 'note', label: 'Note', type: 'textarea', span: 2 },
    ]}
    toServerFilters={(f) => (f.unit_id ? [{ field: 'unit_id', op: 'eq', value: f.unit_id }] : [])} />);
}
