import CrudScreen from '../components/CrudScreen';
import { locationsApi } from '../api/scitech';
import { useLookups } from '../utils/useLookups';
import { treeFromOptions } from '../utils/treeNodes';
export default function VehicleLocationPage() {
  const lookups = useLookups({ units: true });
  const c = (v) => (v == null ? '—' : Number(v).toFixed(4));
  return (<CrudScreen title="Search Vehicle Location" subtitle="Recorded GPS positions per vehicle (read-only)." section="sci_location" entityLabel="ping" api={locationsApi} initialSort="recorded_at" readOnly lookups={lookups}
    tree={{ filterKey: 'unit_id', title: 'Units', nodes: treeFromOptions(lookups.units, 'All units') }}
    columns={[
      { key: 'vehicle_plate', label: 'Vehicle', width: 130, sortable: true, sortKey: 'vehicle', render: (r) => <strong>{r.vehicle_plate || '—'}</strong> },
      { key: 'unit_name', label: 'Unit', sortable: true, sortKey: 'unit', render: (r) => r.unit_name || '—' },
      { key: 'recorded_at', label: 'Recorded', width: 170, sortable: true, render: (r) => r.recorded_at },
      { key: 'latitude', label: 'Latitude', width: 110, align: 'right', render: (r) => c(r.latitude) },
      { key: 'longitude', label: 'Longitude', width: 110, align: 'right', render: (r) => c(r.longitude) },
      { key: 'speed', label: 'Speed (km/h)', width: 110, align: 'right', sortable: true, render: (r) => r.speed == null ? '—' : Number(r.speed) },
    ]}
    fields={[]}
    toServerFilters={(f) => (f.unit_id ? [{ field: 'unit_id', op: 'eq', value: f.unit_id }] : [])} />);
}
