import CrudScreen from '../components/CrudScreen';
import { gpsApi } from '../api/scitech';
import { useLookups } from '../utils/useLookups';
import { treeFromOptions } from '../utils/treeNodes';
export default function RegisterGpsPage() {
  const lookups = useLookups({ units: true, lookups: ['vehicles'] });
  return (<CrudScreen title="Register GPS" subtitle="GPS devices installed on vehicles." section="sci_gps" entityLabel="device" api={gpsApi} initialSort="device_no" lookups={lookups}
    tree={{ filterKey: 'unit_id', title: 'Units', nodes: treeFromOptions(lookups.units, 'All units') }}
    columns={[
      { key: 'device_no', label: 'Device no', sortable: true, filterable: true, render: (r) => <strong>{r.device_no}</strong> },
      { key: 'vehicle_plate', label: 'Vehicle', width: 130, sortable: true, sortKey: 'vehicle', render: (r) => r.vehicle_plate || '—' },
      { key: 'unit_name', label: 'Unit', sortable: true, sortKey: 'unit', render: (r) => r.unit_name || '—' },
      { key: 'installed_on', label: 'Installed', width: 130, sortable: true, render: (r) => r.installed_on || '—' },
    ]}
    fields={[
      { key: 'device_no', label: 'Device no', required: true },
      { key: 'vehicle_id', label: 'Vehicle', type: 'select', optionsKey: 'vehicles', required: true },
      { key: 'installed_on', label: 'Installed on', type: 'date' },
    ]}
    toServerFilters={(f) => { const s = []; if (f.device_no) s.push({ field: 'device_no', op: 'contains', value: f.device_no }); if (f.unit_id) s.push({ field: 'unit_id', op: 'eq', value: f.unit_id }); return s; }} />);
}
