// src/pages/UsersPage.jsx — user management on the table framework.
import { useEffect, useState, useCallback } from 'react';
import { useAuth } from '../auth/AuthContext';
import { useToast } from '../components/Toast';
import { useConfirm } from '../components/ConfirmDialog';
import { useDataTable } from '../utils/useDataTable';
import { listUsers, getUser, createUser, updateUser, removeUser } from '../api/users';
import { listRoles } from '../api/roles';
import { getUnitOptions, getSectionsAll } from '../api/admin';
import { getRegions } from '../api/meta';
import DataTable from '../components/DataTable';
import Modal from '../components/Modal';
import Field from '../components/Field';
import { Plus, Edit, Trash } from '../components/Icons';

const SECTION = 'admin_users';

function CheckList({ options, selected, onToggle, empty = 'None' }) {
  if (!options.length) return <div style={{ color: 'var(--ink-faint)', fontSize: 'var(--fs-sm)' }}>{empty}</div>;
  return (
    <div style={{ maxHeight: 130, overflow: 'auto', border: '1px solid var(--line)', borderRadius: 'var(--radius-sm)', padding: 6 }}>
      {options.map((o) => (
        <label key={o.value} style={{ display: 'flex', gap: 8, alignItems: 'center', padding: '3px 4px', fontSize: 'var(--fs-sm)', cursor: 'pointer' }}>
          <input type="checkbox" checked={selected.includes(o.value)} onChange={() => onToggle(o.value)} />
          {o.label}
        </label>
      ))}
    </div>
  );
}

export default function UsersPage() {
  const { can, user: me } = useAuth();
  const toast = useToast();
  const confirm = useConfirm();

  const [roleOptions, setRoleOptions] = useState([]);
  const [unitOptions, setUnitOptions] = useState([]);
  const [regionOptions, setRegionOptions] = useState([]);
  const [sectionOptions, setSectionOptions] = useState([]);

  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({});
  const [fieldErrors, setFieldErrors] = useState({});
  const [dirty, setDirty] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    listRoles({ limit: 200 }).then((r) => setRoleOptions(r.data.map((x) => ({ value: x.id, label: x.name })))).catch(() => {});
    getUnitOptions().then((r) => setUnitOptions(r.data.map((x) => ({ value: x.id, label: x.name })))).catch(() => {});
    getRegions().then((r) => { const flat = []; (function w(ns, p = '') { ns.forEach((n) => { flat.push({ value: n.id, label: p + n.name }); if (n.children) w(n.children, p + n.name + ' / '); }); })(r.data); setRegionOptions(flat); }).catch(() => {});
    getSectionsAll().then((r) => setSectionOptions(r.data.map((s) => ({ value: s.id, label: s.name })))).catch(() => {});
  }, []);

  const fetcher = useCallback(({ page, pageSize, sort, dir, q, filters }, opts) => {
    const sf = [];
    if (filters.username) sf.push({ field: 'username', op: 'contains', value: filters.username });
    if (filters.full_name) sf.push({ field: 'full_name', op: 'contains', value: filters.full_name });
    return listUsers({ page, limit: pageSize, sort, dir, q, filters: sf.length ? JSON.stringify(sf) : undefined }, opts);
  }, []);
  const table = useDataTable(fetcher, { initialSort: 'username' });

  const columns = [
    { key: 'username', label: 'Username', sortable: true, filterable: true, render: (r) => <strong>{r.username}</strong> },
    { key: 'full_name', label: 'Full name', sortable: true, filterable: true },
    { key: 'role_names', label: 'Roles', render: (r) => (r.role_names && r.role_names.length ? r.role_names.join(', ') : <span style={{ color: 'var(--ink-faint)' }}>—</span>) },
    { key: 'is_super_admin', label: 'Access', width: 130, render: (r) => r.is_super_admin ? <span className="pill pill-ok">Super admin</span> : <span className="pill pill-off">Standard</span> },
    { key: 'is_active', label: 'Status', width: 90, render: (r) => r.is_active ? <span className="pill pill-ok">Active</span> : <span className="pill pill-off">Inactive</span> },
  ];

  const openNew = () => { setEditing({}); setForm({ is_active: true, is_super_admin: false, roleIds: [], scopeUnitIds: [], scopeRegionIds: [], managedSectionIds: [] }); setFieldErrors({}); setDirty(false); };
  const openEdit = async (r) => {
    try {
      const full = (await getUser(r.id)).data;
      setEditing(full);
      setForm({
        full_name: full.full_name, is_active: !!full.is_active, is_super_admin: !!full.is_super_admin,
        roleIds: full.roleIds || [], managedSectionIds: full.managedSectionIds || [],
        scopeUnitIds: full.scopes.filter((s) => s.scope_type === 1).map((s) => s.scope_id),
        scopeRegionIds: full.scopes.filter((s) => s.scope_type === 2).map((s) => s.scope_id),
        password: '',
      });
      setFieldErrors({}); setDirty(false);
    } catch { toast.error('Could not load user.'); }
  };

  const change = (k, v) => { setForm((f) => ({ ...f, [k]: v })); setDirty(true); };
  const toggleIn = (k, v) => { setForm((f) => { const arr = f[k] || []; return { ...f, [k]: arr.includes(v) ? arr.filter((x) => x !== v) : [...arr, v] }; }); setDirty(true); };

  const requestClose = async () => {
    if (dirty && !(await confirm({ title: 'Discard changes?', message: 'You have unsaved changes. Discard them?', confirmLabel: 'Discard', danger: true }))) return;
    setEditing(null); setDirty(false); setFieldErrors({});
  };

  const save = async () => {
    setFieldErrors({}); setSaving(true);
    const body = {
      username: form.username, full_name: form.full_name, password: form.password || undefined,
      is_active: form.is_active, is_super_admin: form.is_super_admin,
      roleIds: form.roleIds, scopeUnitIds: form.scopeUnitIds, scopeRegionIds: form.scopeRegionIds, managedSectionIds: form.managedSectionIds,
    };
    try {
      if (editing.id) { await updateUser(editing.id, body); toast.success('User saved.'); }
      else { await createUser(body); toast.success('User created.'); }
      table.reload(); setEditing(null); setDirty(false);
    } catch (err) { if (err.fields) setFieldErrors(err.fields); else toast.error(err.message || 'Could not save.'); }
    finally { setSaving(false); }
  };

  const del = async (r) => {
    if (!(await confirm({ title: 'Deactivate user?', message: `Deactivate "${r.username}"? They will no longer be able to sign in.`, confirmLabel: 'Deactivate', danger: true }))) return;
    try { await removeUser(r.id); toast.success('User deactivated.'); table.reload(); } catch { toast.error('Could not deactivate.'); }
  };

  return (
    <div>
      <h1 style={{ fontSize: 'var(--fs-xl)' }}>Users</h1>
      <p style={{ color: 'var(--ink-soft)', margin: '2px 0 14px', fontSize: 'var(--fs-sm)' }}>Accounts, roles, and data access.</p>
      <div className="card" style={{ height: 'calc(100vh - var(--topbar-h) - 120px)', minHeight: 320, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
        <DataTable
          columns={columns}
          rows={table.rows} total={table.total} loading={table.loading} error={table.error} onRetry={table.reload}
          page={table.page} pageSize={table.pageSize} onPageChange={table.setPage} onPageSizeChange={table.setPageSize}
          sort={table.sort} dir={table.dir} onSort={table.toggleSort}
          filters={table.filters} onFilter={table.setFilter}
          q={table.q} onSearch={table.setQ}
          density={table.density} onDensityChange={table.setDensity}
          emptyText="No users match."
          toolbarRight={can(SECTION, 'add') && <button className="btn btn-sm btn-primary" onClick={openNew}><Plus /> New user</button>}
          rowActions={(r) => (
            <span style={{ display: 'inline-flex', gap: 6 }}>
              {can(SECTION, 'edit') && <button className="btn btn-sm btn-ghost" onClick={() => openEdit(r)} aria-label="Edit"><Edit /></button>}
              {can(SECTION, 'remove') && <button className="btn btn-sm btn-danger" onClick={() => del(r)} aria-label="Deactivate"><Trash /></button>}
            </span>
          )}
        />
      </div>

      <Modal open={!!editing} title={editing?.id ? `Edit ${editing.username}` : 'New user'} onClose={requestClose} width={560}
        footer={(<>
          <button className="btn" onClick={requestClose}>Cancel</button>
          <button className="btn btn-primary" disabled={saving} onClick={save}>{saving ? 'Saving…' : (editing?.id ? 'Save changes' : 'Create user')}</button>
        </>)}>
        {editing && (
          <form onSubmit={(e) => { e.preventDefault(); save(); }}>
            {!editing.id && (
              <Field label="Username" error={fieldErrors.username}>
                <input className="input" value={form.username || ''} onChange={(e) => change('username', e.target.value)} autoFocus />
              </Field>
            )}
            <Field label="Full name" error={fieldErrors.full_name}>
              <input className="input" value={form.full_name || ''} onChange={(e) => change('full_name', e.target.value)} />
            </Field>
            <Field label={editing.id ? 'Set new password (optional)' : 'Password'} error={fieldErrors.password}>
              <input className="input" type="password" value={form.password || ''} onChange={(e) => change('password', e.target.value)} placeholder={editing.id ? 'Leave blank to keep current' : ''} />
            </Field>
            <div style={{ display: 'flex', gap: 18, margin: '4px 0 14px' }}>
              <label style={{ display: 'flex', gap: 6, alignItems: 'center', fontSize: 'var(--fs-sm)' }}>
                <input type="checkbox" checked={!!form.is_active} onChange={(e) => change('is_active', e.target.checked)} /> Active
              </label>
              {me?.isSuperAdmin && (
                <label style={{ display: 'flex', gap: 6, alignItems: 'center', fontSize: 'var(--fs-sm)' }}>
                  <input type="checkbox" checked={!!form.is_super_admin} onChange={(e) => change('is_super_admin', e.target.checked)} /> Super admin
                </label>
              )}
            </div>
            {form.is_super_admin ? (
              <div style={{ color: 'var(--ink-soft)', fontSize: 'var(--fs-sm)', background: 'var(--surface-2)', padding: 10, borderRadius: 6 }}>
                Super admins bypass roles and data scope — full access to everything.
              </div>
            ) : (
              <>
                <Field label="Roles"><CheckList options={roleOptions} selected={form.roleIds || []} onToggle={(v) => toggleIn('roleIds', v)} empty="No roles defined yet." /></Field>
                <Field label="Data scope — units (blank = all)"><CheckList options={unitOptions} selected={form.scopeUnitIds || []} onToggle={(v) => toggleIn('scopeUnitIds', v)} /></Field>
                <Field label="Data scope — regions (blank = all)"><CheckList options={regionOptions} selected={form.scopeRegionIds || []} onToggle={(v) => toggleIn('scopeRegionIds', v)} /></Field>
                {me?.isSuperAdmin && <Field label="Manages sections (delegated admin)"><CheckList options={sectionOptions} selected={form.managedSectionIds || []} onToggle={(v) => toggleIn('managedSectionIds', v)} /></Field>}
              </>
            )}
          </form>
        )}
      </Modal>
    </div>
  );
}
