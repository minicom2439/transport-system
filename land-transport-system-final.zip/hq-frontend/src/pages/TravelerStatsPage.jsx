import CrudScreen from '../components/CrudScreen';
import { travelerStatsApi } from '../api/integration';
import { useLookups } from '../utils/useLookups';
import { treeFromOptions } from '../utils/treeNodes';
export default function TravelerStatsPage() {
  const lookups = useLookups({ units: true });
  const n = (v) => (v == null ? '0' : Number(v).toLocaleString());
  return (<CrudScreen title="Traveler Transport — View Data" subtitle="Passenger transport statistics per unit (read-only oversight)." section="integration_traveler_stats" entityLabel="row" api={travelerStatsApi} initialSort="stat_year" readOnly searchable={false} lookups={lookups}
    tree={{ filterKey: 'unit_id', title: 'Units', nodes: treeFromOptions(lookups.units, 'All units') }}
    columns={[
      { key: 'stat_year', label: 'Year', width: 80, sortable: true, filterable: true, render: (r) => r.stat_year },
      { key: 'period', label: 'Month', width: 80, render: (r) => String(r.stat_month).padStart(2, '0') },
      { key: 'unit_name', label: 'Unit', sortable: true, sortKey: 'unit', render: (r) => r.unit_name || '—' },
      { key: 'trips', label: 'Trips', align: 'right', sortable: true, render: (r) => n(r.trips) },
      { key: 'passengers_carried', label: 'Passengers', align: 'right', render: (r) => n(r.passengers_carried) },
      { key: 'distance_km', label: 'Distance (km)', align: 'right', render: (r) => n(r.distance_km) },
      { key: 'revenue', label: 'Revenue', align: 'right', sortable: true, render: (r) => n(r.revenue) },
    ]}
    fields={[]}
    toServerFilters={(f) => { const s = []; if (f.stat_year) s.push({ field: 'stat_year', op: 'eq', value: f.stat_year }); if (f.unit_id) s.push({ field: 'unit_id', op: 'eq', value: f.unit_id }); return s; }} />);
}
