import CrudScreen from '../components/CrudScreen';
import { programsApi } from '../api/infoservice';
export default function ProgramsPage() {
  return (<CrudScreen title="Relevant Programs" subtitle="Downloadable software and tools." section="info_programs" entityLabel="program" api={programsApi} initialSort="name"
    columns={[
      { key: 'name', label: 'Name', sortable: true, filterable: true, render: (r) => <strong>{r.name}</strong> },
      { key: 'version', label: 'Version', width: 120, sortable: true, render: (r) => r.version || '—' },
      { key: 'description', label: 'Description', render: (r) => r.description || '—' },
    ]}
    fields={[
      { key: 'name', label: 'Name', required: true, span: 2 },
      { key: 'version', label: 'Version' },
      { key: 'file_path', label: 'File path' },
      { key: 'description', label: 'Description', type: 'textarea', span: 2 },
    ]}
    toServerFilters={(f) => (f.name ? [{ field: 'name', op: 'contains', value: f.name }] : [])} />);
}
