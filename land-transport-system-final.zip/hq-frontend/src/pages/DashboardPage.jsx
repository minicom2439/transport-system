// src/pages/DashboardPage.jsx
import { useAuth } from '../auth/AuthContext';

export default function DashboardPage() {
  const { user } = useAuth();
  return (
    <div>
      <h1 style={{ fontSize: 'var(--fs-2xl)', marginBottom: 6 }}>Welcome, {user?.fullName}</h1>
      <p style={{ color: 'var(--ink-soft)', marginTop: 0 }}>
        Use the system rail on the left to open a screen. Your menu shows only what you have permission to view.
      </p>
      <div className="card" style={{ padding: 20, marginTop: 18, maxWidth: 640 }}>
        <h3 style={{ marginBottom: 8 }}>Getting started</h3>
        <p style={{ color: 'var(--ink-soft)', fontSize: 'var(--fs-sm)', margin: 0 }}>
          The Units, Vehicles, and Traveler Transport screens are wired to live data. Other screens appear in the
          rail as they are built, following the same tree-and-table pattern.
        </p>
      </div>
    </div>
  );
}
