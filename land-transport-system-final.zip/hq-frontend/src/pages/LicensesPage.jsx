import WorkflowScreen from '../components/WorkflowScreen';
import { licensesApi } from '../api/landops';
import { useLookups } from '../utils/useLookups';
import { treeFromOptions } from '../utils/treeNodes';
const STATUS_OPTS = ['draft', 'submitted', 'approved', 'rejected', 'cancelled'].map((s) => ({ value: s, label: s[0].toUpperCase() + s.slice(1) }));
export default function LicensesPage() {
  const lookups = useLookups({ units: true, lookups: ['license_types'] });
  return (<WorkflowScreen title="License Management" subtitle="Business & operation licenses with an approval workflow." section="land_ops_licenses" entityLabel="license" api={licensesApi} initialSort="license_no" lookups={lookups}
    tree={{ filterKey: 'unit_id', title: 'Units', nodes: treeFromOptions(lookups.units, 'All units') }}
    columns={[
      { key: 'license_no', label: 'License no', sortable: true, filterable: true, render: (r) => <strong>{r.license_no || '—'}</strong> },
      { key: 'license_type_name', label: 'Type', sortable: true, sortKey: 'type', render: (r) => r.license_type_name || '—' },
      { key: 'unit_name', label: 'Unit', sortable: true, sortKey: 'unit', render: (r) => r.unit_name || '—' },
      { key: 'validity', label: 'Validity', width: 170, render: (r) => `${r.valid_from || '—'} → ${r.valid_to || '—'}` },
      { key: 'status', label: 'Status', width: 110, filterable: true, filterType: 'select', options: STATUS_OPTS },
    ]}
    fields={[
      { key: 'license_no', label: 'License no' },
      { key: 'license_type_id', label: 'Type', type: 'select', optionsKey: 'license_types' },
      { key: 'unit_id', label: 'Unit', type: 'select', optionsKey: 'units', required: true },
      { key: 'valid_from', label: 'Valid from', type: 'date' },
      { key: 'valid_to', label: 'Valid to', type: 'date' },
    ]}
    toServerFilters={(f) => { const s = []; if (f.license_no) s.push({ field: 'license_no', op: 'contains', value: f.license_no }); if (f.status) s.push({ field: 'status', op: 'eq', value: f.status }); if (f.unit_id) s.push({ field: 'unit_id', op: 'eq', value: f.unit_id }); return s; }} />);
}
