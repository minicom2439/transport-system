// src/pages/RegisterPage.jsx — public self-registration (creates a pending request).
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { register } from '../api/auth';
import { Grid } from '../components/Icons';

export default function RegisterPage() {
  const [form, setForm] = useState({ username: '', full_name: '', position: '', mobile_phone: '', office_phone: '', certificate_id: '', password: '', note: '' });
  const [fieldErrors, setFieldErrors] = useState({});
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);

  const change = (k, v) => setForm((f) => ({ ...f, [k]: v }));
  const submit = async (e) => {
    e.preventDefault(); setFieldErrors({}); setBusy(true);
    try { await register(form); setDone(true); }
    catch (err) { if (err.fields) setFieldErrors(err.fields); else setFieldErrors({ _: err.message || 'Could not submit request.' }); }
    finally { setBusy(false); }
  };

  return (
    <div className="auth-screen">
      <div className="auth-stack">
        <div className="brand">
          <span className="brand-mark"><Grid /></span>
          <div className="brand-name">HQ Transport</div>
          <div className="brand-sub">Land Transport Management System</div>
        </div>

        {done ? (
          <div className="auth-card">
            <h2 className="auth-title">Request submitted</h2>
            <p style={{ color: 'var(--ink-soft)', fontSize: 'var(--fs-sm)' }}>
              Your account request has been sent to an administrator. You'll be able to sign in once it's approved.
            </p>
            <Link className="btn btn-primary" to="/login" style={{ width: '100%', marginTop: 12, height: 36, justifyContent: 'center' }}>Back to sign in</Link>
          </div>
        ) : (
          <form className="auth-card" onSubmit={submit}>
            <h2 className="auth-title">Request an account</h2>
            <p style={{ color: 'var(--ink-soft)', fontSize: 'var(--fs-sm)', marginTop: 0 }}>An administrator will review your request.</p>
            <label className="label">Username</label>
            <input className="input" value={form.username} onChange={(e) => change('username', e.target.value)} autoFocus />
            {fieldErrors.username && <div className="fe">{fieldErrors.username}</div>}
            <div style={{ height: 12 }} />
            <label className="label">Full name</label>
            <input className="input" value={form.full_name} onChange={(e) => change('full_name', e.target.value)} />
            {fieldErrors.full_name && <div className="fe">{fieldErrors.full_name}</div>}
            <div style={{ height: 12 }} />
            <label className="label">Workplace / position (optional)</label>
            <input className="input" value={form.position} onChange={(e) => change('position', e.target.value)} />
            <div style={{ height: 12 }} />
            <label className="label">Mobile number (optional)</label>
            <input className="input" value={form.mobile_phone} onChange={(e) => change('mobile_phone', e.target.value)} />
            <div style={{ height: 12 }} />
            <label className="label">Office phone (optional)</label>
            <input className="input" value={form.office_phone} onChange={(e) => change('office_phone', e.target.value)} />
            <div style={{ height: 12 }} />
            <label className="label">Electronic certificate (optional)</label>
            <input className="input" value={form.certificate_id} onChange={(e) => change('certificate_id', e.target.value)} />
            <div style={{ height: 12 }} />
            <label className="label">Password</label>
            <input className="input" type="password" value={form.password} onChange={(e) => change('password', e.target.value)} />
            {fieldErrors.password && <div className="fe">{fieldErrors.password}</div>}
            <div style={{ height: 12 }} />
            <label className="label">Note (optional)</label>
            <input className="input" value={form.note} onChange={(e) => change('note', e.target.value)} placeholder="e.g. which unit / role you need" />
            {fieldErrors._ && <div className="login-error">{fieldErrors._}</div>}
            <button className="btn btn-primary" style={{ width: '100%', marginTop: 16, height: 36 }} disabled={busy}>{busy ? 'Submitting…' : 'Submit request'}</button>
            <div style={{ textAlign: 'center', marginTop: 12, fontSize: 'var(--fs-sm)' }}><Link to="/login">Back to sign in</Link></div>
          </form>
        )}
      </div>
      <style>{`
        .auth-screen { min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 24px;
          background: radial-gradient(1200px 600px at 50% -10%, #15938a 0%, rgba(21,147,138,0) 60%),
            repeating-linear-gradient(0deg, rgba(255,255,255,.04) 0 1px, transparent 1px 40px),
            repeating-linear-gradient(90deg, rgba(255,255,255,.04) 0 1px, transparent 1px 40px), var(--accent); }
        .auth-stack { width: 100%; max-width: 380px; }
        .brand { text-align: center; color: #fff; margin-bottom: 22px; }
        .brand-mark { display: inline-flex; width: 56px; height: 56px; align-items: center; justify-content: center;
          background: rgba(255,255,255,.14); border: 1px solid rgba(255,255,255,.28); border-radius: 14px; margin-bottom: 14px; }
        .brand-mark svg { width: 28px; height: 28px; }
        .brand-name { font-size: 26px; font-weight: 750; letter-spacing: -0.02em; }
        .brand-sub { font-size: 13px; color: rgba(255,255,255,.82); margin-top: 4px; }
        .auth-card { background: var(--surface); border-radius: 12px; padding: 26px; box-shadow: 0 18px 50px rgba(10,40,38,.35); }
        .auth-title { font-size: 19px; }
        .fe { color: var(--danger); font-size: var(--fs-xs); margin-top: 4px; }
        .login-error { margin-top: 12px; padding: 8px 10px; background: var(--danger-soft); color: var(--danger); border-radius: var(--radius-sm); font-size: var(--fs-sm); }
      `}</style>
    </div>
  );
}
