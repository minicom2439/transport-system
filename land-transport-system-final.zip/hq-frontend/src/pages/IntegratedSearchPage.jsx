import { useEffect, useRef, useState } from 'react';
import { Search } from '../components/Icons';
import { searchApi } from '../api/insights';
const soft = { color: 'var(--ink-soft)' };
export default function IntegratedSearchPage() {
  const [q, setQ] = useState('');
  const [groups, setGroups] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);
  const t = useRef(null);
  useEffect(() => {
    if (t.current) clearTimeout(t.current);
    if (q.trim().length < 2) { setGroups([]); setSearched(false); return; }
    t.current = setTimeout(() => {
      setLoading(true);
      searchApi.run(q.trim()).then((res) => { setGroups(res.groups || []); setSearched(true); setLoading(false); }).catch(() => setLoading(false));
    }, 250);
    return () => t.current && clearTimeout(t.current);
  }, [q]);
  return (
    <div>
      <h1 style={{ fontSize: 'var(--fs-xl)' }}>Integrated Search</h1>
      <p style={{ ...soft, margin: '2px 0 14px', fontSize: 'var(--fs-sm)' }}>Search across units, vehicles, routes, equipment, notices and daily reports.</p>
      <div className="card" style={{ padding: 12, marginBottom: 12 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <Search /><input className="input" autoFocus placeholder="Type at least 2 characters…" value={q} onChange={(e) => setQ(e.target.value)} style={{ border: 'none', boxShadow: 'none' }} />
        </div>
      </div>
      {loading && <p style={soft}>Searching…</p>}
      {!loading && searched && groups.length === 0 && <p style={soft}>No matches for “{q}”.</p>}
      <div style={{ display: 'grid', gap: 12 }}>
        {groups.map((g) => (
          <div className="card" key={g.type} style={{ padding: 12 }}>
            <h3 style={{ margin: '0 0 8px' }}>{g.type} <span style={{ ...soft, fontWeight: 400 }}>({g.items.length})</span></h3>
            <ul style={{ margin: 0, paddingLeft: 18 }}>
              {g.items.map((it) => (<li key={it.id} style={{ padding: '2px 0' }}>{it.label}{it.sub ? <span style={soft}> — {it.sub}</span> : null}</li>))}
            </ul>
          </div>
        ))}
      </div>
    </div>
  );
}
