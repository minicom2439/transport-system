import CrudScreen from '../components/CrudScreen';
import { unitStatsApi } from '../api/landops';
import { useLookups } from '../utils/useLookups';
import { treeFromOptions } from '../utils/treeNodes';
export default function UnitStatsPage() {
  const lookups = useLookups({ units: true });
  const n = (v) => (v == null ? '0' : Number(v).toLocaleString());
  return (<CrudScreen title="Statistics per Unit" subtitle="Monthly transport statistics per unit (read-only). Every column filterable." section="land_ops_unit_stats" entityLabel="row" api={unitStatsApi} initialSort="stat_year" readOnly searchable={false} lookups={lookups}
    tree={{ filterKey: 'unit_id', title: 'Units', nodes: treeFromOptions(lookups.units, 'All units') }}
    columns={[
      { key: 'stat_year', label: 'Year', width: 90, sortable: true, filterable: true, render: (r) => r.stat_year },
      { key: 'period', label: 'Month', width: 90, render: (r) => String(r.stat_month).padStart(2, '0') },
      { key: 'unit_name', label: 'Unit', sortable: true, sortKey: 'unit', render: (r) => r.unit_name || '—' },
      { key: 'trips', label: 'Trips', align: 'right', sortable: true, render: (r) => n(r.trips) },
      { key: 'distance_km', label: 'Distance (km)', align: 'right', render: (r) => n(r.distance_km) },
      { key: 'passengers_carried', label: 'Passengers', align: 'right', render: (r) => n(r.passengers_carried) },
      { key: 'cargo_weight', label: 'Cargo (wt)', align: 'right', render: (r) => n(r.cargo_weight) },
      { key: 'revenue', label: 'Revenue', align: 'right', sortable: true, render: (r) => n(r.revenue) },
    ]}
    fields={[]}
    toServerFilters={(f) => { const s = []; if (f.stat_year) s.push({ field: 'stat_year', op: 'eq', value: f.stat_year }); if (f.unit_id) s.push({ field: 'unit_id', op: 'eq', value: f.unit_id }); return s; }} />);
}
