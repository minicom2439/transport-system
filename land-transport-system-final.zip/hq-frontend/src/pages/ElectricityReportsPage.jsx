import CrudScreen from '../components/CrudScreen';
import { electricityApi } from '../api/departments';
import { useLookups } from '../utils/useLookups';
import { treeFromOptions } from '../utils/treeNodes';
export default function ElectricityReportsPage() {
  const lookups = useLookups({ units: true });
  const n = (v) => (v == null ? '—' : Number(v).toLocaleString());
  return (<CrudScreen title="Electricity Daily Reports" subtitle="Daily electricity consumption per unit." section="pp_electricity" entityLabel="report" api={electricityApi} initialSort="report_date" lookups={lookups}
    tree={{ filterKey: 'unit_id', title: 'Units', nodes: treeFromOptions(lookups.units, 'All units') }}
    columns={[
      { key: 'report_date', label: 'Date', width: 130, sortable: true, render: (r) => r.report_date },
      { key: 'unit_name', label: 'Unit', sortable: true, sortKey: 'unit', render: (r) => r.unit_name || '—' },
      { key: 'consumption_kwh', label: 'Consumption (kWh)', align: 'right', sortable: true, render: (r) => n(r.consumption_kwh) },
      { key: 'peak_kwh', label: 'Peak (kWh)', align: 'right', render: (r) => n(r.peak_kwh) },
    ]}
    fields={[
      { key: 'unit_id', label: 'Unit', type: 'select', optionsKey: 'units' },
      { key: 'report_date', label: 'Date', type: 'date', required: true },
      { key: 'consumption_kwh', label: 'Consumption (kWh)', type: 'number' },
      { key: 'peak_kwh', label: 'Peak (kWh)', type: 'number' },
      { key: 'notes', label: 'Notes', type: 'textarea', span: 2 },
    ]}
    toServerFilters={(f) => (f.unit_id ? [{ field: 'unit_id', op: 'eq', value: f.unit_id }] : [])} />);
}
