import CrudScreen from '../components/CrudScreen';
import { equipmentInspectionsApi } from '../api/departments';
import { useLookups } from '../utils/useLookups';
import { treeFromOptions } from '../utils/treeNodes';
export default function EquipmentInspectionsPage() {
  const lookups = useLookups({ units: true, lookups: ['equipment'] });
  return (<CrudScreen title="Equipment Inspections" subtitle="Inspection records per unit." section="eqr_inspections" entityLabel="inspection" api={equipmentInspectionsApi} initialSort="inspection_date" lookups={lookups}
    tree={{ filterKey: 'unit_id', title: 'Units', nodes: treeFromOptions(lookups.units, 'All units') }}
    columns={[
      { key: 'inspection_date', label: 'Date', width: 130, sortable: true, render: (r) => r.inspection_date },
      { key: 'equipment_name', label: 'Equipment', sortable: true, sortKey: 'equipment', render: (r) => r.equipment_name || '—' },
      { key: 'unit_name', label: 'Unit', sortable: true, sortKey: 'unit', render: (r) => r.unit_name || '—' },
      { key: 'inspection_type', label: 'Type', render: (r) => r.inspection_type || '—' },
      { key: 'result', label: 'Result', width: 110, render: (r) => r.result ? <span className="pill pill-ok">{r.result}</span> : '—' },
    ]}
    fields={[
      { key: 'equipment_id', label: 'Equipment', type: 'select', optionsKey: 'equipment' },
      { key: 'unit_id', label: 'Unit', type: 'select', optionsKey: 'units' },
      { key: 'inspection_date', label: 'Date', type: 'date', required: true },
      { key: 'inspection_type', label: 'Type' },
      { key: 'result', label: 'Result' },
      { key: 'inspector', label: 'Inspector' },
      { key: 'notes', label: 'Notes', type: 'textarea', span: 2 },
    ]}
    toServerFilters={(f) => (f.unit_id ? [{ field: 'unit_id', op: 'eq', value: f.unit_id }] : [])} />);
}
