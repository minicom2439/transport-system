import CrudScreen from '../components/CrudScreen';
import { equipmentApi } from '../api/departments';
import { useLookups } from '../utils/useLookups';
import { treeFromOptions } from '../utils/treeNodes';
export default function EquipmentPage() {
  const lookups = useLookups({ units: true });
  return (<CrudScreen title="Equipment" subtitle="Equipment registry per unit." section="eqr_equipment" entityLabel="item" api={equipmentApi} initialSort="name" lookups={lookups}
    tree={{ filterKey: 'unit_id', title: 'Units', nodes: treeFromOptions(lookups.units, 'All units') }}
    columns={[
      { key: 'name', label: 'Equipment', sortable: true, filterable: true, render: (r) => <strong>{r.name}</strong> },
      { key: 'code', label: 'Code', width: 110, sortable: true, render: (r) => r.code || '—' },
      { key: 'unit_name', label: 'Unit', sortable: true, sortKey: 'unit', render: (r) => r.unit_name || '—' },
      { key: 'category', label: 'Category', render: (r) => r.category || '—' },
      { key: 'status', label: 'Status', width: 120, render: (r) => r.status ? <span className="pill pill-off">{r.status}</span> : '—' },
    ]}
    fields={[
      { key: 'name', label: 'Name', required: true, span: 2 },
      { key: 'unit_id', label: 'Unit', type: 'select', optionsKey: 'units' },
      { key: 'code', label: 'Code' },
      { key: 'category', label: 'Category' },
      { key: 'serial_no', label: 'Serial no' },
      { key: 'status', label: 'Status' },
      { key: 'registered_on', label: 'Registered on', type: 'date' },
    ]}
    toServerFilters={(f) => { const s = []; if (f.name) s.push({ field: 'name', op: 'contains', value: f.name }); if (f.unit_id) s.push({ field: 'unit_id', op: 'eq', value: f.unit_id }); return s; }} />);
}
