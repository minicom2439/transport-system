import CrudScreen from '../components/CrudScreen';
import { noAccidentApi } from '../api/departments';
import { useLookups } from '../utils/useLookups';
import { treeFromOptions } from '../utils/treeNodes';
export default function NoAccidentPage() {
  const lookups = useLookups({ units: true });
  return (<CrudScreen title="Register No Accident" subtitle="Accident-free day records per unit." section="eqr_no_accident" entityLabel="record" api={noAccidentApi} initialSort="as_of_date" lookups={lookups}
    tree={{ filterKey: 'unit_id', title: 'Units', nodes: treeFromOptions(lookups.units, 'All units') }}
    columns={[
      { key: 'as_of_date', label: 'As of', width: 130, sortable: true, render: (r) => r.as_of_date },
      { key: 'unit_name', label: 'Unit', sortable: true, sortKey: 'unit', render: (r) => r.unit_name || '—' },
      { key: 'accident_free_days', label: 'Accident-free days', align: 'right', sortable: true, render: (r) => r.accident_free_days ?? '—' },
      { key: 'notes', label: 'Notes', render: (r) => r.notes || '—' },
    ]}
    fields={[
      { key: 'unit_id', label: 'Unit', type: 'select', optionsKey: 'units' },
      { key: 'as_of_date', label: 'As of date', type: 'date', required: true },
      { key: 'accident_free_days', label: 'Accident-free days', type: 'number' },
      { key: 'notes', label: 'Notes', type: 'textarea', span: 2 },
    ]}
    toServerFilters={(f) => (f.unit_id ? [{ field: 'unit_id', op: 'eq', value: f.unit_id }] : [])} />);
}
