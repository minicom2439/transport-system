import CrudScreen from '../components/CrudScreen';
import { eInvoicesApi } from '../api/integration';
import { useLookups } from '../utils/useLookups';
import { treeFromOptions } from '../utils/treeNodes';
export default function EInvoicePage() {
  const lookups = useLookups({ units: true });
  const n = (v) => (v == null ? '—' : Number(v).toLocaleString());
  return (<CrudScreen title="Electronic Invoice" subtitle="Invoices across units (read-only oversight)." section="integration_einvoice" entityLabel="invoice" api={eInvoicesApi} initialSort="issued_at" readOnly lookups={lookups}
    tree={{ filterKey: 'unit_id', title: 'Units', nodes: treeFromOptions(lookups.units, 'All units') }}
    columns={[
      { key: 'invoice_no', label: 'Invoice no', sortable: true, filterable: true, render: (r) => <strong>{r.invoice_no}</strong> },
      { key: 'unit_name', label: 'Unit', sortable: true, sortKey: 'unit', render: (r) => r.unit_name || '—' },
      { key: 'issued_at', label: 'Issued', width: 120, sortable: true, render: (r) => r.issued_at || '—' },
      { key: 'amount', label: 'Amount', width: 120, align: 'right', sortable: true, render: (r) => n(r.amount) },
      { key: 'status_name', label: 'Status', width: 110, render: (r) => r.status_name || '—' },
    ]}
    fields={[]}
    toServerFilters={(f) => { const s = []; if (f.invoice_no) s.push({ field: 'invoice_no', op: 'contains', value: f.invoice_no }); if (f.unit_id) s.push({ field: 'unit_id', op: 'eq', value: f.unit_id }); return s; }} />);
}
