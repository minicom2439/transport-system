// src/pages/AccountRequestsPage.jsx — review and approve/reject pending sign-ups.
import { useEffect, useState, useCallback } from 'react';
import { useAuth } from '../auth/AuthContext';
import { useToast } from '../components/Toast';
import { useConfirm } from '../components/ConfirmDialog';
import { listRequests, approveRequest, rejectRequest } from '../api/requests';
import DataTable from '../components/DataTable';
import { Check, X } from '../components/Icons';

const SECTION = 'admin_requests';

export default function AccountRequestsPage() {
  const { can } = useAuth();
  const toast = useToast();
  const confirm = useConfirm();
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const load = useCallback(() => {
    setLoading(true); setError(null);
    listRequests().then((r) => setRows(r.data)).catch(setError).finally(() => setLoading(false));
  }, []);
  useEffect(() => { load(); }, [load]);

  const approve = async (r) => {
    if (!(await confirm({ title: 'Approve request?', message: `Approve "${r.username}"? An active account will be created.`, confirmLabel: 'Approve' }))) return;
    try { await approveRequest(r.id); toast.success(`${r.username} approved.`); load(); }
    catch (e) { toast.error(e.message || 'Could not approve.'); }
  };
  const reject = async (r) => {
    if (!(await confirm({ title: 'Reject request?', message: `Reject "${r.username}"? They will not get an account.`, confirmLabel: 'Reject', danger: true }))) return;
    try { await rejectRequest(r.id); toast.success(`${r.username} rejected.`); load(); }
    catch (e) { toast.error(e.message || 'Could not reject.'); }
  };

  const columns = [
    { key: 'username', label: 'Username', render: (r) => <strong>{r.username}</strong> },
    { key: 'full_name', label: 'Full name' },
    { key: 'note', label: 'Note', render: (r) => r.note || <span style={{ color: 'var(--ink-faint)' }}>—</span> },
    { key: 'requested_at', label: 'Requested', width: 170, render: (r) => new Date(r.requested_at).toLocaleString() },
  ];

  return (
    <div>
      <h1 style={{ fontSize: 'var(--fs-xl)' }}>Account requests</h1>
      <p style={{ color: 'var(--ink-soft)', margin: '2px 0 14px', fontSize: 'var(--fs-sm)' }}>People requesting access. Approve to create an active account.</p>
      <div className="card" style={{ height: 'calc(100vh - var(--topbar-h) - 120px)', minHeight: 320, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
        <DataTable
          columns={columns} rows={rows} total={rows.length} loading={loading} error={error} onRetry={load}
          emptyText="No pending requests."
          rowActions={can(SECTION, 'edit') ? (r) => (
            <span style={{ display: 'inline-flex', gap: 6 }}>
              <button className="btn btn-sm btn-primary" onClick={() => approve(r)}><Check /> Approve</button>
              <button className="btn btn-sm btn-danger" onClick={() => reject(r)}><X /> Reject</button>
            </span>
          ) : undefined}
        />
      </div>
    </div>
  );
}
