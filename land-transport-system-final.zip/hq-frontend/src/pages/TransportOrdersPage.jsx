import CrudScreen from '../components/CrudScreen';
import { ordersApi } from '../api/landops';
import { useLookups } from '../utils/useLookups';
import { treeFromOptions } from '../utils/treeNodes';
export default function TransportOrdersPage() {
  const lookups = useLookups({ units: true });
  return (<CrudScreen title="Transport Orders" subtitle="Orders received from the ordering system (read-only)." section="land_ops_orders" entityLabel="order" api={ordersApi} initialSort="order_date" readOnly lookups={lookups}
    tree={{ filterKey: 'unit_id', title: 'Transfer Units', nodes: treeFromOptions(lookups.units, 'All units') }}
    columns={[
      { key: 'order_no', label: 'Order no', sortable: true, filterable: true, render: (r) => <strong>{r.order_no}</strong> },
      { key: 'order_type_name', label: 'Type', render: (r) => r.order_type_name || '—' },
      { key: 'unit_name', label: 'Unit', sortable: true, sortKey: 'unit', render: (r) => r.unit_name || '—' },
      { key: 'corridor', label: 'Corridor', render: (r) => `${r.origin_region_name || '—'} → ${r.dest_region_name || '—'}` },
      { key: 'order_date', label: 'Date', width: 120, sortable: true },
      { key: 'status_name', label: 'Status', width: 110, render: (r) => r.status_name ? <span className="pill pill-off">{r.status_name}</span> : '—' },
      { key: 'amount', label: 'Amount', width: 110, align: 'right', render: (r) => r.amount != null ? Number(r.amount).toLocaleString() : '—' },
    ]}
    fields={[]}
    toServerFilters={(f) => { const s = []; if (f.order_no) s.push({ field: 'order_no', op: 'contains', value: f.order_no }); if (f.unit_id) s.push({ field: 'unit_id', op: 'eq', value: f.unit_id }); return s; }} />);
}
