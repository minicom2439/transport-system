import CrudScreen from '../components/CrudScreen';
import { financeStatsApi } from '../api/departments';
import { useLookups } from '../utils/useLookups';
import { treeFromOptions } from '../utils/treeNodes';
export default function FinanceStatsPage() {
  const lookups = useLookups({ units: true });
  const n = (v) => (v == null ? '—' : Number(v).toLocaleString());
  return (<CrudScreen title="Finance Statistics" subtitle="Financial records across units (read-only oversight)." section="fin_stats" entityLabel="record" api={financeStatsApi} initialSort="record_date" readOnly lookups={lookups}
    tree={{ filterKey: 'unit_id', title: 'Units', nodes: treeFromOptions(lookups.units, 'All units') }}
    columns={[
      { key: 'record_date', label: 'Date', width: 120, sortable: true },
      { key: 'unit_name', label: 'Unit', sortable: true, sortKey: 'unit', render: (r) => r.unit_name || '—' },
      { key: 'category_name', label: 'Category', sortable: true, sortKey: 'category', render: (r) => r.category_name || '—' },
      { key: 'direction', label: 'Type', width: 100, render: (r) => <span className={`pill ${r.direction === 2 ? 'pill-danger' : 'pill-ok'}`}>{r.direction === 2 ? 'Expense' : 'Income'}</span> },
      { key: 'amount', label: 'Amount', width: 130, align: 'right', sortable: true, render: (r) => n(r.amount) },
    ]}
    fields={[]}
    toServerFilters={(f) => (f.unit_id ? [{ field: 'unit_id', op: 'eq', value: f.unit_id }] : [])} />);
}
