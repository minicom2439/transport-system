import WorkflowScreen from '../components/WorkflowScreen';
import { effortPlansApi } from '../api/departments';
import { useLookups } from '../utils/useLookups';
import { treeFromOptions } from '../utils/treeNodes';
const STATUS_OPTS = ['draft', 'submitted', 'approved', 'rejected', 'cancelled'].map((s) => ({ value: s, label: s[0].toUpperCase() + s.slice(1) }));
export default function EffortPlansPage() {
  const lookups = useLookups({ units: true });
  const n = (v) => (v == null ? '—' : Number(v).toLocaleString());
  return (<WorkflowScreen title="Effort Plans" subtitle="Units submit production/effort plans; admins review and approve with directions." section="pp_effort" entityLabel="plan" api={effortPlansApi} initialSort="period" lookups={lookups} approveCommandLabel="Approve & direct"
    tree={{ filterKey: 'unit_id', title: 'Units', nodes: treeFromOptions(lookups.units, 'All units') }}
    columns={[
      { key: 'title', label: 'Plan', sortable: true, filterable: true, render: (r) => <strong>{r.title}</strong> },
      { key: 'period', label: 'Period', width: 110, sortable: true, render: (r) => r.period || '—' },
      { key: 'unit_name', label: 'Unit', sortable: true, sortKey: 'unit', render: (r) => r.unit_name || '—' },
      { key: 'target_value', label: 'Target', width: 100, align: 'right', render: (r) => n(r.target_value) },
      { key: 'actual_value', label: 'Actual', width: 100, align: 'right', render: (r) => n(r.actual_value) },
      { key: 'status', label: 'Status', width: 110, filterable: true, filterType: 'select', options: STATUS_OPTS },
      { key: 'command', label: 'Direction', render: (r) => r.command ? <span title={r.command}>{r.command.length > 40 ? r.command.slice(0, 40) + '…' : r.command}</span> : <span style={{ color: 'var(--ink-faint)' }}>—</span> },
    ]}
    fields={[
      { key: 'title', label: 'Title', required: true, span: 2 },
      { key: 'unit_id', label: 'Unit', type: 'select', optionsKey: 'units' },
      { key: 'period', label: 'Period (e.g. 2026-Q3)', required: true },
      { key: 'target_value', label: 'Target', type: 'number' },
      { key: 'actual_value', label: 'Actual', type: 'number' },
      { key: 'notes', label: 'Notes', type: 'textarea', span: 2 },
    ]}
    toServerFilters={(f) => { const s = []; if (f.title) s.push({ field: 'title', op: 'contains', value: f.title }); if (f.status) s.push({ field: 'status', op: 'eq', value: f.status }); if (f.unit_id) s.push({ field: 'unit_id', op: 'eq', value: f.unit_id }); return s; }} />);
}
