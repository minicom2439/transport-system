import CrudScreen from '../components/CrudScreen';
import { schedulesApi } from '../api/landops';
import { useLookups } from '../utils/useLookups';
import { treeFromOptions } from '../utils/treeNodes';
export default function SchedulesPage() {
  const lookups = useLookups({ units: true, lookups: ['schedule_types', 'parks', 'routes'] });
  return (<CrudScreen title="Schedules" subtitle="Bus schedules (daily and fixed)." section="land_ops_schedules" entityLabel="schedule" api={schedulesApi} initialSort="schedule_date" lookups={lookups}
    tree={{ filterKey: 'park_id', title: 'Parks', nodes: treeFromOptions(lookups.parks, 'All parks') }}
    toServerFilters={(f) => (f.park_id ? [{ field: 'park_id', op: 'eq', value: f.park_id }] : [])}
    columns={[
      { key: 'schedule_type_name', label: 'Type', sortable: true, sortKey: 'type', render: (r) => r.schedule_type_name || '—' },
      { key: 'unit_name', label: 'Unit', sortable: true, sortKey: 'unit', render: (r) => r.unit_name || '—' },
      { key: 'route_no', label: 'Route', width: 110, render: (r) => r.route_no || '—' },
      { key: 'schedule_date', label: 'Date', width: 120, sortable: true },
      { key: 'window', label: 'Window', render: (r) => `${r.start_time || '—'}–${r.end_time || '—'}` },
    ]}
    fields={[
      { key: 'schedule_type_id', label: 'Schedule type', type: 'select', optionsKey: 'schedule_types', required: true },
      { key: 'unit_id', label: 'Unit', type: 'select', optionsKey: 'units' },
      { key: 'park_id', label: 'Park', type: 'select', optionsKey: 'parks' },
      { key: 'route_id', label: 'Route', type: 'select', optionsKey: 'routes' },
      { key: 'schedule_date', label: 'Date', type: 'date' },
      { key: 'start_time', label: 'Start time (HH:MM)' },
      { key: 'end_time', label: 'End time (HH:MM)' },
      { key: 'notes', label: 'Notes', type: 'textarea', span: 2 },
    ]} />);
}
