import CrudScreen from '../components/CrudScreen';
import { invoicesApi } from '../api/vehicleadmin';
import { useLookups } from '../utils/useLookups';
export default function InvoicesPage() {
  const lookups = useLookups({ units: true });
  const n = (v) => (v == null ? '—' : Number(v).toLocaleString());
  return (<CrudScreen title="Invoices" subtitle="Billing records." section="vehicle_admin_invoices" entityLabel="invoice" api={invoicesApi} initialSort="issued_at" lookups={lookups}
    columns={[
      { key: 'invoice_no', label: 'Invoice no', sortable: true, filterable: true, render: (r) => <strong>{r.invoice_no}</strong> },
      { key: 'unit_name', label: 'Unit', sortable: true, sortKey: 'unit', render: (r) => r.unit_name || '—' },
      { key: 'issued_at', label: 'Issued', width: 120, sortable: true, render: (r) => r.issued_at || '—' },
      { key: 'amount', label: 'Amount', width: 120, align: 'right', sortable: true, render: (r) => n(r.amount) },
      { key: 'status_name', label: 'Status', width: 110, render: (r) => r.status_name || '—' },
    ]}
    fields={[
      { key: 'invoice_no', label: 'Invoice no', required: true },
      { key: 'unit_id', label: 'Unit', type: 'select', optionsKey: 'units' },
      { key: 'amount', label: 'Amount', type: 'number' },
      { key: 'issued_at', label: 'Issued at', type: 'date' },
      { key: 'order_id', label: 'Order ID (optional)', type: 'number' },
    ]}
    toServerFilters={(f) => (f.invoice_no ? [{ field: 'invoice_no', op: 'contains', value: f.invoice_no }] : [])} />);
}
