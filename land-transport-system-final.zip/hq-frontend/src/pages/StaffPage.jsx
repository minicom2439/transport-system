import CrudScreen from '../components/CrudScreen';
import { staffApi } from '../api/staff';
import { useLookups } from '../utils/useLookups';
import { treeFromOptions } from '../utils/treeNodes';

export default function StaffPage() {
  const lookups = useLookups({ units: true });
  return (
    <CrudScreen
      title="Manage Staffs" subtitle="Personnel by unit." section="other_staff" entityLabel="staff member"
      api={staffApi} initialSort="full_name" lookups={lookups}
      tree={{ filterKey: 'unit_id', title: 'Units', nodes: treeFromOptions(lookups.units, 'All units') }}
      columns={[
        { key: 'full_name', label: 'Name', sortable: true, filterable: true, render: (r) => <strong>{r.full_name}</strong> },
        { key: 'staff_no', label: 'Staff no', width: 120, sortable: true, render: (r) => r.staff_no || '—' },
        { key: 'position', label: 'Position', sortable: true, filterable: true, render: (r) => r.position || '—' },
        { key: 'unit_name', label: 'Unit', sortable: true, sortKey: 'unit', render: (r) => r.unit_name || '—' },
        { key: 'date_joined', label: 'Joined', width: 120, render: (r) => r.date_joined || '—' },
      ]}
      fields={[
        { key: 'full_name', label: 'Full name', required: true, span: 2 },
        { key: 'unit_id', label: 'Unit', type: 'select', optionsKey: 'units', required: true },
        { key: 'staff_no', label: 'Staff no' },
        { key: 'position', label: 'Position' },
        { key: 'phone', label: 'Phone' },
        { key: 'date_joined', label: 'Date joined', type: 'date' },
      ]}
      toServerFilters={(f) => {
        const s = [];
        if (f.full_name) s.push({ field: 'full_name', op: 'contains', value: f.full_name });
        if (f.position) s.push({ field: 'position', op: 'contains', value: f.position });
        if (f.unit_id) s.push({ field: 'unit_id', op: 'eq', value: f.unit_id });
        return s;
      }}
    />
  );
}
