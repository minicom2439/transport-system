import WorkflowScreen from '../components/WorkflowScreen';
import { conditionsApi } from '../api/landops';
import { useLookups } from '../utils/useLookups';
import { treeFromOptions } from '../utils/treeNodes';
const STATUS_OPTS = ['draft', 'submitted', 'approved', 'rejected', 'cancelled'].map((s) => ({ value: s, label: s[0].toUpperCase() + s.slice(1) }));
export default function OperatingConditionsPage() {
  const lookups = useLookups({ units: true });
  return (<WorkflowScreen title="Operating Conditions" subtitle="Business/operating conditions per unit, with an approval workflow." section="land_ops_conditions" entityLabel="condition" api={conditionsApi} initialSort="title" lookups={lookups}
    tree={{ filterKey: 'unit_id', title: 'Units', nodes: treeFromOptions(lookups.units, 'All units') }}
    columns={[
      { key: 'title', label: 'Condition', sortable: true, filterable: true, render: (r) => <strong>{r.title}</strong> },
      { key: 'unit_name', label: 'Unit', sortable: true, sortKey: 'unit', render: (r) => r.unit_name || '—' },
      { key: 'validity', label: 'Validity', width: 170, render: (r) => `${r.valid_from || '—'} → ${r.valid_to || '—'}` },
      { key: 'modes', label: 'Modes', width: 110, render: (r) => (<span style={{ display: 'inline-flex', gap: 4 }}>{r.allows_passenger ? <span className="pill pill-accent">Pax</span> : null}{r.allows_cargo ? <span className="pill pill-accent">Cargo</span> : null}{!r.allows_passenger && !r.allows_cargo ? '—' : null}</span>) },
      { key: 'status', label: 'Status', width: 110, filterable: true, filterType: 'select', options: STATUS_OPTS },
    ]}
    fields={[
      { key: 'title', label: 'Title', required: true, span: 2 },
      { key: 'unit_id', label: 'Unit', type: 'select', optionsKey: 'units', required: true },
      { key: 'scope_description', label: 'Scope / terms', type: 'textarea', span: 2 },
      { key: 'valid_from', label: 'Valid from', type: 'date' },
      { key: 'valid_to', label: 'Valid to', type: 'date' },
      { key: 'allowed_vehicle_count', label: 'Vehicles', type: 'number' },
      { key: 'allows_passenger', label: 'Passenger', type: 'checkbox' },
      { key: 'allows_cargo', label: 'Cargo', type: 'checkbox' },
    ]}
    toServerFilters={(f) => { const s = []; if (f.title) s.push({ field: 'title', op: 'contains', value: f.title }); if (f.status) s.push({ field: 'status', op: 'eq', value: f.status }); return s; }} />);
}
