import CrudScreen from '../components/CrudScreen';
import { onlineApi } from '../api/landops';
import { useLookups } from '../utils/useLookups';
import { treeFromOptions } from '../utils/treeNodes';
export default function NetworkOnlinePage() {
  const lookups = useLookups({ units: true });
  return (<CrudScreen title="Network Online State" subtitle="Online status per registered unit (read-only)." section="land_ops_online" entityLabel="unit" api={onlineApi} initialSort="unit" readOnly searchable={false} lookups={lookups}
    tree={{ filterKey: 'unit_id', title: 'Registered Units', nodes: treeFromOptions(lookups.units, 'All units') }}
    columns={[
      { key: 'unit_name', label: 'Unit', sortable: true, sortKey: 'unit', render: (r) => r.unit_name || '—' },
      { key: 'is_online', label: 'State', width: 130, render: (r) => <span className={`pill ${r.is_online ? 'pill-ok' : 'pill-off'}`}>{r.is_online ? 'Online' : 'Offline'}</span> },
      { key: 'last_seen_at', label: 'Last seen', width: 180, sortable: true, render: (r) => r.last_seen_at || '—' },
    ]}
    fields={[]}
    toServerFilters={(f) => (f.unit_id ? [{ field: 'unit_id', op: 'eq', value: f.unit_id }] : [])} />);
}
