// src/pages/UnitsPage.jsx — reference screen built on the table framework:
// server-side sort/filter/search, selection + bulk delete, modal editor with
// validation + dirty guard + "save & add another", toasts and confirm dialogs.
import { useEffect, useState, useCallback } from 'react';
import { useAuth } from '../auth/AuthContext';
import { useToast } from '../components/Toast';
import { useConfirm } from '../components/ConfirmDialog';
import { useDataTable } from '../utils/useDataTable';
import { getRegions } from '../api/meta';
import { listUnits, createUnit, updateUnit, removeUnit } from '../api/units';
import TreeView from '../components/TreeView';
import DataTable from '../components/DataTable';
import Modal from '../components/Modal';
import Field from '../components/Field';
import { exportToExcel } from '../utils/exportExcel';
import { Plus, Edit, Trash, Download } from '../components/Icons';

const SECTION = 'land_ops_units';

export default function UnitsPage() {
  const { can } = useAuth();
  const toast = useToast();
  const confirm = useConfirm();

  const [regions, setRegions] = useState([]);
  const [treeOpen, setTreeOpen] = useState(true);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({});
  const [fieldErrors, setFieldErrors] = useState({});
  const [dirty, setDirty] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => { getRegions().then((r) => setRegions(r.data)).catch(() => {}); }, []);

  const fetcher = useCallback(({ page, pageSize, sort, dir, q, filters }, opts) => {
    const sf = [];
    if (filters.name) sf.push({ field: 'name', op: 'contains', value: filters.name });
    if (filters.code) sf.push({ field: 'code', op: 'contains', value: filters.code });
    if (filters.region_id) sf.push({ field: 'region_id', op: 'eq', value: Number(filters.region_id) });
    return listUnits({ page, limit: pageSize, sort, dir, q, filters: sf.length ? JSON.stringify(sf) : undefined }, opts);
  }, []);

  const table = useDataTable(fetcher, { initialSort: 'name' });

  const flatRegions = [];
  (function walk(nodes, prefix = '') { nodes.forEach((n) => { flatRegions.push({ id: n.id, label: prefix + n.name }); if (n.children) walk(n.children, prefix + n.name + ' / '); }); })(regions);

  const columns = [
    { key: 'name', label: 'Unit', sortable: true, filterable: true, render: (r) => <strong>{r.name}</strong> },
    { key: 'code', label: 'Code', width: 120, sortable: true, filterable: true, render: (r) => r.code || '—' },
    { key: 'region', label: 'Region', width: 160, sortable: true, sortKey: 'region', render: (r) => r.region_name || '—' },
    { key: 'classification', label: 'Class', width: 120, sortable: true, sortKey: 'classification', render: (r) => r.classification_name || '—' },
  ];

  const openNew = () => { setEditing({}); setForm({ region_id: table.filters.region_id || '' }); setFieldErrors({}); setDirty(false); };
  const openEdit = (r) => { setEditing(r); setForm({ name: r.name, code: r.code || '', region_id: r.region_id }); setFieldErrors({}); setDirty(false); };

  const change = (k, v) => { setForm((f) => ({ ...f, [k]: v })); setDirty(true); };

  const requestClose = async () => {
    if (dirty) {
      const ok = await confirm({ title: 'Discard changes?', message: 'You have unsaved changes. Discard them?', confirmLabel: 'Discard', danger: true });
      if (!ok) return;
    }
    setEditing(null); setDirty(false); setFieldErrors({});
  };

  const save = async (addAnother) => {
    setFieldErrors({}); setSaving(true);
    const body = { name: form.name, code: form.code || null, region_id: form.region_id ? Number(form.region_id) : null };
    try {
      if (editing.id) { await updateUnit(editing.id, body); toast.success('Unit saved.'); }
      else { await createUnit(body); toast.success('Unit created.'); }
      table.reload();
      if (addAnother && !editing.id) { setForm({ region_id: form.region_id }); setDirty(false); }
      else { setEditing(null); setDirty(false); }
    } catch (err) {
      if (err.fields) { setFieldErrors(err.fields); }
      else toast.error(err.message || 'Could not save.');
    } finally { setSaving(false); }
  };

  const del = async (row) => {
    const ok = await confirm({ title: 'Remove unit?', message: `Remove "${row.name}"? It will be hidden from lists.`, confirmLabel: 'Remove', danger: true });
    if (!ok) return;
    try { await removeUnit(row.id); toast.success('Unit removed.'); table.reload(); }
    catch (e) { toast.error('Could not remove unit.'); }
  };

  const bulkDelete = async () => {
    const ids = [...table.selected];
    const ok = await confirm({ title: 'Remove selected?', message: `Remove ${ids.length} unit(s)? They will be hidden from lists.`, confirmLabel: 'Remove all', danger: true });
    if (!ok) return;
    try { await Promise.all(ids.map((id) => removeUnit(id))); toast.success(`${ids.length} unit(s) removed.`); table.clearSelection(); table.reload(); }
    catch (e) { toast.error('Could not remove some units.'); }
  };

  const selectedRegionName = flatRegions.find((r) => String(r.id) === String(table.filters.region_id))?.label;

  return (
    <div className="page">
      <div className="page-head">
        <div>
          <h1 style={{ fontSize: 'var(--fs-xl)' }}>Units</h1>
          <p className="page-sub">Subordinate transport enterprises.</p>
        </div>
      </div>

      <div className={`master-detail card${treeOpen ? '' : ' tree-collapsed'}`}>
        <aside className="md-left">
          <TreeView
            header="Regions"
            nodes={[{ id: 0, name: 'All regions', children: regions }]}
            selectedId={Number(table.filters.region_id) || 0}
            onSelect={(n) => table.setFilter('region_id', n.id === 0 ? '' : n.id)}
          />
        </aside>
        <section className="md-right">
          <div className="md-toolbar">
            <button className="btn btn-sm btn-ghost" onClick={() => setTreeOpen((v) => !v)}>{treeOpen ? '◂ Hide regions' : '▸ Regions'}</button>
            {selectedRegionName && <span className="md-context">Region: <strong>{selectedRegionName}</strong></span>}
          </div>
          <DataTable
            columns={columns}
            rows={table.rows} total={table.total} loading={table.loading} error={table.error} onRetry={table.reload}
            page={table.page} pageSize={table.pageSize} onPageChange={table.setPage} onPageSizeChange={table.setPageSize}
            sort={table.sort} dir={table.dir} onSort={table.toggleSort}
            filters={table.filters} onFilter={table.setFilter}
            q={table.q} onSearch={table.setQ}
            density={table.density} onDensityChange={table.setDensity}
            selectable={can(SECTION, 'remove')}
            selected={table.selected} onToggleSelect={table.toggleSelect} onToggleSelectAll={table.toggleSelectAll} allSelected={table.allSelected}
            bulkBar={<button className="btn btn-sm btn-danger" onClick={bulkDelete}>Remove selected</button>}
            emptyText="No units match. Adjust filters or create one."
            toolbarRight={(
              <>
                {can(SECTION, 'export') && <button className="btn btn-sm" onClick={() => exportToExcel('units', columns.map((c) => ({ label: c.label, value: (r) => c.key === 'region' ? r.region_name : c.key === 'classification' ? r.classification_name : r[c.key] })), table.rows)}><Download /> Export</button>}
                {can(SECTION, 'add') && <button className="btn btn-sm btn-primary" onClick={openNew}><Plus /> New unit</button>}
              </>
            )}
            rowActions={(r) => (
              <span style={{ display: 'inline-flex', gap: 6 }}>
                {can(SECTION, 'edit') && <button className="btn btn-sm btn-ghost" onClick={() => openEdit(r)} aria-label="Edit"><Edit /></button>}
                {can(SECTION, 'remove') && <button className="btn btn-sm btn-danger" onClick={() => del(r)} aria-label="Remove"><Trash /></button>}
              </span>
            )}
          />
        </section>
      </div>

      <Modal
        open={!!editing}
        title={editing?.id ? 'Edit unit' : 'New unit'}
        onClose={requestClose}
        footer={(
          <>
            <button className="btn" onClick={requestClose}>Cancel</button>
            {!editing?.id && <button className="btn" disabled={saving} onClick={() => save(true)}>Save & add another</button>}
            <button className="btn btn-primary" disabled={saving} onClick={() => save(false)}>{saving ? 'Saving…' : (editing?.id ? 'Save changes' : 'Create unit')}</button>
          </>
        )}
      >
        {editing && (
          <form onSubmit={(e) => { e.preventDefault(); save(false); }}>
            <Field label="Name" error={fieldErrors.name}>
              <input className="input" value={form.name || ''} onChange={(e) => change('name', e.target.value)} autoFocus />
            </Field>
            <Field label="Code" error={fieldErrors.code}>
              <input className="input" value={form.code || ''} onChange={(e) => change('code', e.target.value)} />
            </Field>
            <Field label="Region" error={fieldErrors.region_id}>
              <select className="input" value={form.region_id || ''} onChange={(e) => change('region_id', e.target.value)}>
                <option value="">Select region…</option>
                {flatRegions.map((o) => <option key={o.id} value={o.id}>{o.label}</option>)}
              </select>
            </Field>
          </form>
        )}
      </Modal>

      <style>{`
        .page-head { margin-bottom: 14px; }
        .page-sub { color: var(--ink-soft); margin: 2px 0 0; font-size: var(--fs-sm); }
        .master-detail { display: grid; grid-template-columns: 240px 1fr; height: calc(100vh - var(--topbar-h) - 116px); overflow: hidden; transition: grid-template-columns .16s ease; }
        .master-detail.tree-collapsed { grid-template-columns: 0 1fr; }
        .md-left { border-right: 1px solid var(--line); overflow: auto; min-width: 0; }
        .master-detail.tree-collapsed .md-left { border-right: none; }
        .md-right { min-width: 0; display: flex; flex-direction: column; }
        .md-toolbar { display: flex; align-items: center; gap: 12px; padding: 6px 8px; border-bottom: 1px solid var(--line); background: var(--surface-2); }
        .md-context { font-size: var(--fs-sm); color: var(--ink-soft); }
        @media (max-width: 760px) { .master-detail, .master-detail.tree-collapsed { grid-template-columns: 1fr; } .md-left { display: none; } }
      `}</style>
    </div>
  );
}
