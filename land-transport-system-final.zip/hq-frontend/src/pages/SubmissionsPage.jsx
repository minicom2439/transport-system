import WorkflowScreen from '../components/WorkflowScreen';
import { submissionsApi } from '../api/infoservice';
import { useLookups } from '../utils/useLookups';
import { treeFromOptions } from '../utils/treeNodes';
const STATUS_OPTS = ['draft', 'submitted', 'approved', 'rejected', 'cancelled'].map((s) => ({ value: s, label: s[0].toUpperCase() + s.slice(1) }));
export default function SubmissionsPage() {
  const lookups = useLookups({ units: true });
  return (<WorkflowScreen title="Data Submissions" subtitle="Units submit science & technology data; admins review and instruct." section="info_submissions" entityLabel="submission" api={submissionsApi} initialSort="submitted_at" lookups={lookups} approveCommandLabel="Review & instruct"
    tree={{ filterKey: 'unit_id', title: 'Units', nodes: treeFromOptions(lookups.units, 'All units') }}
    columns={[
      { key: 'title', label: 'Title', sortable: true, filterable: true, render: (r) => <strong>{r.title}</strong> },
      { key: 'unit_name', label: 'Unit', sortable: true, sortKey: 'unit', render: (r) => r.unit_name || '—' },
      { key: 'submitted_at', label: 'Submitted', width: 130, sortable: true, render: (r) => (r.submitted_at || '').slice(0, 10) || '—' },
      { key: 'status', label: 'Status', width: 110, filterable: true, filterType: 'select', options: STATUS_OPTS },
      { key: 'command', label: 'Instruction', render: (r) => r.command ? <span title={r.command}>{r.command.length > 50 ? r.command.slice(0, 50) + '…' : r.command}</span> : <span style={{ color: 'var(--ink-faint)' }}>—</span> },
    ]}
    fields={[
      { key: 'title', label: 'Title', required: true, span: 2 },
      { key: 'unit_id', label: 'Unit', type: 'select', optionsKey: 'units' },
      { key: 'file_path', label: 'File path / reference', span: 2 },
    ]}
    toServerFilters={(f) => { const s = []; if (f.title) s.push({ field: 'title', op: 'contains', value: f.title }); if (f.status) s.push({ field: 'status', op: 'eq', value: f.status }); if (f.unit_id) s.push({ field: 'unit_id', op: 'eq', value: f.unit_id }); return s; }} />);
}
