import WorkflowScreen from '../components/WorkflowScreen';
import { reportsApi } from '../api/landops';
import { useLookups } from '../utils/useLookups';
const STATUS_OPTS = ['draft', 'submitted', 'approved', 'rejected', 'cancelled'].map((s) => ({ value: s, label: s[0].toUpperCase() + s.slice(1) }));
export default function ReportsPage() {
  const lookups = useLookups({ lookups: ['report_types'] });
  return (<WorkflowScreen title="Business Reports" subtitle="Units write and submit business reports; admins review and issue instructions." section="land_ops_reports" entityLabel="report" api={reportsApi} initialSort="report_date" lookups={lookups} approveCommandLabel="Review & instruct"
    columns={[
      { key: 'title', label: 'Title', sortable: true, filterable: true, render: (r) => <strong>{r.title || '—'}</strong> },
      { key: 'report_type_name', label: 'Type', sortable: true, sortKey: 'type', render: (r) => r.report_type_name || '—' },
      { key: 'report_date', label: 'Date', width: 116, sortable: true },
      { key: 'status', label: 'Status', width: 110, filterable: true, filterType: 'select', options: STATUS_OPTS },
      { key: 'command', label: 'Instruction', render: (r) => r.command ? <span title={r.command}>{r.command.length > 60 ? r.command.slice(0, 60) + '…' : r.command}</span> : <span style={{ color: 'var(--ink-faint)' }}>—</span> },
    ]}
    fields={[
      { key: 'title', label: 'Title', required: true, span: 2 },
      { key: 'report_type_id', label: 'Report type', type: 'select', optionsKey: 'report_types' },
      { key: 'report_date', label: 'Report date', type: 'date', required: true },
      { key: 'period', label: 'Period (e.g. 2026-06)' },
      { key: 'content', label: 'Content', type: 'textarea', span: 2 },
    ]}
    toServerFilters={(f) => { const s = []; if (f.title) s.push({ field: 'title', op: 'contains', value: f.title }); if (f.status) s.push({ field: 'status', op: 'eq', value: f.status }); return s; }} />);
}
