import CrudScreen from '../components/CrudScreen';
import { accidentsApi } from '../api/vehicleadmin';
import { useLookups } from '../utils/useLookups';
export default function AccidentsPage() {
  const lookups = useLookups({ units: true, lookups: ['vehicles', 'accident_severities'] });
  return (<CrudScreen title="Accident Notifications" subtitle="Reported vehicle accidents." section="vehicle_admin_accidents" entityLabel="report" api={accidentsApi} initialSort="occurred_at" lookups={lookups}
    columns={[
      { key: 'occurred_at', label: 'Occurred', width: 160, sortable: true, render: (r) => r.occurred_at },
      { key: 'unit_name', label: 'Unit', sortable: true, sortKey: 'unit', render: (r) => r.unit_name || '—' },
      { key: 'vehicle_plate', label: 'Vehicle', width: 120, render: (r) => r.vehicle_plate || '—' },
      { key: 'severity_name', label: 'Severity', width: 110, sortable: true, sortKey: 'severity', render: (r) => r.severity_name ? <span className="pill pill-warn">{r.severity_name}</span> : '—' },
      { key: 'location', label: 'Location', render: (r) => r.location || '—' },
    ]}
    fields={[
      { key: 'unit_id', label: 'Unit', type: 'select', optionsKey: 'units', required: true },
      { key: 'vehicle_id', label: 'Vehicle', type: 'select', optionsKey: 'vehicles' },
      { key: 'occurred_at', label: 'Occurred at (YYYY-MM-DD HH:MM)', required: true, span: 2 },
      { key: 'severity_id', label: 'Severity', type: 'select', optionsKey: 'accident_severities' },
      { key: 'location', label: 'Location' },
      { key: 'description', label: 'Description', type: 'textarea', span: 2 },
    ]}
    toServerFilters={() => []} />);
}
