import CrudScreen from '../components/CrudScreen';
import { routesApi } from '../api/routes';
import { useLookups } from '../utils/useLookups';

export default function RoutesPage() {
  const lookups = useLookups({ units: true, regions: true });
  return (
    <CrudScreen
      title="Routes" subtitle="Transport routes by unit." section="land_ops_routes" entityLabel="route"
      api={routesApi} initialSort="route_no" lookups={lookups}
      columns={[
        { key: 'route_no', label: 'Route no', width: 120, sortable: true, filterable: true, render: (r) => <strong>{r.route_no}</strong> },
        { key: 'name', label: 'Name', sortable: true, filterable: true, render: (r) => r.name || '—' },
        { key: 'unit_name', label: 'Unit', sortable: true, sortKey: 'unit', filterable: true, filterType: 'select', filterKey: 'unit_id', options: lookups.units, render: (r) => r.unit_name || '—' },
        { key: 'corridor', label: 'Corridor', render: (r) => `${r.start_region_name || '—'} → ${r.end_region_name || '—'}` },
        { key: 'distance_km', label: 'Distance (km)', width: 120, align: 'right', sortable: true, render: (r) => r.distance_km ?? '—' },
      ]}
      fields={[
        { key: 'route_no', label: 'Route no', required: true },
        { key: 'unit_id', label: 'Unit', type: 'select', optionsKey: 'units', required: true },
        { key: 'name', label: 'Name', span: 2 },
        { key: 'start_region_id', label: 'Start region', type: 'select', optionsKey: 'regions' },
        { key: 'end_region_id', label: 'End region', type: 'select', optionsKey: 'regions' },
        { key: 'distance_km', label: 'Distance (km)', type: 'number' },
      ]}
      toServerFilters={(f) => {
        const s = [];
        if (f.route_no) s.push({ field: 'route_no', op: 'contains', value: f.route_no });
        if (f.name) s.push({ field: 'name', op: 'contains', value: f.name });
        if (f.unit_id) s.push({ field: 'unit_id', op: 'eq', value: f.unit_id });
        return s;
      }}
    />
  );
}
