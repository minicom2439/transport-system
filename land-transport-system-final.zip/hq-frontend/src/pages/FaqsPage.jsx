import CrudScreen from '../components/CrudScreen';
import { faqsApi } from '../api/infoservice';
export default function FaqsPage() {
  return (<CrudScreen title="FAQ" subtitle="Frequently asked questions." section="info_faqs" entityLabel="entry" api={faqsApi} initialSort="sort_order"
    columns={[
      { key: 'sort_order', label: '#', width: 60, align: 'right', sortable: true, render: (r) => r.sort_order },
      { key: 'question', label: 'Question', sortable: true, filterable: true, render: (r) => <strong>{r.question}</strong> },
      { key: 'answer', label: 'Answer', render: (r) => r.answer || '—' },
    ]}
    fields={[
      { key: 'question', label: 'Question', required: true, span: 2 },
      { key: 'answer', label: 'Answer', type: 'textarea', span: 2 },
      { key: 'sort_order', label: 'Sort order', type: 'number' },
    ]}
    toServerFilters={(f) => (f.question ? [{ field: 'question', op: 'contains', value: f.question }] : [])} />);
}
