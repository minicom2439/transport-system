import CrudScreen from '../components/CrudScreen';
import { indicatorsApi } from '../api/landops';
export default function TransportLedgerPage() {
  return (<CrudScreen title="Transport Ledger" subtitle="National transport indicators." section="land_ops_indicators" entityLabel="indicator" api={indicatorsApi} initialSort="name"
    columns={[
      { key: 'name', label: 'Indicator', sortable: true, filterable: true, render: (r) => <strong>{r.name}</strong> },
      { key: 'code', label: 'Code', width: 120, sortable: true, render: (r) => r.code || '—' },
      { key: 'unit_of_measure', label: 'Unit of measure', width: 160, render: (r) => r.unit_of_measure || '—' },
      { key: 'description', label: 'Description', render: (r) => r.description || '—' },
    ]}
    fields={[
      { key: 'name', label: 'Name', required: true, span: 2 },
      { key: 'code', label: 'Code' },
      { key: 'unit_of_measure', label: 'Unit of measure' },
      { key: 'description', label: 'Description', type: 'textarea', span: 2 },
    ]}
    toServerFilters={(f) => (f.name ? [{ field: 'name', op: 'contains', value: f.name }] : [])} />);
}
