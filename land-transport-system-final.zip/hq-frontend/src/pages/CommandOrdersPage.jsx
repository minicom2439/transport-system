import { useState, useEffect, useCallback } from 'react';
import CrudScreen from '../components/CrudScreen';
import Modal from '../components/Modal';
import { commandOrdersApi, commandOrderAttachmentsApi } from '../api/vehicleadmin';
import { useLookups } from '../utils/useLookups';
import { treeFromOptions } from '../utils/treeNodes';
import { useToast } from '../components/Toast';
import { useAuth } from '../auth/AuthContext';

const CATS = ['maintenance', 'operations', 'safety', 'administrative', 'other'].map((v) => ({ value: v, label: v[0].toUpperCase() + v.slice(1) }));
const CLASS = ['routine', 'priority', 'urgent'].map((v) => ({ value: v, label: v[0].toUpperCase() + v.slice(1) }));
const kb = (n) => (n == null ? '' : n >= 1024 ? `${(n / 1024).toFixed(0)} KB` : `${n} B`);

function AttachmentsModal({ order, onClose }) {
  const toast = useToast(); const { can } = useAuth();
  const canEdit = can('vehicle_admin_command_orders', 'edit');
  const [items, setItems] = useState([]); const [loading, setLoading] = useState(false);
  const [file, setFile] = useState(null); const [busy, setBusy] = useState(false);
  const load = useCallback(() => { setLoading(true); commandOrderAttachmentsApi.list(order.id).then((r) => { setItems(r.data || []); setLoading(false); }).catch((e) => { toast.error(e.message); setLoading(false); }); }, [order.id]);
  useEffect(() => { load(); }, [load]);
  const onPick = (e) => { const f = e.target.files && e.target.files[0]; if (!f) { setFile(null); return; } const reader = new FileReader(); reader.onload = () => setFile({ name: f.name, type: f.type, size: f.size, data: String(reader.result).split(',')[1] }); reader.readAsDataURL(f); };
  const upload = async () => {
    if (!file) { toast.error('Choose a file first.'); return; }
    setBusy(true);
    try { await commandOrderAttachmentsApi.upload(order.id, { file_name: file.name, content_type: file.type, data_base64: file.data }); toast.success('Attached.'); setFile(null); load(); }
    catch (e) { toast.error(e.message || 'Upload failed.'); } finally { setBusy(false); }
  };
  const remove = async (att) => { try { await commandOrderAttachmentsApi.remove(order.id, att.id); toast.success('Removed.'); load(); } catch (e) { toast.error(e.message); } };
  return (
    <Modal open title={`Attachments — ${order.title}`} width={560} onClose={onClose}>
      <div style={{ display: 'grid', gap: 12 }}>
        {loading ? <div style={{ color: 'var(--ink-soft)' }}>Loading…</div>
          : items.length === 0 ? <div style={{ color: 'var(--ink-soft)' }}>No attachments yet.</div>
          : items.map((a) => (
            <div key={a.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '6px 0', borderBottom: '1px solid var(--line)' }}>
              <span>{a.file_name} <span style={{ color: 'var(--ink-soft)' }}>{kb(a.file_size)}</span></span>
              {canEdit && <button className="btn btn-sm btn-danger" onClick={() => remove(a)}>Remove</button>}
            </div>))}
        {canEdit && (
          <div style={{ borderTop: '1px solid var(--line)', paddingTop: 12 }}>
            <input className="input" type="file" onChange={onPick} />
            <div style={{ marginTop: 8 }}><button className="btn btn-primary" onClick={upload} disabled={busy || !file}>{busy ? 'Uploading…' : 'Attach file'}</button></div>
          </div>)}
      </div>
    </Modal>
  );
}

export default function CommandOrdersPage() {
  const lookups = useLookups({ units: true, lookups: ['order_statuses'] });
  const [attachOrder, setAttachOrder] = useState(null);
  return (
    <>
      <CrudScreen title="Command Orders" subtitle="Directives issued to subordinate units, with attachments." section="vehicle_admin_command_orders" entityLabel="order" api={commandOrdersApi} initialSort="order_date" lookups={lookups}
        tree={{ filterKey: 'unit_id', title: 'Target Units', nodes: treeFromOptions(lookups.units, 'All units') }}
        rowExtra={(r) => <button className="btn btn-sm" onClick={() => setAttachOrder(r)} aria-label="Attachments">Files</button>}
        columns={[
          { key: 'title', label: 'Title', sortable: true, filterable: true, render: (r) => <strong>{r.title}</strong> },
          { key: 'order_number', label: 'Order no.', width: 130, render: (r) => r.order_number || '—' },
          { key: 'instruction_category', label: 'Category', width: 130, render: (r) => r.instruction_category || '—' },
          { key: 'unit_name', label: 'Target unit', sortable: true, sortKey: 'unit', render: (r) => r.unit_name || '—' },
          { key: 'order_date', label: 'Date', width: 120, sortable: true, render: (r) => r.order_date || '—' },
          { key: 'status_name', label: 'Status', width: 120, render: (r) => r.status_name || '—' },
        ]}
        fields={[
          { key: 'title', label: 'Title', required: true, span: 2 },
          { key: 'short_title', label: 'Short title' },
          { key: 'order_number', label: 'Order number' },
          { key: 'target_unit_id', label: 'Target unit', type: 'select', optionsKey: 'units', required: true },
          { key: 'instruction_category', label: 'Instruction category', type: 'select', options: CATS },
          { key: 'order_classification', label: 'Classification', type: 'select', options: CLASS },
          { key: 'order_date', label: 'Date', type: 'date' },
          { key: 'status_id', label: 'Status', type: 'select', optionsKey: 'order_statuses' },
          { key: 'body', label: 'Instruction details', type: 'textarea', span: 2 },
        ]}
        toServerFilters={(f) => { const s = []; if (f.title) s.push({ field: 'title', op: 'contains', value: f.title }); if (f.unit_id) s.push({ field: 'unit_id', op: 'eq', value: f.unit_id }); return s; }} />
      {attachOrder && <AttachmentsModal order={attachOrder} onClose={() => setAttachOrder(null)} />}
    </>
  );
}
