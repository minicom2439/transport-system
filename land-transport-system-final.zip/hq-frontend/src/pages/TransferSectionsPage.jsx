import CrudScreen from '../components/CrudScreen';
import { transferSectionsApi } from '../api/landops';
import { useLookups } from '../utils/useLookups';
export default function TransferSectionsPage() {
  const lookups = useLookups({ regions: true });
  return (<CrudScreen title="Transfer Sections" subtitle="Cargo transfer lanes (start → arrive)." section="land_ops_transfer_sections" entityLabel="section" api={transferSectionsApi} initialSort="name" lookups={lookups}
    columns={[
      { key: 'name', label: 'Section', sortable: true, filterable: true, render: (r) => <strong>{r.name}</strong> },
      { key: 'start_region_name', label: 'Start area', sortable: true, sortKey: 'start', render: (r) => r.start_region_name || '—' },
      { key: 'end_region_name', label: 'Arrive area', sortable: true, sortKey: 'end', render: (r) => r.end_region_name || '—' },
    ]}
    fields={[
      { key: 'name', label: 'Name', required: true, span: 2 },
      { key: 'start_region_id', label: 'Start area', type: 'select', optionsKey: 'regions' },
      { key: 'end_region_id', label: 'Arrive area', type: 'select', optionsKey: 'regions' },
    ]}
    toServerFilters={(f) => (f.name ? [{ field: 'name', op: 'contains', value: f.name }] : [])} />);
}
