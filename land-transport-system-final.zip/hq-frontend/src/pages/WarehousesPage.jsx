import CrudScreen from '../components/CrudScreen';
import { warehousesApi } from '../api/landops';
import { useLookups } from '../utils/useLookups';
import { treeFromOptions } from '../utils/treeNodes';
export default function WarehousesPage() {
  const lookups = useLookups({ units: true, regions: true });
  return (<CrudScreen title="Transfer Warehouses" subtitle="Cargo warehouses by unit." section="land_ops_warehouses" entityLabel="warehouse" api={warehousesApi} initialSort="name" lookups={lookups}
    tree={{ filterKey: 'unit_id', title: 'Units', nodes: treeFromOptions(lookups.units, 'All units') }}
    columns={[
      { key: 'name', label: 'Name', sortable: true, filterable: true, render: (r) => <strong>{r.name}</strong> },
      { key: 'code', label: 'Code', width: 110, sortable: true, render: (r) => r.code || '—' },
      { key: 'unit_name', label: 'Unit', sortable: true, sortKey: 'unit', render: (r) => r.unit_name || '—' },
      { key: 'region_name', label: 'Region', sortable: true, sortKey: 'region', render: (r) => r.region_name || '—' },
      { key: 'capacity', label: 'Capacity', width: 120, align: 'right', sortable: true, render: (r) => r.capacity != null ? `${r.capacity} ${r.capacity_unit || ''}`.trim() : '—' },
    ]}
    fields={[
      { key: 'name', label: 'Name', required: true, span: 2 },
      { key: 'unit_id', label: 'Unit', type: 'select', optionsKey: 'units', required: true },
      { key: 'region_id', label: 'Region', type: 'select', optionsKey: 'regions' },
      { key: 'code', label: 'Code' },
      { key: 'capacity', label: 'Capacity', type: 'number' },
      { key: 'capacity_unit', label: 'Capacity unit (e.g. tonnes)' },
    ]}
    toServerFilters={(f) => { const s = []; if (f.name) s.push({ field: 'name', op: 'contains', value: f.name }); if (f.unit_id) s.push({ field: 'unit_id', op: 'eq', value: f.unit_id }); return s; }} />);
}
