// src/pages/TransportPage.jsx — analytics: stats by unit (aggregate, no paging).
import { useEffect, useState } from 'react';
import { statsByUnit } from '../api/transport';
import DataTable from '../components/DataTable';

export default function TransportPage() {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const load = () => { setLoading(true); setError(null); statsByUnit({}).then((r) => setRows(r.data)).catch(setError).finally(() => setLoading(false)); };
  useEffect(() => { load(); }, []);

  const n = (v) => (v == null ? '0' : Number(v).toLocaleString());
  const columns = [
    { key: 'unit_name', label: 'Unit', render: (r) => r.unit_name || `Unit ${r.unit_id}` },
    { key: 'trips', label: 'Trips', align: 'right', render: (r) => n(r.trips) },
    { key: 'distance_km', label: 'Distance (km)', align: 'right', render: (r) => n(r.distance_km) },
    { key: 'passengers_carried', label: 'Passengers', align: 'right', render: (r) => n(r.passengers_carried) },
    { key: 'cargo_weight', label: 'Cargo (wt)', align: 'right', render: (r) => n(r.cargo_weight) },
    { key: 'revenue', label: 'Revenue', align: 'right', render: (r) => n(r.revenue) },
  ];

  return (
    <div>
      <h1 style={{ fontSize: 'var(--fs-xl)' }}>Traveler & Cargo Transport</h1>
      <p style={{ color: 'var(--ink-soft)', margin: '2px 0 14px', fontSize: 'var(--fs-sm)' }}>Aggregated from the per-vehicle-per-day records.</p>
      <div className="card" style={{ height: 'calc(100vh - var(--topbar-h) - 120px)', minHeight: 320, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
        <DataTable columns={columns} rows={rows} total={rows.length} loading={loading} error={error} onRetry={load} emptyText="No transport records yet." />
      </div>
    </div>
  );
}
