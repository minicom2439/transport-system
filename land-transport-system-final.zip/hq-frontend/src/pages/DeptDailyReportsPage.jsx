import { useMemo } from 'react';
import CrudScreen from '../components/CrudScreen';
import { deptDailyApi } from '../api/departments';
import { useLookups } from '../utils/useLookups';
import { treeFromOptions } from '../utils/treeNodes';
const STATUS_OPTS = ['draft', 'submitted', 'approved', 'rejected', 'cancelled'].map((s) => ({ value: s, label: s[0].toUpperCase() + s.slice(1) }));
export default function DeptDailyReportsPage({ apiPath, section, title, subtitle }) {
  const lookups = useLookups({ units: true });
  const api = useMemo(() => deptDailyApi(apiPath), [apiPath]);
  return (<CrudScreen title={title} subtitle={subtitle} section={section} entityLabel="report" api={api} initialSort="report_date" readOnly lookups={lookups}
    tree={{ filterKey: 'unit_id', title: 'Units', nodes: treeFromOptions(lookups.units, 'All units') }}
    columns={[
      { key: 'report_date', label: 'Date', width: 120, sortable: true, render: (r) => r.report_date },
      { key: 'title', label: 'Title', sortable: true, filterable: true, render: (r) => <strong>{r.title}</strong> },
      { key: 'unit_name', label: 'Unit', sortable: true, sortKey: 'unit', render: (r) => r.unit_name || '—' },
      { key: 'status', label: 'Status', width: 110, filterable: true, filterType: 'select', options: STATUS_OPTS },
      { key: 'command', label: 'Instruction', render: (r) => r.command ? <span title={r.command}>{r.command.length > 50 ? r.command.slice(0, 50) + '…' : r.command}</span> : <span style={{ color: 'var(--ink-faint)' }}>—</span> },
    ]}
    fields={[]}
    toServerFilters={(f) => { const s = []; if (f.title) s.push({ field: 'title', op: 'contains', value: f.title }); if (f.status) s.push({ field: 'status', op: 'eq', value: f.status }); if (f.unit_id) s.push({ field: 'unit_id', op: 'eq', value: f.unit_id }); return s; }} />);
}
