import CrudScreen from '../components/CrudScreen';
import { parksApi } from '../api/parks';
import { useLookups } from '../utils/useLookups';

export default function ParksPage() {
  const lookups = useLookups({ units: true, regions: true });
  return (
    <CrudScreen
      title="Parks (Depots)" subtitle="Bus depots / parking facilities." section="vehicle_admin_parks" entityLabel="park"
      api={parksApi} initialSort="name" lookups={lookups}
      columns={[
        { key: 'name', label: 'Name', sortable: true, filterable: true, render: (r) => <strong>{r.name}</strong> },
        { key: 'code', label: 'Code', width: 110, sortable: true, render: (r) => r.code || '—' },
        { key: 'unit_name', label: 'Unit', sortable: true, sortKey: 'unit', render: (r) => r.unit_name || '—' },
        { key: 'region_name', label: 'Region', sortable: true, sortKey: 'region', render: (r) => r.region_name || '—' },
        { key: 'capacity', label: 'Capacity', width: 100, align: 'right', sortable: true, render: (r) => r.capacity ?? '—' },
      ]}
      fields={[
        { key: 'name', label: 'Name', required: true, span: 2 },
        { key: 'unit_id', label: 'Unit', type: 'select', optionsKey: 'units', required: true },
        { key: 'region_id', label: 'Region', type: 'select', optionsKey: 'regions' },
        { key: 'code', label: 'Code' },
        { key: 'capacity', label: 'Capacity', type: 'number' },
      ]}
      toServerFilters={(f) => (f.name ? [{ field: 'name', op: 'contains', value: f.name }] : [])}
    />
  );
}
