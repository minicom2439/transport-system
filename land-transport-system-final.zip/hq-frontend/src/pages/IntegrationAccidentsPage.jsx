import CrudScreen from '../components/CrudScreen';
import { intgAccidentsApi } from '../api/integration';
import { useLookups } from '../utils/useLookups';
import { treeFromOptions } from '../utils/treeNodes';
export default function IntegrationAccidentsPage() {
  const lookups = useLookups({ units: true });
  return (<CrudScreen title="Accident Notification" subtitle="Accidents across units (read-only oversight)." section="integration_accidents" entityLabel="report" api={intgAccidentsApi} initialSort="occurred_at" readOnly lookups={lookups}
    tree={{ filterKey: 'unit_id', title: 'Units', nodes: treeFromOptions(lookups.units, 'All units') }}
    columns={[
      { key: 'occurred_at', label: 'Occurred', width: 160, sortable: true, render: (r) => r.occurred_at },
      { key: 'unit_name', label: 'Unit', sortable: true, sortKey: 'unit', render: (r) => r.unit_name || '—' },
      { key: 'vehicle_plate', label: 'Vehicle', width: 120, render: (r) => r.vehicle_plate || '—' },
      { key: 'severity_name', label: 'Severity', width: 110, render: (r) => r.severity_name ? <span className="pill pill-warn">{r.severity_name}</span> : '—' },
      { key: 'location', label: 'Location', render: (r) => r.location || '—' },
    ]}
    fields={[]}
    toServerFilters={(f) => (f.unit_id ? [{ field: 'unit_id', op: 'eq', value: f.unit_id }] : [])} />);
}
