import LookupAdminScreen from '../components/LookupAdminScreen';
export default function BasicDataPage() {
  return (<LookupAdminScreen title="Basic Data" subtitle="Reference data for vehicles and operations." section="vehicle_admin_basic_data"
    tabs={[
      { table: 'vehicle_types', label: 'Vehicle Types' },
      { table: 'vehicle_forms', label: 'Vehicle Forms' },
      { table: 'vehicle_uses', label: 'Uses' },
      { table: 'technical_statuses', label: 'Technical Status' },
      { table: 'vehicle_statuses', label: 'Vehicle Status' },
      { table: 'equipment_categories', label: 'Equipment Category' },
      { table: 'register_categories', label: 'Register Category' },
      { table: 'structural_features', label: 'Structural Features' },
      { table: 'real_move_states', label: 'Real Move State' },
      { table: 'safety_directives', label: 'Safety Directives' },
      { table: 'accident_severities', label: 'Accident Severities' },
      { table: 'finance_categories', label: 'Finance Categories' },
      { table: 'license_types', label: 'License Types' },
    ]} />);
}
