import CrudScreen from '../components/CrudScreen';
import { weeklyScheduleApi } from '../api/departments';
import { useLookups } from '../utils/useLookups';
import { treeFromOptions } from '../utils/treeNodes';
export default function WeeklySchedulePage() {
  const lookups = useLookups({ units: true });
  return (<CrudScreen title="Weekly Work Schedule" subtitle="Weekly work schedules per unit." section="cmp_weekly" entityLabel="schedule" api={weeklyScheduleApi} initialSort="week_start" lookups={lookups}
    tree={{ filterKey: 'unit_id', title: 'Units', nodes: treeFromOptions(lookups.units, 'All units') }}
    columns={[
      { key: 'title', label: 'Title', sortable: true, filterable: true, render: (r) => <strong>{r.title}</strong> },
      { key: 'week_start', label: 'Week of', width: 130, sortable: true, render: (r) => r.week_start },
      { key: 'unit_name', label: 'Unit', sortable: true, sortKey: 'unit', render: (r) => r.unit_name || '—' },
    ]}
    fields={[
      { key: 'title', label: 'Title', required: true, span: 2 },
      { key: 'unit_id', label: 'Unit', type: 'select', optionsKey: 'units' },
      { key: 'week_start', label: 'Week start', type: 'date', required: true },
      { key: 'content', label: 'Content', type: 'textarea', span: 2 },
    ]}
    toServerFilters={(f) => { const s = []; if (f.title) s.push({ field: 'title', op: 'contains', value: f.title }); if (f.unit_id) s.push({ field: 'unit_id', op: 'eq', value: f.unit_id }); return s; }} />);
}
