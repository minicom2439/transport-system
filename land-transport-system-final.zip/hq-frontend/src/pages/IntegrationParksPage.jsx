import CrudScreen from '../components/CrudScreen';
import { intgParksApi } from '../api/integration';
import { useLookups } from '../utils/useLookups';
import { treeFromOptions } from '../utils/treeNodes';
export default function IntegrationParksPage() {
  const lookups = useLookups({ units: true });
  return (<CrudScreen title="Park" subtitle="Depots/parks across units (read-only oversight)." section="integration_parks" entityLabel="park" api={intgParksApi} initialSort="name" readOnly lookups={lookups}
    tree={{ filterKey: 'unit_id', title: 'Units', nodes: treeFromOptions(lookups.units, 'All units') }}
    columns={[
      { key: 'name', label: 'Park', sortable: true, filterable: true, render: (r) => <strong>{r.name}</strong> },
      { key: 'code', label: 'Code', width: 110, render: (r) => r.code || '—' },
      { key: 'unit_name', label: 'Unit', sortable: true, sortKey: 'unit', render: (r) => r.unit_name || '—' },
      { key: 'capacity', label: 'Capacity', width: 110, align: 'right', render: (r) => r.capacity ?? '—' },
    ]}
    fields={[]}
    toServerFilters={(f) => { const s = []; if (f.name) s.push({ field: 'name', op: 'contains', value: f.name }); if (f.unit_id) s.push({ field: 'unit_id', op: 'eq', value: f.unit_id }); return s; }} />);
}
