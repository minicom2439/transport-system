import CrudScreen from '../components/CrudScreen';
import { feedbackApi } from '../api/infoservice';
export default function FeedbackPage() {
  return (<CrudScreen title="Feedback Box" subtitle="Submitted feedback and suggestions." section="info_feedback" entityLabel="message" api={feedbackApi} initialSort="submitted_at"
    columns={[
      { key: 'subject', label: 'Subject', sortable: true, render: (r) => <strong>{r.subject || '(no subject)'}</strong> },
      { key: 'body', label: 'Message', render: (r) => r.body },
      { key: 'submitted_by_name', label: 'From', width: 160, render: (r) => r.submitted_by_name || '—' },
      { key: 'submitted_at', label: 'Submitted', width: 170, sortable: true, render: (r) => r.submitted_at || '—' },
      { key: 'is_read', label: 'Read', width: 90, render: (r) => <span className={`pill ${r.is_read ? 'pill-ok' : 'pill-warn'}`}>{r.is_read ? 'Read' : 'New'}</span> },
    ]}
    fields={[
      { key: 'subject', label: 'Subject', span: 2 },
      { key: 'body', label: 'Message', type: 'textarea', required: true, span: 2 },
      { key: 'is_read', label: 'Mark as read', type: 'checkbox' },
    ]} />);
}
