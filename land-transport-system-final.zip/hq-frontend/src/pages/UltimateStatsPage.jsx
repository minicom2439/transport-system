import { useEffect, useState } from 'react';
import { statsApi } from '../api/insights';
import { useToast } from '../components/Toast';
const AXES = [{ value: 'unit', label: 'Per Unit' }, { value: 'route', label: 'Per Route' }, { value: 'region', label: 'Per Area' }, { value: 'period', label: 'Per Month' }];
const num = (v) => Number(v || 0).toLocaleString();
export default function UltimateStatsPage() {
  const toast = useToast();
  const [axis, setAxis] = useState('unit');
  const [year, setYear] = useState('');
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    let alive = true; setLoading(true);
    statsApi.transport({ axis, ...(year ? { year } : {}) }).then((res) => { if (alive) { setRows(res.data || []); setLoading(false); } }).catch((e) => { if (alive) { toast.error(e.message || 'Could not load statistics.'); setLoading(false); } });
    return () => { alive = false; };
  }, [axis, year]);
  const maxPax = Math.max(1, ...rows.map((r) => r.passengers));
  return (
    <div>
      <h1 style={{ fontSize: 'var(--fs-xl)' }}>Ultimate Statistics</h1>
      <p style={{ color: 'var(--ink-soft)', margin: '2px 0 14px', fontSize: 'var(--fs-sm)' }}>Passenger and cargo transport by indicator, aggregated across units, routes, areas and periods.</p>
      <div style={{ display: 'flex', gap: 12, alignItems: 'center', flexWrap: 'wrap', marginBottom: 12 }}>
        <span style={{ display: 'inline-flex', gap: 6 }}>{AXES.map((a) => (<button key={a.value} className={`btn btn-sm ${axis === a.value ? 'btn-primary' : ''}`} onClick={() => setAxis(a.value)}>{a.label}</button>))}</span>
        <input className="input" style={{ maxWidth: 140 }} placeholder="Year (all)" value={year} onChange={(e) => setYear(e.target.value.replace(/[^0-9]/g, ''))} />
      </div>
      <div className="card" style={{ overflowX: 'auto', padding: 0 }}>
        <table className="stats-tbl">
          <thead><tr><th style={{ textAlign: 'left' }}>{AXES.find((a) => a.value === axis).label.replace('Per ', '')}</th><th>Trips</th><th>Passengers</th><th style={{ width: '28%' }}>Passengers share</th><th>Cargo (wt)</th><th>Revenue</th></tr></thead>
          <tbody>
            {loading ? (<tr><td colSpan={6} style={{ padding: 16, color: 'var(--ink-soft)' }}>Loading…</td></tr>)
              : rows.length === 0 ? (<tr><td colSpan={6} style={{ padding: 16, color: 'var(--ink-soft)' }}>No statistics for this view.</td></tr>)
              : rows.map((r, i) => (
                <tr key={i}>
                  <td style={{ textAlign: 'left' }}><strong>{r.key_name}</strong></td>
                  <td>{num(r.trips)}</td>
                  <td>{num(r.passengers)}</td>
                  <td><div style={{ background: 'var(--surface-2)', borderRadius: 4, height: 14 }}><div style={{ width: `${Math.round((r.passengers / maxPax) * 100)}%`, background: 'var(--accent)', height: 14, borderRadius: 4, minWidth: r.passengers ? 2 : 0 }} /></div></td>
                  <td>{num(r.cargo_weight)}</td>
                  <td>{num(r.revenue)}</td>
                </tr>))}
          </tbody>
        </table>
      </div>
      <style>{`
        .stats-tbl { width: 100%; border-collapse: collapse; font-size: var(--fs-sm); }
        .stats-tbl th, .stats-tbl td { padding: 10px 12px; text-align: right; border-bottom: 1px solid var(--line); }
        .stats-tbl thead th { background: var(--surface-2); color: var(--ink-soft); font-weight: 600; position: sticky; top: 0; }
        .stats-tbl tbody tr:hover { background: var(--surface-2); }
      `}</style>
    </div>
  );
}
