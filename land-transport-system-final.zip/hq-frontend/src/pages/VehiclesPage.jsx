import CrudScreen from '../components/CrudScreen';
import { vehiclesApi } from '../api/vehicleadmin';
import { useLookups } from '../utils/useLookups';
import { treeFromOptions } from '../utils/treeNodes';
export default function VehiclesPage() {
  const lookups = useLookups({ units: true, lookups: ['parks', 'vehicle_types', 'vehicle_forms', 'vehicle_uses', 'technical_statuses', 'vehicle_statuses', 'equipment_categories', 'register_categories', 'structural_features'] });
  return (<CrudScreen title="Vehicles" subtitle="Registered means of transportation." section="vehicle_admin_register" entityLabel="vehicle" api={vehiclesApi} initialSort="plate_no" lookups={lookups}
    tree={{ filterKey: 'unit_id', title: 'Units', nodes: treeFromOptions(lookups.units, 'All units') }}
    columns={[
      { key: 'plate_no', label: 'Plate', sortable: true, filterable: true, render: (r) => <strong>{r.plate_no}</strong> },
      { key: 'vehicle_type_name', label: 'Type', sortable: true, sortKey: 'type', render: (r) => r.vehicle_type_name || '—' },
      { key: 'unit_name', label: 'Unit', sortable: true, sortKey: 'unit', render: (r) => r.unit_name || '—' },
      { key: 'park_name', label: 'Park', sortable: true, sortKey: 'park', render: (r) => r.park_name || '—' },
      { key: 'vehicle_status_name', label: 'Status', sortable: true, sortKey: 'status', render: (r) => r.vehicle_status_name ? <span className="pill pill-off">{r.vehicle_status_name}</span> : '—' },
      { key: 'seat_count', label: 'Seats', width: 80, align: 'right', sortable: true, render: (r) => r.seat_count ?? '—' },
    ]}
    fields={[
      { key: 'plate_no', label: 'Plate number', required: true },
      { key: 'unit_id', label: 'Unit', type: 'select', optionsKey: 'units', required: true },
      { key: 'park_id', label: 'Park', type: 'select', optionsKey: 'parks' },
      { key: 'vehicle_type_id', label: 'Vehicle type', type: 'select', optionsKey: 'vehicle_types' },
      { key: 'vehicle_form_id', label: 'Form', type: 'select', optionsKey: 'vehicle_forms' },
      { key: 'use_id', label: 'Use', type: 'select', optionsKey: 'vehicle_uses' },
      { key: 'vehicle_status_id', label: 'Vehicle status', type: 'select', optionsKey: 'vehicle_statuses' },
      { key: 'technical_status_id', label: 'Technical status', type: 'select', optionsKey: 'technical_statuses' },
      { key: 'equipment_category_id', label: 'Equipment category', type: 'select', optionsKey: 'equipment_categories' },
      { key: 'register_category_id', label: 'Register category', type: 'select', optionsKey: 'register_categories' },
      { key: 'structural_feature_id', label: 'Structural feature', type: 'select', optionsKey: 'structural_features' },
      { key: 'seat_count', label: 'Seats', type: 'number' },
      { key: 'load_capacity', label: 'Load capacity', type: 'number' },
      { key: 'registered_on', label: 'Registered on', type: 'date' },
    ]}
    toServerFilters={(f) => { const s = []; if (f.plate_no) s.push({ field: 'plate_no', op: 'contains', value: f.plate_no }); if (f.unit_id) s.push({ field: 'unit_id', op: 'eq', value: f.unit_id }); return s; }} />);
}
