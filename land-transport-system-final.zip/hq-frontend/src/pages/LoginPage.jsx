// src/pages/LoginPage.jsx — full-screen branded background, centered form.
import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';
import { Grid } from '../components/Icons';

export default function LoginPage() {
  const { signIn } = useAuth();
  const navigate = useNavigate();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setError(''); setBusy(true);
    try { await signIn(username, password); navigate('/'); }
    catch (err) { setError(err.status === 401 ? 'Incorrect username or password.' : 'Could not sign in. Try again.'); }
    finally { setBusy(false); }
  };

  return (
    <div className="login-screen">
      <div className="login-stack">
        <div className="brand">
          <span className="brand-mark"><Grid /></span>
          <div className="brand-name">HQ Transport</div>
          <div className="brand-sub">Land Transport Management System</div>
        </div>

        <form className="login-card" onSubmit={submit}>
          <h2 className="login-title">Sign in</h2>
          <p className="login-hint">Use your operations console account.</p>

          <label className="label" htmlFor="u">Username</label>
          <input id="u" className="input" value={username} onChange={(e) => setUsername(e.target.value)} autoFocus autoComplete="username" />
          <div style={{ height: 14 }} />
          <label className="label" htmlFor="p">Password</label>
          <input id="p" className="input" type="password" value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="current-password" />

          {error && <div className="login-error" role="alert">{error}</div>}

          <button className="btn btn-primary login-submit" disabled={busy}>
            {busy ? 'Signing in…' : 'Sign in'}
          </button>
        </form>

        <div className="login-foot">Authorized use only · Internal network</div>
      </div>

      <style>{`
        .login-screen {
          min-height: 100vh; display: flex; align-items: center; justify-content: center;
          padding: 24px;
          /* solid brand color with subtle depth + faint console grid (offline, no image) */
          background:
            radial-gradient(1200px 600px at 50% -10%, #15938a 0%, rgba(21,147,138,0) 60%),
            repeating-linear-gradient(0deg,  rgba(255,255,255,.04) 0 1px, transparent 1px 40px),
            repeating-linear-gradient(90deg, rgba(255,255,255,.04) 0 1px, transparent 1px 40px),
            var(--accent);
        }
        .login-stack { width: 100%; max-width: 380px; display: flex; flex-direction: column; align-items: center; }
        .brand { text-align: center; color: #fff; margin-bottom: 22px; }
        .brand-mark {
          display: inline-flex; width: 56px; height: 56px; align-items: center; justify-content: center;
          background: rgba(255,255,255,.14); border: 1px solid rgba(255,255,255,.28);
          border-radius: 14px; margin-bottom: 14px;
        }
        .brand-mark svg { width: 28px; height: 28px; }
        .brand-name { font-size: 26px; font-weight: 750; letter-spacing: -0.02em; }
        .brand-sub { font-size: 13px; color: rgba(255,255,255,.82); margin-top: 4px; letter-spacing: .01em; }

        .login-card {
          width: 100%; background: var(--surface); border-radius: 12px; padding: 26px;
          box-shadow: 0 18px 50px rgba(10,40,38,.35);
        }
        .login-title { font-size: 19px; }
        .login-hint { color: var(--ink-soft); font-size: var(--fs-sm); margin: 4px 0 18px; }
        .login-error {
          margin-top: 14px; padding: 9px 11px; background: var(--danger-soft); color: var(--danger);
          border-radius: var(--radius-sm); font-size: var(--fs-sm);
        }
        .login-submit { width: 100%; height: 38px; margin-top: 18px; font-size: var(--fs-md); }
        .login-foot { color: rgba(255,255,255,.7); font-size: 11.5px; margin-top: 20px; letter-spacing: .03em; }
      `}</style>
    </div>
  );
}
