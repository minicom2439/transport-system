import WorkflowScreen from '../components/WorkflowScreen';
import { routeCertsApi } from '../api/landops';
import { useLookups } from '../utils/useLookups';
import { treeFromOptions } from '../utils/treeNodes';
const STATUS_OPTS = ['draft', 'submitted', 'approved', 'rejected', 'cancelled'].map((s) => ({ value: s, label: s[0].toUpperCase() + s.slice(1) }));
export default function RouteCertificatesPage() {
  const lookups = useLookups({ units: true, lookups: ['routes', 'route_types'] });
  return (<WorkflowScreen title="Route Certificates" subtitle="Traveler & small-bus route certifications, with an approval workflow." section="land_ops_route_certs" entityLabel="certificate" api={routeCertsApi} initialSort="certificate_no" lookups={lookups}
    tree={{ filterKey: 'unit_id', title: 'Requested Units', nodes: treeFromOptions(lookups.units, 'All units') }}
    columns={[
      { key: 'certificate_no', label: 'Certificate', sortable: true, filterable: true, render: (r) => <strong>{r.certificate_no || '—'}</strong> },
      { key: 'cert_type_name', label: 'Type', width: 120, filterable: true, filterType: 'select', filterKey: 'cert_type_id', options: lookups.route_types, render: (r) => r.cert_type_name || '—' },
      { key: 'route_no', label: 'Route', width: 100, sortable: true, sortKey: 'route', render: (r) => r.route_no || '—' },
      { key: 'unit_name', label: 'Unit', sortable: true, sortKey: 'unit', render: (r) => r.unit_name || '—' },
      { key: 'validity', label: 'Validity', width: 170, render: (r) => `${r.valid_from || '—'} → ${r.valid_to || '—'}` },
      { key: 'status', label: 'Status', width: 110, filterable: true, filterType: 'select', options: STATUS_OPTS },
    ]}
    fields={[
      { key: 'certificate_no', label: 'Certificate no' },
      { key: 'cert_type_id', label: 'Type (Traveler / Small bus)', type: 'select', optionsKey: 'route_types' },
      { key: 'route_id', label: 'Route', type: 'select', optionsKey: 'routes', required: true },
      { key: 'unit_id', label: 'Unit', type: 'select', optionsKey: 'units', required: true },
      { key: 'valid_from', label: 'Valid from', type: 'date' },
      { key: 'valid_to', label: 'Valid to', type: 'date' },
    ]}
    toServerFilters={(f) => { const s = []; if (f.certificate_no) s.push({ field: 'certificate_no', op: 'contains', value: f.certificate_no }); if (f.status) s.push({ field: 'status', op: 'eq', value: f.status }); if (f.cert_type_id) s.push({ field: 'cert_type_id', op: 'eq', value: f.cert_type_id }); if (f.unit_id) s.push({ field: 'unit_id', op: 'eq', value: f.unit_id }); return s; }} />);
}
