import CrudScreen from '../components/CrudScreen';
import { parkVehiclesApi } from '../api/landops';
import { useLookups } from '../utils/useLookups';
import { treeFromOptions } from '../utils/treeNodes';
export default function ParkVehiclesPage() {
  const lookups = useLookups({ lookups: ['parks'] });
  return (<CrudScreen title="Vehicle Information (per Park)" subtitle="Vehicles registered at each park (read-only)." section="land_ops_park_vehicles" entityLabel="vehicle" api={parkVehiclesApi} initialSort="plate_no" readOnly lookups={lookups}
    tree={{ filterKey: 'park_id', title: 'Parks', nodes: treeFromOptions(lookups.parks, 'All parks') }}
    columns={[
      { key: 'plate_no', label: 'Plate', sortable: true, filterable: true, render: (r) => <strong>{r.plate_no}</strong> },
      { key: 'vehicle_type_name', label: 'Type', sortable: true, sortKey: 'type', render: (r) => r.vehicle_type_name || '—' },
      { key: 'unit_name', label: 'Unit', sortable: true, sortKey: 'unit', render: (r) => r.unit_name || '—' },
      { key: 'park_name', label: 'Park', sortable: true, sortKey: 'park', render: (r) => r.park_name || '—' },
      { key: 'vehicle_status_name', label: 'Status', render: (r) => r.vehicle_status_name ? <span className="pill pill-off">{r.vehicle_status_name}</span> : '—' },
      { key: 'seat_count', label: 'Seats', width: 80, align: 'right', render: (r) => r.seat_count ?? '—' },
    ]}
    fields={[]}
    toServerFilters={(f) => { const s = []; if (f.plate_no) s.push({ field: 'plate_no', op: 'contains', value: f.plate_no }); if (f.park_id) s.push({ field: 'park_id', op: 'eq', value: f.park_id }); return s; }} />);
}
