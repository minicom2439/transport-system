import CrudScreen from '../components/CrudScreen';
import { guardDutiesApi } from '../api/departments';
import { useLookups } from '../utils/useLookups';
import { treeFromOptions } from '../utils/treeNodes';
const SHIFTS = ['Day', 'Night'].map((v) => ({ value: v, label: v }));
export default function GuardDutiesPage() {
  const lookups = useLookups({ units: true });
  return (<CrudScreen title="Security Guard Duty" subtitle="Guard posts and shifts per unit (defense roster)." section="cmp_defense" entityLabel="duty" api={guardDutiesApi} initialSort="duty_date" lookups={lookups}
    tree={{ filterKey: 'unit_id', title: 'Units', nodes: treeFromOptions(lookups.units, 'All units') }}
    columns={[
      { key: 'duty_date', label: 'Date', width: 120, sortable: true, render: (r) => r.duty_date },
      { key: 'shift', label: 'Shift', width: 90, filterable: true, filterType: 'select', options: SHIFTS, render: (r) => r.shift ? <span className={`pill ${r.shift === 'Night' ? 'pill-off' : 'pill-accent'}`}>{r.shift}</span> : '—' },
      { key: 'post', label: 'Post', sortable: true, filterable: true, render: (r) => <strong>{r.post || '—'}</strong> },
      { key: 'guard_name', label: 'Guard', render: (r) => r.guard_name || '—' },
      { key: 'unit_name', label: 'Unit', sortable: true, sortKey: 'unit', render: (r) => r.unit_name || '—' },
    ]}
    fields={[
      { key: 'unit_id', label: 'Unit', type: 'select', optionsKey: 'units' },
      { key: 'duty_date', label: 'Date', type: 'date', required: true },
      { key: 'shift', label: 'Shift', type: 'select', options: SHIFTS },
      { key: 'post', label: 'Post / location' },
      { key: 'guard_name', label: 'Guard' },
      { key: 'notes', label: 'Notes', type: 'textarea', span: 2 },
    ]}
    toServerFilters={(f) => { const s = []; if (f.post) s.push({ field: 'post', op: 'contains', value: f.post }); if (f.shift) s.push({ field: 'shift', op: 'eq', value: f.shift }); if (f.unit_id) s.push({ field: 'unit_id', op: 'eq', value: f.unit_id }); return s; }} />);
}
