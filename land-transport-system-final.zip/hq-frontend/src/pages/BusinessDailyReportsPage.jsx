import WorkflowScreen from '../components/WorkflowScreen';
import { businessDailyApi } from '../api/departments';
import { useLookups } from '../utils/useLookups';
import { treeFromOptions } from '../utils/treeNodes';
const DEPTS = ['planning', 'equipment', 'finance', 'comprehensive', 'first_business', 'disinfection'].map((d) => ({ value: d, label: d[0].toUpperCase() + d.slice(1).replace('_', ' ') }));
const STATUS_OPTS = ['draft', 'submitted', 'approved', 'rejected', 'cancelled'].map((s) => ({ value: s, label: s[0].toUpperCase() + s.slice(1) }));
// One page, two experiences:
//  • a Unit (add/edit, scoped to its own unit) writes a report and submits it;
//  • an admin/section manager (approve/reject, sees all units) reviews it and
//    issues a "business daily command" on approval.
export default function BusinessDailyReportsPage() {
  const lookups = useLookups({ units: true });
  return (<WorkflowScreen title="Business Daily Reports" subtitle="Units submit daily reports; admins review and issue a daily command." section="cmp_daily_reports" entityLabel="report" api={businessDailyApi} initialSort="report_date" lookups={lookups} approveCommandLabel="Review & command"
    tree={{ filterKey: 'unit_id', title: 'Units', nodes: treeFromOptions(lookups.units, 'All units') }}
    columns={[
      { key: 'report_date', label: 'Date', width: 116, sortable: true, render: (r) => r.report_date },
      { key: 'title', label: 'Title', sortable: true, filterable: true, render: (r) => <strong>{r.title}</strong> },
      { key: 'department', label: 'Department', width: 130, filterable: true, filterType: 'select', options: DEPTS, render: (r) => r.department || '—' },
      { key: 'unit_name', label: 'Unit', sortable: true, sortKey: 'unit', render: (r) => r.unit_name || '—' },
      { key: 'status', label: 'Status', width: 110, filterable: true, filterType: 'select', options: STATUS_OPTS },
      { key: 'command', label: 'Daily command', render: (r) => r.command ? <span title={r.command}>{r.command.length > 60 ? r.command.slice(0, 60) + '…' : r.command}</span> : <span style={{ color: 'var(--ink-faint)' }}>—</span> },
    ]}
    fields={[
      { key: 'title', label: 'Title', required: true, span: 2 },
      { key: 'department', label: 'Department', type: 'select', options: DEPTS },
      { key: 'unit_id', label: 'Unit', type: 'select', optionsKey: 'units' },
      { key: 'report_date', label: 'Date', type: 'date', required: true },
      { key: 'content', label: 'Report content', type: 'textarea', span: 2 },
    ]}
    toServerFilters={(f) => { const s = []; if (f.title) s.push({ field: 'title', op: 'contains', value: f.title }); if (f.department) s.push({ field: 'department', op: 'eq', value: f.department }); if (f.status) s.push({ field: 'status', op: 'eq', value: f.status }); if (f.unit_id) s.push({ field: 'unit_id', op: 'eq', value: f.unit_id }); return s; }} />);
}
