import CrudScreen from '../components/CrudScreen';
import { noticesApi } from '../api/infoservice';
export default function NoticesPage() {
  return (<CrudScreen title="Notices" subtitle="Public notices — write and publish." section="info_notices" entityLabel="notice" api={noticesApi} initialSort="published_at"
    columns={[
      { key: 'title', label: 'Title', sortable: true, filterable: true, render: (r) => <strong>{r.title}</strong> },
      { key: 'is_published', label: 'State', width: 120, render: (r) => <span className={`pill ${r.is_published ? 'pill-ok' : 'pill-off'}`}>{r.is_published ? 'Published' : 'Draft'}</span> },
      { key: 'published_at', label: 'Publish date', width: 140, sortable: true, render: (r) => r.published_at || '—' },
      { key: 'author_name', label: 'Author', render: (r) => r.author_name || '—' },
    ]}
    fields={[
      { key: 'title', label: 'Title', required: true, span: 2 },
      { key: 'body', label: 'Body', type: 'textarea', span: 2 },
      { key: 'published_at', label: 'Publish date', type: 'date' },
      { key: 'is_published', label: 'Published', type: 'checkbox' },
    ]}
    toServerFilters={(f) => (f.title ? [{ field: 'title', op: 'contains', value: f.title }] : [])} />);
}
