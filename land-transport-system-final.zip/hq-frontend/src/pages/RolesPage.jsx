// src/pages/RolesPage.jsx — roles + the permission matrix (sections × actions).
import { useEffect, useState, useCallback } from 'react';
import { useAuth } from '../auth/AuthContext';
import { useToast } from '../components/Toast';
import { useConfirm } from '../components/ConfirmDialog';
import { useDataTable } from '../utils/useDataTable';
import { listRoles, createRole, updateRole, removeRole, getRolePermissions, setRolePermissions } from '../api/roles';
import { getSectionsAll, getActions, getMyAdminDomain } from '../api/admin';
import DataTable from '../components/DataTable';
import Modal from '../components/Modal';
import Field from '../components/Field';
import { Plus, Edit, Trash } from '../components/Icons';

const SECTION = 'admin_roles';

function flatten(tree, depth = 0, out = []) {
  tree.forEach((n) => { out.push({ id: n.id, name: n.name, depth, node_type: n.node_type }); if (n.children) flatten(n.children, depth + 1, out); });
  return out;
}

export default function RolesPage() {
  const { can } = useAuth();
  const toast = useToast();
  const confirm = useConfirm();

  const [sections, setSections] = useState([]);
  const [actions, setActions] = useState([]);
  const [domain, setDomain] = useState({ all: true });
  const [editing, setEditing] = useState(null);   // role row or {}
  const [form, setForm] = useState({});
  const [fieldErrors, setFieldErrors] = useState({});
  const [matrix, setMatrix] = useState(() => new Set()); // "sectionId:actionId"
  const [dirty, setDirty] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    getSectionsAll().then((r) => setSections(flatten(r.data))).catch(() => {});
    getActions().then((r) => setActions(r.data)).catch(() => {});
    getMyAdminDomain().then((r) => setDomain(r.data)).catch(() => setDomain({ all: true }));
  }, []);

  const fetcher = useCallback(({ page, pageSize, sort, dir, q, filters }, opts) => {
    const sf = [];
    if (filters.name) sf.push({ field: 'name', op: 'contains', value: filters.name });
    return listRoles({ page, limit: pageSize, sort, dir, q, filters: sf.length ? JSON.stringify(sf) : undefined }, opts);
  }, []);
  const table = useDataTable(fetcher, { initialSort: 'name' });

  const columns = [
    { key: 'name', label: 'Role', sortable: true, filterable: true, render: (r) => <strong>{r.name}</strong> },
    { key: 'code', label: 'Code', width: 160, sortable: true, render: (r) => <code style={{ fontSize: 'var(--fs-xs)' }}>{r.code}</code> },
    { key: 'perm_count', label: 'Permissions', width: 130, align: 'right', render: (r) => r.perm_count },
  ];

  const openNew = () => { setEditing({}); setForm({ name: '', code: '' }); setMatrix(new Set()); setFieldErrors({}); setDirty(false); };
  const openEdit = async (r) => {
    setEditing(r); setForm({ name: r.name, code: r.code }); setFieldErrors({}); setDirty(false);
    try { const perms = (await getRolePermissions(r.id)).data; setMatrix(new Set(perms.map((p) => `${p.section_id}:${p.action_id}`))); }
    catch { setMatrix(new Set()); }
  };

  const key = (s, a) => `${s}:${a}`;
  const editable = (s, a) => domain.all || ((domain.sectionIds || []).includes(s) && (domain.pairs || []).includes(`${s}:${a}`));
  const toggleCell = (s, a) => { setMatrix((m) => { const n = new Set(m); const k = key(s, a); n.has(k) ? n.delete(k) : n.add(k); return n; }); setDirty(true); };
  const toggleRow = (s) => {
    setMatrix((m) => { const n = new Set(m); const all = actions.every((a) => n.has(key(s, a.id)));
      actions.forEach((a) => { all ? n.delete(key(s, a.id)) : n.add(key(s, a.id)); }); return n; });
    setDirty(true);
  };

  const requestClose = async () => {
    if (dirty && !(await confirm({ title: 'Discard changes?', message: 'You have unsaved changes. Discard them?', confirmLabel: 'Discard', danger: true }))) return;
    setEditing(null); setDirty(false);
  };

  const save = async () => {
    setFieldErrors({}); setSaving(true);
    try {
      let roleId = editing.id;
      if (roleId) await updateRole(roleId, { name: form.name });
      else { const created = await createRole({ name: form.name, code: form.code }); roleId = created.data.id; }
      const permissions = [...matrix].map((k) => { const [section_id, action_id] = k.split(':').map(Number); return { section_id, action_id }; });
      await setRolePermissions(roleId, permissions);
      toast.success('Role saved.'); table.reload(); setEditing(null); setDirty(false);
    } catch (err) { if (err.fields) setFieldErrors(err.fields); else toast.error(err.message || 'Could not save role.'); }
    finally { setSaving(false); }
  };

  const del = async (r) => {
    if (!(await confirm({ title: 'Delete role?', message: `Delete "${r.name}"? Users keep their accounts but lose this role.`, confirmLabel: 'Delete', danger: true }))) return;
    try { await removeRole(r.id); toast.success('Role deleted.'); table.reload(); } catch { toast.error('Could not delete role.'); }
  };

  return (
    <div>
      <h1 style={{ fontSize: 'var(--fs-xl)' }}>Roles & permissions</h1>
      <p style={{ color: 'var(--ink-soft)', margin: '2px 0 14px', fontSize: 'var(--fs-sm)' }}>Define roles and grant them screen-level actions.</p>
      <div className="card" style={{ height: 'calc(100vh - var(--topbar-h) - 120px)', minHeight: 320, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
        <DataTable
          columns={columns}
          rows={table.rows} total={table.total} loading={table.loading} error={table.error} onRetry={table.reload}
          page={table.page} pageSize={table.pageSize} onPageChange={table.setPage} onPageSizeChange={table.setPageSize}
          sort={table.sort} dir={table.dir} onSort={table.toggleSort}
          filters={table.filters} onFilter={table.setFilter}
          q={table.q} onSearch={table.setQ}
          emptyText="No roles match."
          toolbarRight={can(SECTION, 'add') && <button className="btn btn-sm btn-primary" onClick={openNew}><Plus /> New role</button>}
          rowActions={(r) => (
            <span style={{ display: 'inline-flex', gap: 6 }}>
              {can(SECTION, 'edit') && <button className="btn btn-sm btn-ghost" onClick={() => openEdit(r)} aria-label="Edit"><Edit /></button>}
              {can(SECTION, 'remove') && <button className="btn btn-sm btn-danger" onClick={() => del(r)} aria-label="Delete"><Trash /></button>}
            </span>
          )}
        />
      </div>

      <Modal open={!!editing} title={editing?.id ? `Edit role: ${editing.name}` : 'New role'} onClose={requestClose} width={760}
        footer={(<>
          <button className="btn" onClick={requestClose}>Cancel</button>
          <button className="btn btn-primary" disabled={saving} onClick={save}>{saving ? 'Saving…' : 'Save role'}</button>
        </>)}>
        {editing && (
          <div>
            <div style={{ display: 'flex', gap: 12 }}>
              <Field label="Name" error={fieldErrors.name}><input className="input" value={form.name || ''} onChange={(e) => { setForm({ ...form, name: e.target.value }); setDirty(true); }} autoFocus /></Field>
              {!editing.id && <Field label="Code" error={fieldErrors.code}><input className="input" value={form.code || ''} onChange={(e) => { setForm({ ...form, code: e.target.value }); setDirty(true); }} placeholder="e.g. dispatcher" /></Field>}
            </div>
            <label className="label" style={{ marginTop: 6 }}>Permissions</label>
            <div className="matrix">
              <table>
                <thead>
                  <tr>
                    <th className="mx-sect">Section</th>
                    {actions.map((a) => <th key={a.id} className="mx-act">{a.code}</th>)}
                  </tr>
                </thead>
                <tbody>
                  {sections.map((s) => (
                    <tr key={s.id}>
                      <td className="mx-sect" style={{ paddingLeft: 10 + s.depth * 16 }}>
                        <button type="button" className="mx-rowtoggle" onClick={() => toggleRow(s.id)} title="Toggle row">{s.name}</button>
                      </td>
                      {actions.map((a) => (
                        <td key={a.id} className="mx-act">
                          <input type="checkbox" checked={matrix.has(key(s.id, a.id))} onChange={() => toggleCell(s.id, a.id)} />
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <p style={{ color: 'var(--ink-faint)', fontSize: 'var(--fs-xs)', marginTop: 8 }}>Tip: click a section name to toggle its whole row.</p>
          </div>
        )}
      </Modal>

      <style>{`
        .matrix { border: 1px solid var(--line); border-radius: var(--radius-sm); overflow: auto; max-height: 50vh; }
        .matrix table { width: 100%; border-collapse: collapse; font-size: var(--fs-sm); }
        .matrix thead th { position: sticky; top: 0; background: var(--surface-2); padding: 8px; border-bottom: 1px solid var(--line);
          font-size: var(--fs-xs); text-transform: uppercase; letter-spacing: .03em; color: var(--ink-soft); }
        .mx-sect { text-align: left; }
        .mx-act { text-align: center; width: 56px; }
        .matrix tbody td { padding: 6px 8px; border-bottom: 1px solid var(--line); }
        .mx-rowtoggle { border: none; background: transparent; cursor: pointer; color: var(--ink); font-size: var(--fs-sm); padding: 0; text-align: left; }
        .mx-rowtoggle:hover { color: var(--accent); }
      `}</style>
    </div>
  );
}
