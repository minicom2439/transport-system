// src/components/LookupAdminScreen.jsx — tabbed admin for standard lookup tables.
import { useEffect, useState, useCallback } from 'react';
import { useAuth } from '../auth/AuthContext';
import { useToast } from './Toast';
import { useConfirm } from './ConfirmDialog';
import { lookupsAdmin } from '../api/vehicleadmin';
import DataTable from './DataTable';
import Modal from './Modal';
import Field from './Field';
import { Plus, Edit, Trash } from './Icons';

export default function LookupAdminScreen({ title, subtitle, section, tabs }) {
  const { can } = useAuth();
  const toast = useToast();
  const confirm = useConfirm();
  const [active, setActive] = useState(tabs[0].table);
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({});
  const [fieldErrors, setFieldErrors] = useState({});
  const [saving, setSaving] = useState(false);

  const load = useCallback((table) => { setLoading(true); setError(null); lookupsAdmin.list(table).then((r) => setRows(r.data)).catch(setError).finally(() => setLoading(false)); }, []);
  useEffect(() => { load(active); }, [active, load]);

  const openNew = () => { setEditing({}); setForm({ name: '', code: '', description: '' }); setFieldErrors({}); };
  const openEdit = (r) => { setEditing(r); setForm({ name: r.name, code: r.code || '', description: r.description || '' }); setFieldErrors({}); };
  const save = async () => {
    setFieldErrors({}); setSaving(true);
    try {
      if (editing.id) await lookupsAdmin.update(active, editing.id, form);
      else await lookupsAdmin.create(active, form);
      toast.success('Saved.'); setEditing(null); load(active);
    } catch (err) { if (err.fields) setFieldErrors(err.fields); else toast.error(err.message || 'Could not save.'); }
    finally { setSaving(false); }
  };
  const del = async (r) => { if (!(await confirm({ title: 'Remove item?', message: `Remove "${r.name}"?`, confirmLabel: 'Remove', danger: true }))) return; try { await lookupsAdmin.remove(active, r.id); toast.success('Removed.'); load(active); } catch { toast.error('Could not remove.'); } };

  const columns = [
    { key: 'name', label: 'Name', render: (r) => <strong>{r.name}</strong> },
    { key: 'code', label: 'Code', width: 120, render: (r) => r.code || '—' },
    { key: 'description', label: 'Description', render: (r) => r.description || '—' },
  ];

  return (
    <div>
      <h1 style={{ fontSize: 'var(--fs-xl)' }}>{title}</h1>
      {subtitle && <p style={{ color: 'var(--ink-soft)', margin: '2px 0 14px', fontSize: 'var(--fs-sm)' }}>{subtitle}</p>}
      <div className="tabs">
        {tabs.map((t) => <button key={t.table} className={`tab ${active === t.table ? 'on' : ''}`} onClick={() => setActive(t.table)}>{t.label}</button>)}
      </div>
      <div className="card" style={{ height: 'calc(100vh - var(--topbar-h) - 168px)', minHeight: 300, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
        <DataTable
          columns={columns} rows={rows} total={rows.length} loading={loading} error={error} onRetry={() => load(active)}
          emptyText="No items yet."
          toolbarRight={can(section, 'add') && <button className="btn btn-sm btn-primary" onClick={openNew}><Plus /> New</button>}
          rowActions={(can(section, 'edit') || can(section, 'remove')) ? (r) => (
            <span style={{ display: 'inline-flex', gap: 6 }}>
              {can(section, 'edit') && <button className="btn btn-sm btn-ghost" onClick={() => openEdit(r)} aria-label="Edit"><Edit /></button>}
              {can(section, 'remove') && <button className="btn btn-sm btn-danger" onClick={() => del(r)} aria-label="Remove"><Trash /></button>}
            </span>
          ) : undefined}
        />
      </div>

      <Modal open={!!editing} title={editing?.id ? 'Edit item' : 'New item'} onClose={() => setEditing(null)} width={460}
        footer={(<><button className="btn" onClick={() => setEditing(null)}>Cancel</button><button className="btn btn-primary" disabled={saving} onClick={save}>{saving ? 'Saving…' : 'Save'}</button></>)}>
        {editing && (
          <form onSubmit={(e) => { e.preventDefault(); save(); }}>
            <Field label="Name" error={fieldErrors.name}><input className="input" value={form.name || ''} onChange={(e) => setForm({ ...form, name: e.target.value })} autoFocus /></Field>
            <Field label="Code"><input className="input" value={form.code || ''} onChange={(e) => setForm({ ...form, code: e.target.value })} /></Field>
            <Field label="Description"><textarea className="input" style={{ height: 60, padding: 8 }} value={form.description || ''} onChange={(e) => setForm({ ...form, description: e.target.value })} /></Field>
          </form>
        )}
      </Modal>

      <style>{`
        .tabs { display: flex; flex-wrap: wrap; gap: 4px; margin-bottom: 12px; border-bottom: 1px solid var(--line); }
        .tab { border: none; background: transparent; padding: 8px 12px; cursor: pointer; font-size: var(--fs-sm); color: var(--ink-soft); border-bottom: 2px solid transparent; margin-bottom: -1px; }
        .tab:hover { color: var(--ink); }
        .tab.on { color: var(--accent-ink); border-bottom-color: var(--accent); font-weight: 600; }
      `}</style>
    </div>
  );
}
