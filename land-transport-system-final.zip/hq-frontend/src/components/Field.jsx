// src/components/Field.jsx — labeled form control with optional inline error.
export default function Field({ label, error, children }) {
  return (
    <div style={{ marginBottom: 14 }}>
      {label && <label className="label">{label}</label>}
      {children}
      {error && <div style={{ color: 'var(--danger)', fontSize: 'var(--fs-xs)', marginTop: 4 }}>{error}</div>}
    </div>
  );
}
