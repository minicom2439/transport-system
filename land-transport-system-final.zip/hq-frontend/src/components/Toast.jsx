// src/components/Toast.jsx — toast notifications (success auto-dismiss, errors persist).
import { createContext, useContext, useState, useCallback } from 'react';
import { X, Check } from './Icons';

const ToastContext = createContext(null);
let seq = 0;

export function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([]);
  const remove = useCallback((id) => setToasts((t) => t.filter((x) => x.id !== id)), []);
  const push = useCallback((type, message) => {
    const id = ++seq;
    setToasts((t) => [...t, { id, type, message }]);
    if (type !== 'error') setTimeout(() => remove(id), 4000);
  }, [remove]);

  const toast = {
    success: (m) => push('success', m),
    error: (m) => push('error', m),
    info: (m) => push('info', m),
  };

  return (
    <ToastContext.Provider value={toast}>
      {children}
      <div className="toast-wrap" aria-live="polite" aria-atomic="false">
        {toasts.map((t) => (
          <div key={t.id} className={`toast toast-${t.type}`} role={t.type === 'error' ? 'alert' : 'status'}>
            <span className="toast-ic">{t.type === 'success' ? <Check /> : t.type === 'error' ? <X /> : null}</span>
            <span className="toast-msg">{t.message}</span>
            <button className="toast-close" onClick={() => remove(t.id)} aria-label="Dismiss"><X /></button>
          </div>
        ))}
      </div>
      <style>{`
        .toast-wrap { position: fixed; top: 16px; right: 16px; z-index: 100; display: flex; flex-direction: column; gap: 8px; max-width: 360px; }
        .toast { display: flex; align-items: flex-start; gap: 8px; padding: 10px 12px; border-radius: var(--radius-sm);
          background: var(--surface); border: 1px solid var(--line); box-shadow: var(--shadow-2); font-size: var(--fs-sm); }
        .toast-success { border-left: 3px solid var(--ok); }
        .toast-error { border-left: 3px solid var(--danger); }
        .toast-info { border-left: 3px solid var(--accent); }
        .toast-ic { display: inline-flex; color: var(--ok); flex: 0 0 auto; margin-top: 1px; }
        .toast-error .toast-ic { color: var(--danger); }
        .toast-msg { flex: 1; color: var(--ink); }
        .toast-close { border: none; background: transparent; cursor: pointer; color: var(--ink-faint); display: inline-flex; padding: 0; }
        .toast-close:hover { color: var(--ink); }
      `}</style>
    </ToastContext.Provider>
  );
}

export function useToast() {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error('useToast must be used within ToastProvider');
  return ctx;
}
