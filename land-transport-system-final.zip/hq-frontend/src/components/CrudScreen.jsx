// src/components/CrudScreen.jsx
// Reusable master-data screen: server-side table (sort/filter/search/paginate),
// modal editor with validation + dirty guard, toasts and confirm dialogs.
// Screens supply columns, form fields, api, and (optionally) select lookups.
import { useState, useCallback } from 'react';
import { useAuth } from '../auth/AuthContext';
import { useToast } from './Toast';
import { useConfirm } from './ConfirmDialog';
import { useDataTable } from '../utils/useDataTable';
import DataTable from './DataTable';
import TreeView from './TreeView';
import Modal from './Modal';
import Field from './Field';
import { exportToExcel } from '../utils/exportExcel';
import { Plus, Edit, Trash, Download } from './Icons';

export default function CrudScreen({
  title, subtitle, section, columns, fields, api,
  initialSort, toServerFilters, lookups = {}, entityLabel = 'record',
  searchable = true, exportable = true, readOnly = false, tree = null, rowExtra = null,
}) {
  const { can } = useAuth();
  const toast = useToast();
  const confirm = useConfirm();

  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({});
  const [fieldErrors, setFieldErrors] = useState({});
  const [dirty, setDirty] = useState(false);
  const [saving, setSaving] = useState(false);
  const [treeOpen, setTreeOpen] = useState(true);

  const fetcher = useCallback(({ page, pageSize, sort, dir, q, filters }, opts) => {
    const sf = toServerFilters ? toServerFilters(filters) : [];
    return api.list({ page, limit: pageSize, sort, dir, q: searchable ? q : undefined, filters: sf.length ? JSON.stringify(sf) : undefined }, opts);
  }, [api, toServerFilters, searchable]);
  const table = useDataTable(fetcher, { initialSort });

  const blankForm = () => Object.fromEntries(fields.map((f) => [f.key, f.type === 'checkbox' ? false : '']));
  const openNew = () => { setEditing({}); setForm(blankForm()); setFieldErrors({}); setDirty(false); };
  const openEdit = (row) => {
    const f = {};
    fields.forEach((fl) => { f[fl.key] = fl.type === 'checkbox' ? !!row[fl.key] : (row[fl.key] ?? ''); });
    setEditing(row); setForm(f); setFieldErrors({}); setDirty(false);
  };
  const change = (k, v) => { setForm((f) => ({ ...f, [k]: v })); setDirty(true); };

  const requestClose = async () => {
    if (dirty && !(await confirm({ title: 'Discard changes?', message: 'You have unsaved changes. Discard them?', confirmLabel: 'Discard', danger: true }))) return;
    setEditing(null); setDirty(false); setFieldErrors({});
  };

  const save = async () => {
    setFieldErrors({}); setSaving(true);
    const body = {}; fields.forEach((f) => { body[f.key] = form[f.key]; });
    try {
      if (editing.id) { await api.update(editing.id, body); toast.success('Saved.'); }
      else { await api.create(body); toast.success('Created.'); }
      table.reload(); setEditing(null); setDirty(false);
    } catch (err) { if (err.fields) setFieldErrors(err.fields); else toast.error(err.message || 'Could not save.'); }
    finally { setSaving(false); }
  };

  const del = async (row) => {
    if (!(await confirm({ title: `Remove ${entityLabel}?`, message: `Remove this ${entityLabel}? It will be hidden from lists.`, confirmLabel: 'Remove', danger: true }))) return;
    try { await api.remove(row.id); toast.success('Removed.'); table.reload(); } catch { toast.error('Could not remove.'); }
  };

  const renderField = (f) => {
    const v = form[f.key];
    if (f.type === 'checkbox') return <label style={{ display: 'flex', gap: 6, alignItems: 'center', fontSize: 'var(--fs-sm)' }}><input type="checkbox" checked={!!v} onChange={(e) => change(f.key, e.target.checked)} /> {f.label}</label>;
    if (f.type === 'select') {
      const opts = f.options || lookups[f.optionsKey] || [];
      return <select className="input" value={v || ''} onChange={(e) => change(f.key, e.target.value)}><option value="">{f.placeholder || 'Select…'}</option>{opts.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}</select>;
    }
    if (f.type === 'textarea') return <textarea className="input" style={{ height: 70, padding: 8 }} value={v || ''} onChange={(e) => change(f.key, e.target.value)} />;
    return <input className="input" type={f.type === 'number' ? 'number' : f.type === 'date' ? 'date' : 'text'} value={v ?? ''} onChange={(e) => change(f.key, e.target.value)} />;
  };

  return (
    <div>
      <h1 style={{ fontSize: 'var(--fs-xl)' }}>{title}</h1>
      {subtitle && <p style={{ color: 'var(--ink-soft)', margin: '2px 0 14px', fontSize: 'var(--fs-sm)' }}>{subtitle}</p>}
      {tree ? (
        <div className={`master-detail card${treeOpen ? '' : ' tree-collapsed'}`}>
          <aside className="md-left">
            <TreeView header={tree.title} nodes={tree.nodes} selectedId={Number(table.filters[tree.filterKey]) || 0} onSelect={(n) => table.setFilter(tree.filterKey, n.id === 0 ? '' : n.id)} />
          </aside>
          <section className="md-right">
            <div className="md-toolbar"><button className="btn btn-sm btn-ghost" onClick={() => setTreeOpen((v) => !v)}>{treeOpen ? '◂ Hide' : '▸ ' + tree.title}</button></div>
        <DataTable
          columns={columns}
          rows={table.rows} total={table.total} loading={table.loading} error={table.error} onRetry={table.reload}
          page={table.page} pageSize={table.pageSize} onPageChange={table.setPage} onPageSizeChange={table.setPageSize}
          sort={table.sort} dir={table.dir} onSort={table.toggleSort}
          filters={table.filters} onFilter={table.setFilter}
          q={searchable ? table.q : undefined} onSearch={searchable ? table.setQ : undefined}
          density={table.density} onDensityChange={table.setDensity}
          emptyText={`No ${entityLabel}s match.`}
          toolbarRight={(
            <>
              {exportable && can(section, 'export') && <button className="btn btn-sm" onClick={() => exportToExcel(title, columns.map((c) => ({ label: c.label, value: c.exportValue || ((r) => r[c.key]) })), table.rows)}><Download /> Export</button>}
              {!readOnly && can(section, 'add') && <button className="btn btn-sm btn-primary" onClick={openNew}><Plus /> New</button>}
            </>
          )}
          rowActions={((!readOnly && (can(section, 'edit') || can(section, 'remove'))) || rowExtra) ? (r) => (
            <span style={{ display: 'inline-flex', gap: 6 }}>
              {rowExtra && rowExtra(r)}
              {!readOnly && can(section, 'edit') && <button className="btn btn-sm btn-ghost" onClick={() => openEdit(r)} aria-label="Edit"><Edit /></button>}
              {!readOnly && can(section, 'remove') && <button className="btn btn-sm btn-danger" onClick={() => del(r)} aria-label="Remove"><Trash /></button>}
            </span>
          ) : undefined}
        />
          </section>
          <style>{`
            .master-detail { display: grid; grid-template-columns: 240px 1fr; height: calc(100vh - var(--topbar-h) - 116px); overflow: hidden; transition: grid-template-columns .16s ease; }
            .master-detail.tree-collapsed { grid-template-columns: 0 1fr; }
            .md-left { border-right: 1px solid var(--line); overflow: auto; min-width: 0; }
            .master-detail.tree-collapsed .md-left { border-right: none; }
            .md-right { min-width: 0; display: flex; flex-direction: column; }
            .md-toolbar { display: flex; align-items: center; gap: 12px; padding: 6px 8px; border-bottom: 1px solid var(--line); background: var(--surface-2); }
            @media (max-width: 760px) { .master-detail, .master-detail.tree-collapsed { grid-template-columns: 1fr; } .md-left { display: none; } }
          `}</style>
        </div>
      ) : (
        <div className="card" style={{ height: 'calc(100vh - var(--topbar-h) - 120px)', minHeight: 320, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
        <DataTable
          columns={columns}
          rows={table.rows} total={table.total} loading={table.loading} error={table.error} onRetry={table.reload}
          page={table.page} pageSize={table.pageSize} onPageChange={table.setPage} onPageSizeChange={table.setPageSize}
          sort={table.sort} dir={table.dir} onSort={table.toggleSort}
          filters={table.filters} onFilter={table.setFilter}
          q={searchable ? table.q : undefined} onSearch={searchable ? table.setQ : undefined}
          density={table.density} onDensityChange={table.setDensity}
          emptyText={`No ${entityLabel}s match.`}
          toolbarRight={(
            <>
              {exportable && can(section, 'export') && <button className="btn btn-sm" onClick={() => exportToExcel(title, columns.map((c) => ({ label: c.label, value: c.exportValue || ((r) => r[c.key]) })), table.rows)}><Download /> Export</button>}
              {!readOnly && can(section, 'add') && <button className="btn btn-sm btn-primary" onClick={openNew}><Plus /> New</button>}
            </>
          )}
          rowActions={((!readOnly && (can(section, 'edit') || can(section, 'remove'))) || rowExtra) ? (r) => (
            <span style={{ display: 'inline-flex', gap: 6 }}>
              {rowExtra && rowExtra(r)}
              {!readOnly && can(section, 'edit') && <button className="btn btn-sm btn-ghost" onClick={() => openEdit(r)} aria-label="Edit"><Edit /></button>}
              {!readOnly && can(section, 'remove') && <button className="btn btn-sm btn-danger" onClick={() => del(r)} aria-label="Remove"><Trash /></button>}
            </span>
          ) : undefined}
        />
        </div>
      )}

      <Modal open={!!editing} title={editing?.id ? `Edit ${entityLabel}` : `New ${entityLabel}`} onClose={requestClose} width={540}
        footer={(<><button className="btn" onClick={requestClose}>Cancel</button><button className="btn btn-primary" disabled={saving} onClick={save}>{saving ? 'Saving…' : (editing?.id ? 'Save changes' : 'Create')}</button></>)}>
        {editing && (
          <form onSubmit={(e) => { e.preventDefault(); save(); }}>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 12 }}>
              {fields.map((f) => (
                <div key={f.key} style={{ flex: f.span === 2 ? '1 1 100%' : '1 1 calc(50% - 6px)', minWidth: 0 }}>
                  {f.type === 'checkbox' ? <div style={{ marginTop: 22 }}>{renderField(f)}</div> : <Field label={f.label} error={fieldErrors[f.key]}>{renderField(f)}</Field>}
                </div>
              ))}
            </div>
          </form>
        )}
      </Modal>
    </div>
  );
}
