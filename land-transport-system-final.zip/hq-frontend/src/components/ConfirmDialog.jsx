// src/components/ConfirmDialog.jsx — promise-based confirm(), replaces window.confirm.
import { createContext, useContext, useState, useCallback, useRef } from 'react';
import Modal from './Modal';

const ConfirmContext = createContext(null);

export function ConfirmProvider({ children }) {
  const [state, setState] = useState(null); // { title, message, confirmLabel, danger }
  const resolver = useRef(null);

  const confirm = useCallback((opts) => new Promise((resolve) => {
    resolver.current = resolve;
    setState({ confirmLabel: 'Confirm', danger: false, ...opts });
  }), []);

  const close = (result) => { setState(null); if (resolver.current) resolver.current(result); resolver.current = null; };

  return (
    <ConfirmContext.Provider value={confirm}>
      {children}
      <Modal
        open={!!state}
        title={state?.title || 'Please confirm'}
        onClose={() => close(false)}
        width={420}
        footer={(
          <>
            <button className="btn" onClick={() => close(false)}>Cancel</button>
            <button className={`btn ${state?.danger ? 'btn-danger' : 'btn-primary'}`} onClick={() => close(true)}>
              {state?.confirmLabel}
            </button>
          </>
        )}
      >
        <p style={{ margin: 0, color: 'var(--ink-soft)', fontSize: 'var(--fs-md)' }}>{state?.message}</p>
      </Modal>
    </ConfirmContext.Provider>
  );
}

export function useConfirm() {
  const ctx = useContext(ConfirmContext);
  if (!ctx) throw new Error('useConfirm must be used within ConfirmProvider');
  return ctx;
}
