// src/components/DataTable.jsx — the ERP data grid.
// Optional features activate when their handlers are supplied (sortable headers,
// filter row, global search, density, page size, selection). Works with or
// without the useDataTable hook.
import { Search, CaretUp, CaretDown, Check } from './Icons';

export default function DataTable({
  columns = [],
  rows = [], total = 0, loading = false, error = null, onRetry,
  page = 0, pageSize = 25, onPageChange, onPageSizeChange,
  sort = null, dir = 'asc', onSort,
  filters = {}, onFilter,
  q, onSearch,
  density = 'comfortable', onDensityChange,
  selectable = false, selected, onToggleSelect, onToggleSelectAll, allSelected = false, bulkBar,
  rowActions, rowKey = (r) => r.id, emptyText = 'No records.', toolbarRight,
}) {
  const pages = Math.max(1, Math.ceil(total / pageSize));
  const from = total === 0 ? 0 : page * pageSize + 1;
  const to = Math.min(total, (page + 1) * pageSize);
  const hasFilterRow = !!onFilter && columns.some((c) => c.filterable);
  const colCount = columns.length + (selectable ? 1 : 0) + (rowActions ? 1 : 0);
  const compact = density === 'compact';

  return (
    <div className={`dt ${compact ? 'dt-compact' : ''}`}>
      <div className="dt-top">
        <div className="dt-top-left">
          {onSearch && (
            <span className="dt-search">
              <Search />
              <input className="input" placeholder="Search…" value={q || ''} onChange={(e) => onSearch(e.target.value)} />
            </span>
          )}
        </div>
        <div className="dt-top-right">
          {toolbarRight}
          {onDensityChange && (
            <button className="btn btn-sm" onClick={() => onDensityChange(compact ? 'comfortable' : 'compact')}>
              {compact ? 'Comfortable' : 'Compact'}
            </button>
          )}
        </div>
      </div>

      {selectable && selected && selected.size > 0 && (
        <div className="dt-bulk">
          <span>{selected.size} selected</span>
          <span className="dt-bulk-actions">{bulkBar}</span>
        </div>
      )}

      <div className="dt-scroll">
        <table>
          <thead>
            <tr>
              {selectable && (
                <th className="dt-check">
                  <button className={`cbox ${allSelected ? 'on' : ''}`} onClick={onToggleSelectAll} aria-label="Select all">
                    {allSelected && <Check />}
                  </button>
                </th>
              )}
              {columns.map((c) => {
                const sortable = onSort && c.sortable;
                const active = sort === (c.sortKey || c.key);
                return (
                  <th key={c.key} style={{ width: c.width, textAlign: c.align || 'left' }}
                      className={sortable ? 'sortable' : ''}
                      aria-sort={active ? (dir === 'asc' ? 'ascending' : 'descending') : 'none'}
                      onClick={sortable ? () => onSort(c.sortKey || c.key) : undefined}>
                    <span className="th-in">{c.label}
                      {sortable && <span className="th-sort">{active ? (dir === 'asc' ? <CaretUp /> : <CaretDown />) : <span className="th-sort-idle">↕</span>}</span>}
                    </span>
                  </th>
                );
              })}
              {rowActions && <th style={{ width: 1 }} />}
            </tr>
            {hasFilterRow && (
              <tr className="dt-filters">
                {selectable && <th />}
                {columns.map((c) => (
                  <th key={c.key}>
                    {c.filterable && c.filterType === 'select' ? (
                      <select className="input" value={filters[c.filterKey || c.key] || ''} onChange={(e) => onFilter(c.filterKey || c.key, e.target.value)}>
                        <option value="">All</option>
                        {(c.options || []).map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
                      </select>
                    ) : c.filterable ? (
                      <input className="input" type={c.filterType === 'number' ? 'number' : 'text'} placeholder="Filter"
                        value={filters[c.filterKey || c.key] || ''} onChange={(e) => onFilter(c.filterKey || c.key, e.target.value)} />
                    ) : null}
                  </th>
                ))}
                {rowActions && <th />}
              </tr>
            )}
          </thead>
          <tbody>
            {loading && <tr><td colSpan={colCount} className="dt-state">Loading…</td></tr>}
            {!loading && error && (
              <tr><td colSpan={colCount} className="dt-state">
                Could not load data. {onRetry && <button className="btn btn-sm" onClick={onRetry}>Retry</button>}
              </td></tr>
            )}
            {!loading && !error && rows.length === 0 && <tr><td colSpan={colCount} className="dt-state">{emptyText}</td></tr>}
            {!loading && !error && rows.map((r) => {
              const id = rowKey(r);
              const isSel = selectable && selected && selected.has(id);
              return (
                <tr key={id} className={isSel ? 'is-sel' : ''}>
                  {selectable && (
                    <td className="dt-check">
                      <button className={`cbox ${isSel ? 'on' : ''}`} onClick={() => onToggleSelect(id)} aria-label="Select row">
                        {isSel && <Check />}
                      </button>
                    </td>
                  )}
                  {columns.map((c) => (
                    <td key={c.key} style={{ textAlign: c.align || 'left' }}>
                      {c.render ? c.render(r) : (c.format ? c.format(r[c.key]) : r[c.key])}
                    </td>
                  ))}
                  {rowActions && <td className="dt-actions">{rowActions(r)}</td>}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {onPageChange && (
        <div className="dt-foot">
          <span className="dt-count">{from}–{to} of {total}</span>
          <span className="dt-pager">
            {onPageSizeChange && (
              <select className="input dt-size" value={pageSize} onChange={(e) => onPageSizeChange(Number(e.target.value))}>
                {[25, 50, 100].map((n) => <option key={n} value={n}>{n}/page</option>)}
              </select>
            )}
            <button className="btn btn-sm" disabled={page <= 0} onClick={() => onPageChange(page - 1)}>Prev</button>
            <span className="dt-page">Page {page + 1} / {pages}</span>
            <button className="btn btn-sm" disabled={page + 1 >= pages} onClick={() => onPageChange(page + 1)}>Next</button>
          </span>
        </div>
      )}

      <style>{`
        .dt { display: flex; flex-direction: column; min-height: 0; height: 100%; }
        .dt-top { display: flex; align-items: center; justify-content: space-between; gap: 10px; padding: 8px 10px;
          border-bottom: 1px solid var(--line); background: var(--surface); flex-wrap: wrap; }
        .dt-top-left { flex: 1; min-width: 180px; }
        .dt-top-right { display: flex; align-items: center; gap: 8px; }
        .dt-search { display: flex; align-items: center; gap: 6px; color: var(--ink-faint); max-width: 320px; }
        .dt-search .input { height: 30px; }
        .dt-bulk { display: flex; align-items: center; justify-content: space-between; gap: 12px; padding: 6px 12px;
          background: var(--accent-soft); color: var(--accent-ink); font-size: var(--fs-sm); }
        .dt-bulk-actions { display: flex; gap: 8px; }
        .dt-scroll { overflow: auto; flex: 1; }
        table { border-collapse: collapse; width: 100%; font-size: var(--fs-sm); }
        thead th { position: sticky; top: 0; background: var(--surface-2); text-align: left; font-weight: 650;
          color: var(--ink-soft); padding: 8px 12px; border-bottom: 1px solid var(--line); font-size: var(--fs-xs);
          text-transform: uppercase; letter-spacing: .03em; white-space: nowrap; }
        th.sortable { cursor: pointer; user-select: none; }
        th.sortable:hover { color: var(--ink); }
        .th-in { display: inline-flex; align-items: center; gap: 4px; }
        .th-sort { display: inline-flex; }
        .th-sort svg { width: 13px; height: 13px; }
        .th-sort-idle { color: var(--ink-faint); font-size: 11px; }
        .dt-filters th { top: 33px; padding: 5px 8px; background: var(--surface); }
        .dt-filters .input { height: 28px; }
        tbody td { padding: 9px 12px; border-bottom: 1px solid var(--line); }
        .dt-compact tbody td { padding: 5px 12px; }
        .dt-compact thead th { padding: 6px 12px; }
        tbody tr:hover { background: var(--surface-2); }
        tbody tr.is-sel { background: var(--accent-soft); }
        .dt-state { text-align: center; color: var(--ink-faint); padding: 28px; }
        .dt-actions { white-space: nowrap; text-align: right; }
        .dt-check { width: 36px; text-align: center; }
        .cbox { width: 17px; height: 17px; border: 1.5px solid var(--line-strong); border-radius: 4px; background: var(--surface);
          cursor: pointer; display: inline-flex; align-items: center; justify-content: center; color: #fff; padding: 0; }
        .cbox.on { background: var(--accent); border-color: var(--accent); }
        .cbox svg { width: 12px; height: 12px; }
        .dt-foot { display: flex; align-items: center; justify-content: space-between; padding: 8px 12px;
          border-top: 1px solid var(--line); background: var(--surface); }
        .dt-count { color: var(--ink-soft); font-size: var(--fs-sm); }
        .dt-pager { display: flex; align-items: center; gap: 10px; }
        .dt-size { height: 28px; width: auto; }
        .dt-page { color: var(--ink-soft); font-size: var(--fs-sm); }
      `}</style>
    </div>
  );
}
