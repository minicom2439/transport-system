// src/components/TreeView.jsx — reusable expandable tree (left master panel).
import { useState } from 'react';
import { Chevron } from './Icons';

function Node({ node, depth, selectedId, onSelect }) {
  const [open, setOpen] = useState(depth < 1);
  const hasKids = node.children && node.children.length > 0;
  const selected = selectedId === node.id;
  return (
    <div>
      <div
        className="tree-row"
        style={{ paddingLeft: 8 + depth * 14, background: selected ? 'var(--accent-soft)' : 'transparent',
                 color: selected ? 'var(--accent-ink)' : 'var(--ink)' }}
        onClick={() => onSelect && onSelect(node)}
      >
        <span
          className="tree-caret"
          onClick={(e) => { e.stopPropagation(); if (hasKids) setOpen(!open); }}
          style={{ visibility: hasKids ? 'visible' : 'hidden' }}
        >
          <Chevron open={open} />
        </span>
        <span className="tree-label">{node.name || node.label}</span>
      </div>
      {hasKids && open && node.children.map((c) => (
        <Node key={c.id} node={c} depth={depth + 1} selectedId={selectedId} onSelect={onSelect} />
      ))}
    </div>
  );
}

export default function TreeView({ nodes = [], selectedId, onSelect, header }) {
  return (
    <div className="tree">
      {header && <div className="tree-header">{header}</div>}
      {nodes.length === 0 && <div className="tree-empty">No items</div>}
      {nodes.map((n) => (
        <Node key={n.id} node={n} depth={0} selectedId={selectedId} onSelect={onSelect} />
      ))}
      <style>{`
        .tree { padding: 6px; }
        .tree-header { font-size: var(--fs-xs); font-weight: 700; text-transform: uppercase;
          letter-spacing: .05em; color: var(--ink-faint); padding: 6px 8px; }
        .tree-empty { color: var(--ink-faint); padding: 8px; font-size: var(--fs-sm); }
        .tree-row { display: flex; align-items: center; gap: 4px; height: 30px; padding-right: 8px;
          border-radius: var(--radius-sm); cursor: pointer; font-size: var(--fs-sm); }
        .tree-row:hover { background: var(--surface-2); }
        .tree-caret { display: inline-flex; width: 18px; color: var(--ink-faint); }
        .tree-label { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
      `}</style>
    </div>
  );
}
