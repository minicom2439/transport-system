// src/components/Sidebar.jsx — collapsible system rail, renders the nested
// section tree (systems → groups → screens) to any depth.
import { useEffect, useState } from 'react';
import { NavLink } from 'react-router-dom';
import { getNav } from '../api/meta';
import { Building, Truck, Chart, Grid, Users, Shield, Inbox, FileText, IdCard, Warehouse, RouteIcon, Calendar, Award, Package, Exchange, Database, Alert, Receipt, Satellite, MapPin, Megaphone, Download, Help, Mail, Upload, Search } from './Icons';

// Leaf screen code -> route + icon. Screens without an entry render as disabled.
const SCREEN_ROUTES = {
  land_ops_units: { to: '/units', icon: Building },
  land_ops_conditions: { to: '/conditions', icon: FileText },
  land_ops_routes: { to: '/routes', icon: RouteIcon },
  land_ops_route_certs: { to: '/route-certs', icon: Award },
  land_ops_schedules: { to: '/schedules', icon: Calendar },
  land_ops_park_vehicles: { to: '/park-vehicles', icon: Truck },
  land_ops_warehouses: { to: '/warehouses', icon: Warehouse },
  land_ops_transfer_sections: { to: '/transfer-sections', icon: Exchange },
  land_ops_orders: { to: '/orders', icon: Package },
  land_ops_reports: { to: '/reports', icon: FileText },
  land_ops_unit_stats: { to: '/unit-stats', icon: Chart },
  land_ops_finance: { to: '/finance', icon: Receipt },
  land_ops_licenses: { to: '/licenses', icon: Award },
  land_ops_indicators: { to: '/indicators', icon: Database },
  land_ops_online: { to: '/online-status', icon: Chart },
  vehicle_admin_register: { to: '/vehicles', icon: Truck },
  vehicle_admin_parks: { to: '/parks', icon: Warehouse },
  vehicle_admin_basic_data: { to: '/basic-data', icon: Database },
  vehicle_admin_accidents: { to: '/accidents', icon: Alert },
  vehicle_admin_invoices: { to: '/invoices', icon: Receipt },
  vehicle_admin_command_orders: { to: '/command-orders', icon: FileText },
  sci_gps: { to: '/gps', icon: Satellite },
  sci_location: { to: '/vehicle-locations', icon: MapPin },
  info_notices: { to: '/notices', icon: Megaphone },
  info_programs: { to: '/programs', icon: Download },
  info_faqs: { to: '/faqs', icon: Help },
  info_feedback: { to: '/feedback', icon: Mail },
  info_submissions: { to: '/submissions', icon: Upload },
  integration_traveler_stats: { to: '/integration/traveler', icon: Chart },
  integration_thing_stats: { to: '/integration/thing', icon: Package },
  integration_einvoice: { to: '/integration/e-invoices', icon: Receipt },
  integration_parks: { to: '/integration/parks', icon: Warehouse },
  integration_accidents: { to: '/integration/accidents', icon: Alert },
  integration_locations: { to: '/integration/locations', icon: MapPin },
  pp_monthly: { to: '/monthly-reports', icon: FileText },
  pp_effort: { to: '/effort-plans', icon: Chart },
  pp_electricity: { to: '/electricity-reports', icon: Chart },
  eqr_equipment: { to: '/equipment', icon: Database },
  eqr_inspections: { to: '/equipment-inspections', icon: Grid },
  eqr_no_accident: { to: '/no-accident', icon: Shield },
  cmp_daily_reports: { to: '/business-daily', icon: FileText },
  cmp_weekly: { to: '/weekly-schedules', icon: Calendar },
  fin_stats: { to: '/finance-stats', icon: Chart },
  land_ops_ultimate_stats: { to: '/ultimate-stats', icon: Chart },
  cmp_defense: { to: '/guard-duties', icon: Shield },
  ow_water: { to: '/ow/water', icon: FileText },
  ow_revenue: { to: '/ow/revenue', icon: Receipt },
  em_daily: { to: '/effort-manage/daily', icon: FileText },
  fbc_daily: { to: '/first-business/daily', icon: FileText },
  info_search: { to: '/search', icon: Search },



  other_staff: { to: '/staff', icon: IdCard },
  admin_users: { to: '/admin/users', icon: Users },
  admin_roles: { to: '/admin/roles', icon: Shield },
  admin_requests: { to: '/admin/requests', icon: Inbox },
};

function collectLeaves(nodes, out = []) {
  nodes.forEach((n) => { if (n.children && n.children.length) collectLeaves(n.children, out); else if (SCREEN_ROUTES[n.code]) out.push(n); });
  return out;
}

function Branch({ node, depth }) {
  const [open, setOpen] = useState(true);
  const hasKids = node.children && node.children.length > 0;
  if (hasKids) {
    return (
      <div className="rail-group">
        <button className="rail-grouphead" style={{ paddingLeft: 8 + depth * 12 }} onClick={() => setOpen((v) => !v)}>
          <span className={`gh-caret ${open ? 'o' : ''}`}>▸</span>{node.name}
        </button>
        {open && node.children.map((c) => <Branch key={c.id} node={c} depth={depth + 1} />)}
      </div>
    );
  }
  const r = SCREEN_ROUTES[node.code];
  if (!r) return <div className="rail-link is-disabled" style={{ paddingLeft: 10 + depth * 12 }} title={`${node.name} (not built yet)`}><span className="rail-ic"><Grid /></span><span className="rail-text">{node.name}</span></div>;
  const Icon = r.icon || Grid;
  return <NavLink to={r.to} className="rail-link" style={{ paddingLeft: 10 + depth * 12 }} title={node.name}><span className="rail-ic"><Icon /></span><span className="rail-text">{node.name}</span></NavLink>;
}

export default function Sidebar({ mode = 'full', open = false }) {
  const [nav, setNav] = useState([]);
  useEffect(() => { getNav().then((r) => setNav(r.data)).catch(() => setNav([])); }, []);
  const mini = mode === 'mini';
  const drawer = mode === 'drawer';
  const cls = `rail rail-${mode}` + (drawer && open ? ' is-open' : '');

  return (
    <nav className={cls} aria-label="Primary">
      <NavLink to="/" end className="rail-link" title="Dashboard" style={{ paddingLeft: 10 }}>
        <span className="rail-ic"><Grid /></span>{!mini && <span className="rail-text">Dashboard</span>}
      </NavLink>
      <div className="rail-scroll">
        {mini
          ? collectLeaves(nav).map((n) => { const Icon = SCREEN_ROUTES[n.code].icon || Grid; return <NavLink key={n.id} to={SCREEN_ROUTES[n.code].to} className="rail-link mini" title={n.name}><span className="rail-ic"><Icon /></span></NavLink>; })
          : nav.map((sys) => (
              <div key={sys.id} className="rail-system">
                <div className="rail-system-label">{sys.name}</div>
                {(sys.children || []).map((c) => <Branch key={c.id} node={c} depth={0} />)}
              </div>
            ))}
      </div>
      <style>{`
        .rail { flex: 0 0 auto; background: var(--surface); border-right: 1px solid var(--line); display: flex; flex-direction: column; min-height: 0; transition: width .16s ease; }
        .rail-full { width: 280px; } .rail-mini { width: 60px; }
        .rail-scroll { overflow-y: auto; overflow-x: hidden; padding: 6px 8px 16px; flex: 1; }
        .rail-system { margin-top: 10px; }
        .rail-system-label { font-size: 10.5px; font-weight: 700; text-transform: uppercase; letter-spacing: .05em; color: var(--ink-faint); padding: 6px 10px 2px; }
        .rail-grouphead { display: flex; align-items: center; gap: 6px; width: 100%; border: none; background: transparent; cursor: pointer; color: var(--ink-soft); font-size: 12px; font-weight: 600; padding: 6px 10px; text-align: left; }
        .rail-grouphead:hover { color: var(--ink); }
        .gh-caret { display: inline-block; transition: transform .12s; font-size: 10px; }
        .gh-caret.o { transform: rotate(90deg); }
        .rail-link { display: flex; align-items: center; gap: 10px; padding: 7px 10px; margin: 1px 4px; border-radius: var(--radius-sm); color: var(--ink); font-size: var(--fs-sm); font-weight: 500; position: relative; white-space: nowrap; }
        .rail-link:hover { background: var(--surface-2); }
        .rail-link.active { background: var(--accent-soft); color: var(--accent-ink); font-weight: 650; }
        .rail-link.active::before { content: ''; position: absolute; left: 0; top: 6px; bottom: 6px; width: 3px; background: var(--accent); border-radius: 0 3px 3px 0; }
        .rail-link.is-disabled { color: var(--ink-faint); }
        .rail-link.is-disabled:hover { background: transparent; }
        .rail-link.mini { justify-content: center; padding: 9px 0; margin: 6px 8px 0; }
        .rail-ic { display: inline-flex; color: var(--ink-soft); flex: 0 0 auto; }
        .rail-link.active .rail-ic { color: var(--accent); }
        .rail-drawer { position: fixed; top: var(--topbar-h); bottom: 0; left: 0; width: 280px; transform: translateX(-100%); transition: transform .18s ease; z-index: 25; box-shadow: var(--shadow-2); }
        .rail-drawer.is-open { transform: translateX(0); }
      `}</style>
    </nav>
  );
}
