// src/components/Layout.jsx — header + collapsible, responsive left rail.
import { useState, useEffect } from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';
import { useMediaQuery } from '../utils/useMediaQuery';
import Sidebar from './Sidebar';
import { Logout, Menu, X, Grid } from './Icons';
import NotificationBell from './NotificationBell';

const TITLES = {
  '/': 'Dashboard', '/units': 'Units',
  '/vehicles': 'Vehicles', '/transport': 'Traveler & Cargo Transport',
};

export default function Layout() {
  const { user, signOut } = useAuth();
  const { pathname } = useLocation();
  const isMobile = useMediaQuery('(max-width: 860px)');

  // Desktop: rail can collapse to icons (persisted). Mobile: rail is a drawer.
  const [collapsed, setCollapsed] = useState(() => {
    try { return localStorage.getItem('railCollapsed') === '1'; } catch { return false; }
  });
  const [drawerOpen, setDrawerOpen] = useState(false);

  useEffect(() => { try { localStorage.setItem('railCollapsed', collapsed ? '1' : '0'); } catch {} }, [collapsed]);
  useEffect(() => { setDrawerOpen(false); }, [pathname]); // close drawer on navigation

  const toggleNav = () => (isMobile ? setDrawerOpen((v) => !v) : setCollapsed((v) => !v));
  const railMode = isMobile ? 'drawer' : (collapsed ? 'mini' : 'full');

  return (
    <div className="shell">
      <header className="header">
        <div className="header-left">
          <button className="iconbtn" onClick={toggleNav} aria-label="Toggle navigation">
            {isMobile && drawerOpen ? <X /> : <Menu />}
          </button>
          <span className="brand">
            <span className="brand-mark"><Grid /></span>
            <span className="brand-name">HQ Transport</span>
          </span>
          <span className="crumb">{TITLES[pathname] || ''}</span>
        </div>
        <div className="header-right">
          <NotificationBell />
          <span className="who">
            {user?.fullName}
            {user?.isSuperAdmin && <span className="pill pill-ok" style={{ marginLeft: 8 }}>Super admin</span>}
          </span>
          <button className="btn btn-sm btn-ghost" onClick={signOut} aria-label="Sign out">
            <Logout /><span className="signout-text">Sign out</span>
          </button>
        </div>
      </header>

      <div className="body">
        {isMobile && drawerOpen && <div className="scrim" onClick={() => setDrawerOpen(false)} />}
        <Sidebar mode={railMode} open={drawerOpen} />
        <main className="content"><Outlet /></main>
      </div>

      <style>{`
        .shell { display: flex; flex-direction: column; height: 100vh; overflow: hidden; }
        .header { height: var(--topbar-h); flex: 0 0 auto; display: flex; align-items: center;
          justify-content: space-between; padding: 0 14px; background: var(--surface);
          border-bottom: 1px solid var(--line); z-index: 30; }
        .header-left { display: flex; align-items: center; gap: 12px; min-width: 0; }
        .iconbtn { display: inline-flex; align-items: center; justify-content: center; width: 34px; height: 34px;
          border: 1px solid transparent; border-radius: var(--radius-sm); background: transparent; cursor: pointer; color: var(--ink); }
        .iconbtn:hover { background: var(--surface-2); }
        .brand { display: flex; align-items: center; gap: 9px; }
        .brand-mark { display: inline-flex; width: 26px; height: 26px; align-items: center; justify-content: center;
          background: var(--accent); color: #fff; border-radius: 6px; }
        .brand-name { font-weight: 700; letter-spacing: -0.01em; }
        .crumb { color: var(--ink-soft); font-size: var(--fs-sm); padding-left: 12px; margin-left: 4px;
          border-left: 1px solid var(--line); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .header-right { display: flex; align-items: center; gap: 12px; }
        .who { font-size: var(--fs-sm); color: var(--ink); white-space: nowrap; }

        .body { flex: 1; display: flex; min-height: 0; position: relative; }
        .content { flex: 1; overflow: auto; padding: 20px; min-width: 0; }
        .scrim { position: fixed; inset: var(--topbar-h) 0 0 0; background: rgba(24,36,47,.4); z-index: 20; }

        @media (max-width: 860px) {
          .crumb { display: none; }
          .who { display: none; }
          .signout-text { display: none; }
          .content { padding: 14px; }
        }
        @media (max-width: 520px) {
          .brand-name { display: none; }
        }
      `}</style>
    </div>
  );
}
