// src/components/Modal.jsx — accessible modal (Esc to close, backdrop click).
import { useEffect } from 'react';

export default function Modal({ open, title, onClose, children, footer, width = 480 }) {
  useEffect(() => {
    if (!open) return undefined;
    const onKey = (e) => { if (e.key === 'Escape') onClose(); };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [open, onClose]);

  if (!open) return null;
  return (
    <div className="modal-backdrop" onMouseDown={onClose} role="dialog" aria-modal="true">
      <div className="modal card" style={{ width }} onMouseDown={(e) => e.stopPropagation()}>
        <div className="modal-head">
          <h3>{title}</h3>
          <button className="btn btn-ghost btn-sm" onClick={onClose} aria-label="Close">✕</button>
        </div>
        <div className="modal-body">{children}</div>
        {footer && <div className="modal-foot">{footer}</div>}
      </div>
      <style>{`
        .modal-backdrop { position: fixed; inset: 0; background: rgba(24,36,47,.38);
          display: flex; align-items: flex-start; justify-content: center; padding-top: 9vh; z-index: 50; }
        .modal { box-shadow: var(--shadow-2); max-height: 82vh; display: flex; flex-direction: column; }
        .modal-head { display: flex; align-items: center; justify-content: space-between;
          padding: 14px 18px; border-bottom: 1px solid var(--line); }
        .modal-body { padding: 18px; overflow: auto; }
        .modal-foot { padding: 12px 18px; border-top: 1px solid var(--line);
          display: flex; justify-content: flex-end; gap: 8px; }
      `}</style>
    </div>
  );
}
