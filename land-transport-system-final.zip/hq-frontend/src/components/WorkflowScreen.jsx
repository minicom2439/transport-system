// src/components/WorkflowScreen.jsx
// Config-driven screen for approval-workflow resources (create-as-draft, edit
// when draft/rejected, submit/approve/reject/cancel, history). Mirrors CrudScreen
// but adds the workflow buttons, a reject-with-comment modal, and a history modal.
import { useState, useCallback } from 'react';
import { useAuth } from '../auth/AuthContext';
import { useToast } from './Toast';
import { useConfirm } from './ConfirmDialog';
import { useDataTable } from '../utils/useDataTable';
import DataTable from './DataTable';
import TreeView from './TreeView';
import Modal from './Modal';
import Field from './Field';
import { Plus, Edit, Trash, Send, Check, X, Clock } from './Icons';

const STATUS_PILL = { draft: 'pill-off', submitted: 'pill-warn', approved: 'pill-ok', rejected: 'pill-danger', cancelled: 'pill-off' };

export default function WorkflowScreen({ title, subtitle, section, columns, fields, api, initialSort, toServerFilters, lookups = {}, entityLabel = 'item', tree = null, approveCommandLabel = null }) {
  const { can } = useAuth();
  const toast = useToast();
  const confirm = useConfirm();
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({});
  const [fieldErrors, setFieldErrors] = useState({});
  const [dirty, setDirty] = useState(false);
  const [saving, setSaving] = useState(false);
  const [treeOpen, setTreeOpen] = useState(true);
  const [rejecting, setRejecting] = useState(null);
  const [rejectComment, setRejectComment] = useState('');
  const [approving, setApproving] = useState(null);
  const [commandText, setCommandText] = useState('');
  const [historyFor, setHistoryFor] = useState(null);
  const [historyRows, setHistoryRows] = useState([]);

  const fetcher = useCallback(({ page, pageSize, sort, dir, q, filters }, opts) => {
    const sf = toServerFilters ? toServerFilters(filters) : [];
    return api.list({ page, limit: pageSize, sort, dir, q, filters: sf.length ? JSON.stringify(sf) : undefined }, opts);
  }, [api, toServerFilters]);
  const table = useDataTable(fetcher, { initialSort });

  const blank = () => Object.fromEntries(fields.map((f) => [f.key, f.type === 'checkbox' ? false : '']));
  const openNew = () => { setEditing({}); setForm(blank()); setFieldErrors({}); setDirty(false); };
  const openEdit = (row) => { const f = {}; fields.forEach((fl) => { f[fl.key] = fl.type === 'checkbox' ? !!row[fl.key] : (row[fl.key] ?? ''); }); setEditing(row); setForm(f); setFieldErrors({}); setDirty(false); };
  const change = (k, v) => { setForm((f) => ({ ...f, [k]: v })); setDirty(true); };

  const requestClose = async () => { if (dirty && !(await confirm({ title: 'Discard changes?', message: 'You have unsaved changes. Discard them?', confirmLabel: 'Discard', danger: true }))) return; setEditing(null); setDirty(false); setFieldErrors({}); };

  const save = async () => {
    setFieldErrors({}); setSaving(true);
    const body = {}; fields.forEach((f) => { body[f.key] = form[f.key]; });
    try {
      if (editing.id) { await api.update(editing.id, body); toast.success('Saved.'); }
      else { await api.create(body); toast.success('Created as draft.'); }
      table.reload(); setEditing(null); setDirty(false);
    } catch (err) { if (err.fields) setFieldErrors(err.fields); else toast.error(err.message || 'Could not save.'); }
    finally { setSaving(false); }
  };

  const doAction = async (r, action, label) => {
    if (!(await confirm({ title: `${label}?`, message: `${label} this ${entityLabel}?`, confirmLabel: label, danger: action === 'cancel' }))) return;
    try { await api.act(r.id, action); toast.success(`${label} done.`); table.reload(); }
    catch (e) { toast.error(e.payload?.fields?._ || e.message || `Could not ${action}.`); }
  };
  const del = async (r) => { if (!(await confirm({ title: `Remove ${entityLabel}?`, message: `Remove this ${entityLabel}?`, confirmLabel: 'Remove', danger: true }))) return; try { await api.remove(r.id); toast.success('Removed.'); table.reload(); } catch { toast.error('Could not remove.'); } };
  const submitReject = async () => { try { await api.act(rejecting.id, 'reject', { comment: rejectComment }); toast.success('Rejected.'); setRejecting(null); setRejectComment(''); table.reload(); } catch (e) { toast.error(e.message || 'Could not reject.'); } };
  const submitApprove = async () => { try { await api.act(approving.id, 'approve', { command: commandText }); toast.success('Reviewed.'); setApproving(null); setCommandText(''); table.reload(); } catch (e) { toast.error(e.message || 'Could not approve.'); } };
  const openHistory = async (r) => { setHistoryFor(r); try { setHistoryRows((await api.history(r.id)).data); } catch { setHistoryRows([]); } };

  const renderField = (f) => {
    const v = form[f.key];
    if (f.type === 'checkbox') return <label style={{ display: 'flex', gap: 6, alignItems: 'center', fontSize: 'var(--fs-sm)' }}><input type="checkbox" checked={!!v} onChange={(e) => change(f.key, e.target.checked)} /> {f.label}</label>;
    if (f.type === 'select') { const opts = f.options || lookups[f.optionsKey] || []; return <select className="input" value={v || ''} onChange={(e) => change(f.key, e.target.value)}><option value="">{f.placeholder || 'Select…'}</option>{opts.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}</select>; }
    if (f.type === 'textarea') return <textarea className="input" style={{ height: 70, padding: 8 }} value={v || ''} onChange={(e) => change(f.key, e.target.value)} />;
    return <input className="input" type={f.type === 'number' ? 'number' : f.type === 'date' ? 'date' : 'text'} value={v ?? ''} onChange={(e) => change(f.key, e.target.value)} />;
  };

  const rowActions = (r) => {
    const a = [];
    if ((r.status === 'draft' || r.status === 'rejected') && can(section, 'edit')) a.push(<button key="e" className="btn btn-sm btn-ghost" onClick={() => openEdit(r)} title="Edit"><Edit /></button>);
    if (r.status === 'draft' && can(section, 'edit')) a.push(<button key="s" className="btn btn-sm" onClick={() => doAction(r, 'submit', 'Submit')} title="Submit"><Send /></button>);
    if (r.status === 'submitted' && can(section, 'approve')) a.push(<button key="a" className="btn btn-sm btn-primary" onClick={() => (approveCommandLabel ? (setApproving(r), setCommandText(r.command || '')) : doAction(r, 'approve', 'Approve'))} title={approveCommandLabel || 'Approve'}><Check /></button>);
    if (r.status === 'submitted' && can(section, 'reject')) a.push(<button key="r" className="btn btn-sm btn-danger" onClick={() => { setRejecting(r); setRejectComment(''); }} title="Reject"><X /></button>);
    if ((r.status === 'draft' || r.status === 'submitted') && can(section, 'edit')) a.push(<button key="c" className="btn btn-sm btn-ghost" onClick={() => doAction(r, 'cancel', 'Cancel')} title="Cancel">⦸</button>);
    a.push(<button key="h" className="btn btn-sm btn-ghost" onClick={() => openHistory(r)} title="History"><Clock /></button>);
    if ((r.status === 'draft' || r.status === 'rejected') && can(section, 'remove')) a.push(<button key="d" className="btn btn-sm btn-danger" onClick={() => del(r)} title="Remove"><Trash /></button>);
    return <span style={{ display: 'inline-flex', gap: 6 }}>{a}</span>;
  };

  const cols = columns.map((c) => c.key === 'status' ? { ...c, render: (r) => <span className={`pill ${STATUS_PILL[r.status] || 'pill-off'}`}>{r.status}</span> } : c);

  return (
    <div>
      <h1 style={{ fontSize: 'var(--fs-xl)' }}>{title}</h1>
      {subtitle && <p style={{ color: 'var(--ink-soft)', margin: '2px 0 14px', fontSize: 'var(--fs-sm)' }}>{subtitle}</p>}
      {tree ? (
        <div className={`master-detail card${treeOpen ? '' : ' tree-collapsed'}`}>
          <aside className="md-left">
            <TreeView header={tree.title} nodes={tree.nodes} selectedId={Number(table.filters[tree.filterKey]) || 0} onSelect={(n) => table.setFilter(tree.filterKey, n.id === 0 ? '' : n.id)} />
          </aside>
          <section className="md-right">
            <div className="md-toolbar"><button className="btn btn-sm btn-ghost" onClick={() => setTreeOpen((v) => !v)}>{treeOpen ? '◂ Hide' : '▸ ' + tree.title}</button></div>
        <DataTable
          columns={cols}
          rows={table.rows} total={table.total} loading={table.loading} error={table.error} onRetry={table.reload}
          page={table.page} pageSize={table.pageSize} onPageChange={table.setPage} onPageSizeChange={table.setPageSize}
          sort={table.sort} dir={table.dir} onSort={table.toggleSort}
          filters={table.filters} onFilter={table.setFilter}
          q={table.q} onSearch={table.setQ}
          density={table.density} onDensityChange={table.setDensity}
          emptyText={`No ${entityLabel}s match.`}
          toolbarRight={can(section, 'add') && <button className="btn btn-sm btn-primary" onClick={openNew}><Plus /> New</button>}
          rowActions={rowActions}
        />
          </section>
          <style>{`
            .master-detail { display: grid; grid-template-columns: 240px 1fr; height: calc(100vh - var(--topbar-h) - 116px); overflow: hidden; transition: grid-template-columns .16s ease; }
            .master-detail.tree-collapsed { grid-template-columns: 0 1fr; }
            .md-left { border-right: 1px solid var(--line); overflow: auto; min-width: 0; }
            .master-detail.tree-collapsed .md-left { border-right: none; }
            .md-right { min-width: 0; display: flex; flex-direction: column; }
            .md-toolbar { display: flex; align-items: center; gap: 12px; padding: 6px 8px; border-bottom: 1px solid var(--line); background: var(--surface-2); }
            @media (max-width: 760px) { .master-detail, .master-detail.tree-collapsed { grid-template-columns: 1fr; } .md-left { display: none; } }
          `}</style>
        </div>
      ) : (
        <div className="card" style={{ height: 'calc(100vh - var(--topbar-h) - 120px)', minHeight: 320, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
        <DataTable
          columns={cols}
          rows={table.rows} total={table.total} loading={table.loading} error={table.error} onRetry={table.reload}
          page={table.page} pageSize={table.pageSize} onPageChange={table.setPage} onPageSizeChange={table.setPageSize}
          sort={table.sort} dir={table.dir} onSort={table.toggleSort}
          filters={table.filters} onFilter={table.setFilter}
          q={table.q} onSearch={table.setQ}
          density={table.density} onDensityChange={table.setDensity}
          emptyText={`No ${entityLabel}s match.`}
          toolbarRight={can(section, 'add') && <button className="btn btn-sm btn-primary" onClick={openNew}><Plus /> New</button>}
          rowActions={rowActions}
        />
        </div>
      )}

      <Modal open={!!editing} title={editing?.id ? `Edit ${entityLabel}` : `New ${entityLabel}`} onClose={requestClose} width={540}
        footer={(<><button className="btn" onClick={requestClose}>Cancel</button><button className="btn btn-primary" disabled={saving} onClick={save}>{saving ? 'Saving…' : (editing?.id ? 'Save changes' : 'Create draft')}</button></>)}>
        {editing && (
          <form onSubmit={(e) => { e.preventDefault(); save(); }}>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 12 }}>
              {fields.map((f) => <div key={f.key} style={{ flex: f.span === 2 ? '1 1 100%' : '1 1 calc(50% - 6px)', minWidth: 0 }}>{f.type === 'checkbox' ? <div style={{ marginTop: 22 }}>{renderField(f)}</div> : <Field label={f.label} error={fieldErrors[f.key]}>{renderField(f)}</Field>}</div>)}
            </div>
          </form>
        )}
      </Modal>

      <Modal open={!!rejecting} title={`Reject ${entityLabel}`} onClose={() => setRejecting(null)} width={440}
        footer={(<><button className="btn" onClick={() => setRejecting(null)}>Cancel</button><button className="btn btn-danger" onClick={submitReject}>Reject</button></>)}>
        <p style={{ marginTop: 0, color: 'var(--ink-soft)', fontSize: 'var(--fs-sm)' }}>Optionally explain the rejection.</p>
        <textarea className="input" style={{ height: 80, padding: 8 }} value={rejectComment} onChange={(e) => setRejectComment(e.target.value)} placeholder="Reason (optional)" />
      </Modal>

      <Modal open={!!approving} title={approveCommandLabel || 'Approve'} onClose={() => setApproving(null)} width={460}
        footer={(<><button className="btn" onClick={() => setApproving(null)}>Cancel</button><button className="btn btn-primary" onClick={submitApprove}>Approve &amp; send</button></>)}>
        <p style={{ marginTop: 0, color: 'var(--ink-soft)', fontSize: 'var(--fs-sm)' }}>Approve this submission and issue a command/directive back to the unit.</p>
        <textarea className="input" style={{ height: 100, padding: 8 }} value={commandText} onChange={(e) => setCommandText(e.target.value)} placeholder="Business daily command (optional)" />
      </Modal>

      <Modal open={!!historyFor} title="History" onClose={() => setHistoryFor(null)} width={520}>
        {historyRows.length === 0 ? <p style={{ color: 'var(--ink-faint)' }}>No history.</p> : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {historyRows.map((h, i) => (
              <div key={i} style={{ display: 'flex', gap: 10, fontSize: 'var(--fs-sm)', borderBottom: '1px solid var(--line)', paddingBottom: 6 }}>
                <span style={{ color: 'var(--ink-faint)', minWidth: 140 }}>{new Date(h.changed_at).toLocaleString()}</span>
                <span><strong>{h.from_status || '∅'} → {h.to_status}</strong>{h.by ? ` · ${h.by}` : ''}{h.comment ? ` · "${h.comment}"` : ''}</span>
              </div>
            ))}
          </div>
        )}
      </Modal>
    </div>
  );
}
