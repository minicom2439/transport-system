// src/components/NotificationBell.jsx — header bell with unread badge + dropdown.
import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Bell } from './Icons';
import * as notifApi from '../api/notifications';

export default function NotificationBell() {
  const [count, setCount] = useState(0);
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState([]);
  const ref = useRef(null);
  const navigate = useNavigate();

  const refreshCount = () => notifApi.unreadCount().then((r) => setCount(r.count)).catch(() => {});

  useEffect(() => {
    refreshCount();
    const t = setInterval(refreshCount, 60000); // poll every 60s
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    const onDoc = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener('mousedown', onDoc);
    return () => document.removeEventListener('mousedown', onDoc);
  }, []);

  const toggle = async () => {
    const next = !open; setOpen(next);
    if (next) { try { const r = await notifApi.listNotifications(); setItems(r.data); } catch {} }
  };

  const openItem = async (n) => {
    if (!n.is_read) { await notifApi.markRead(n.id).catch(() => {}); refreshCount(); }
    setOpen(false);
    if (n.link) navigate(n.link);
  };

  const markAll = async () => { await notifApi.markAllRead().catch(() => {}); setItems((x) => x.map((n) => ({ ...n, is_read: 1 }))); setCount(0); };

  return (
    <div className="bell" ref={ref}>
      <button className="iconbtn bell-btn" onClick={toggle} aria-label={`Notifications (${count} unread)`}>
        <Bell />
        {count > 0 && <span className="bell-badge">{count > 9 ? '9+' : count}</span>}
      </button>
      {open && (
        <div className="bell-panel card">
          <div className="bell-head">
            <strong>Notifications</strong>
            {count > 0 && <button className="btn btn-sm btn-ghost" onClick={markAll}>Mark all read</button>}
          </div>
          <div className="bell-list">
            {items.length === 0 && <div className="bell-empty">You're all caught up.</div>}
            {items.map((n) => (
              <button key={n.id} className={`bell-item ${n.is_read ? '' : 'unread'}`} onClick={() => openItem(n)}>
                <span className={`bell-dot t-${n.type}`} />
                <span className="bell-text">
                  <span className="bell-title">{n.title}</span>
                  {n.body && <span className="bell-body">{n.body}</span>}
                </span>
              </button>
            ))}
          </div>
        </div>
      )}
      <style>{`
        .bell { position: relative; }
        .bell-btn { position: relative; }
        .bell-badge { position: absolute; top: 2px; right: 2px; min-width: 16px; height: 16px; padding: 0 4px;
          background: var(--danger); color: #fff; border-radius: 999px; font-size: 10px; font-weight: 700;
          display: inline-flex; align-items: center; justify-content: center; }
        .bell-panel { position: absolute; right: 0; top: 42px; width: 320px; z-index: 40; box-shadow: var(--shadow-2); overflow: hidden; }
        .bell-head { display: flex; align-items: center; justify-content: space-between; padding: 10px 12px; border-bottom: 1px solid var(--line); }
        .bell-list { max-height: 360px; overflow: auto; }
        .bell-empty { padding: 20px; text-align: center; color: var(--ink-faint); font-size: var(--fs-sm); }
        .bell-item { display: flex; gap: 9px; width: 100%; text-align: left; padding: 10px 12px; border: none;
          border-bottom: 1px solid var(--line); background: transparent; cursor: pointer; }
        .bell-item:hover { background: var(--surface-2); }
        .bell-item.unread { background: var(--accent-soft); }
        .bell-item.unread:hover { background: #d7ebe9; }
        .bell-dot { width: 8px; height: 8px; border-radius: 999px; margin-top: 5px; flex: 0 0 auto; background: var(--ink-faint); }
        .bell-dot.t-approval { background: var(--accent); }
        .bell-dot.t-accident { background: var(--danger); }
        .bell-dot.t-system { background: var(--ink-faint); }
        .bell-text { display: flex; flex-direction: column; gap: 2px; }
        .bell-title { font-size: var(--fs-sm); font-weight: 600; color: var(--ink); }
        .bell-body { font-size: var(--fs-xs); color: var(--ink-soft); }
      `}</style>
    </div>
  );
}
