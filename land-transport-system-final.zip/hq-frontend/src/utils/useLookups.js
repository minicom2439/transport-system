import { useEffect, useState } from 'react';
import { getUnitOptions } from '../api/admin';
import { getRegions } from '../api/meta';
import { api } from '../api/client';

// useLookups({ units:true, regions:true, lookups:['report_types','parks','routes'] })
export function useLookups({ units = false, regions = false, lookups = [] } = {}) {
  const [data, setData] = useState({ units: [], regions: [] });
  const key = lookups.join(',');
  useEffect(() => {
    if (units) getUnitOptions().then((r) => setData((d) => ({ ...d, units: r.data.map((x) => ({ value: x.id, label: x.name })) }))).catch(() => {});
    if (regions) getRegions().then((r) => { const flat = []; (function w(ns, p = '') { ns.forEach((n) => { flat.push({ value: n.id, label: p + n.name }); if (n.children) w(n.children, p + n.name + ' / '); }); })(r.data); setData((d) => ({ ...d, regions: flat })); }).catch(() => {});
    lookups.forEach((name) => {
      api.get(`/api/meta/lookup/${name}`).then((r) => setData((d) => ({ ...d, [name]: r.data }))).catch(() => {});
    });
  }, [units, regions, key]);
  return data;
}
