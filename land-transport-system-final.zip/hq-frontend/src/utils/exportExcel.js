// src/utils/exportExcel.js — offline Excel export via SheetJS (bundled, no network).
import * as XLSX from 'xlsx';

// rows: array of plain objects; columns: [{ key, label, value?(row) }]
export function exportToExcel(filename, columns, rows) {
  const data = rows.map((r) => {
    const o = {};
    columns.forEach((c) => { o[c.label] = c.value ? c.value(r) : r[c.key]; });
    return o;
  });
  const ws = XLSX.utils.json_to_sheet(data);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
  XLSX.writeFile(wb, filename.endsWith('.xlsx') ? filename : `${filename}.xlsx`);
}
