export function treeFromOptions(options = [], allLabel = 'All') {
  return [{ id: 0, name: allLabel, children: (options || []).map((o) => ({ id: o.value, name: o.label })) }];
}
