// src/utils/useDataTable.js
// Owns all table state (paging, sort, filters, search, selection) and fetches
// via a provided fetcher(params, { signal }). Debounces filter/search input and
// cancels stale requests so rapid typing never shows out-of-order results.
import { useEffect, useRef, useState, useCallback } from 'react';

function useDebounced(value, ms) {
  const [v, setV] = useState(value);
  useEffect(() => { const t = setTimeout(() => setV(value), ms); return () => clearTimeout(t); }, [value, ms]);
  return v;
}

export function useDataTable(fetcher, { initialSort = null, initialDir = 'asc', pageSize: initialPageSize = 25 } = {}) {
  const [page, setPage] = useState(0);
  const [pageSize, setPageSizeRaw] = useState(initialPageSize);
  const [sort, setSort] = useState(initialSort);
  const [dir, setDir] = useState(initialDir);
  const [q, setQRaw] = useState('');
  const [filters, setFilters] = useState({});
  const [density, setDensity] = useState('comfortable');
  const [selected, setSelected] = useState(() => new Set());

  const [rows, setRows] = useState([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [reloadKey, setReloadKey] = useState(0);

  const dq = useDebounced(q, 300);
  const dfilters = useDebounced(filters, 300);
  const fetcherRef = useRef(fetcher);
  fetcherRef.current = fetcher;

  useEffect(() => {
    const ctrl = new AbortController();
    let active = true;
    setLoading(true); setError(null);
    fetcherRef.current({ page, pageSize, sort, dir, q: dq, filters: dfilters }, { signal: ctrl.signal })
      .then((res) => { if (active) { setRows(res.data || []); setTotal(res.total || 0); } })
      .catch((err) => { if (!ctrl.signal.aborted && active) setError(err); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; ctrl.abort(); };
  }, [page, pageSize, sort, dir, dq, dfilters, reloadKey]);

  const toggleSort = useCallback((field) => {
    setPage(0);
    setSort((cur) => {
      if (cur === field) { setDir((d) => (d === 'asc' ? 'desc' : 'asc')); return cur; }
      setDir('asc'); return field;
    });
  }, []);
  const setFilter = useCallback((key, value) => { setPage(0); setFilters((f) => ({ ...f, [key]: value })); }, []);
  const setQ = useCallback((value) => { setPage(0); setQRaw(value); }, []);
  const setPageSize = useCallback((n) => { setPage(0); setPageSizeRaw(n); }, []);
  const reload = useCallback(() => setReloadKey((k) => k + 1), []);

  const toggleSelect = useCallback((id) => setSelected((s) => {
    const n = new Set(s); n.has(id) ? n.delete(id) : n.add(id); return n;
  }), []);
  const toggleSelectAll = useCallback(() => setSelected((s) => {
    if (s.size === rows.length) return new Set();
    return new Set(rows.map((r) => r.id));
  }), [rows]);
  const clearSelection = useCallback(() => setSelected(new Set()), []);

  return {
    rows, total, loading, error,
    page, setPage, pageSize, setPageSize,
    sort, dir, toggleSort,
    q, setQ, filters, setFilter,
    density, setDensity,
    selected, toggleSelect, toggleSelectAll, clearSelection,
    allSelected: rows.length > 0 && selected.size === rows.length,
    reload,
  };
}
