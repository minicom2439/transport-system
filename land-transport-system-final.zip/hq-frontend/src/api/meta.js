import { api } from './client';
export const getRegions = () => api.get('/api/meta/regions');
export const getNav = () => api.get('/api/meta/nav');
