import { api } from './client';
export const listRequests = () => api.get('/api/account-requests');
export const approveRequest = (id) => api.post(`/api/account-requests/${id}/approve`);
export const rejectRequest = (id) => api.post(`/api/account-requests/${id}/reject`);
