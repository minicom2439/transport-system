import { api, qs } from './client';
const workflow = (base) => ({ list: (p, o) => api.get(`${base}${qs(p)}`, o), create: (d) => api.post(base, d), update: (id, d) => api.put(`${base}/${id}`, d), remove: (id) => api.del(`${base}/${id}`), act: (id, action, body) => api.post(`${base}/${id}/${action}`, body), history: (id) => api.get(`${base}/${id}/history`) });
const crud = (base) => ({ list: (p, o) => api.get(`${base}${qs(p)}`, o), create: (d) => api.post(base, d), update: (id, d) => api.put(`${base}/${id}`, d), remove: (id) => api.del(`${base}/${id}`) });
export const noticesApi = crud('/api/notices');
export const programsApi = crud('/api/programs');
export const faqsApi = crud('/api/faqs');
export const feedbackApi = crud('/api/feedback');
export const submissionsApi = workflow('/api/submissions');
