import { api } from './client';
export const listNotifications = () => api.get('/api/notifications');
export const unreadCount = () => api.get('/api/notifications/unread-count');
export const markRead = (id) => api.post(`/api/notifications/${id}/read`);
export const markAllRead = () => api.post('/api/notifications/read-all');
