import { api, qs } from './client';
export const listRoles = (params, opts) => api.get(`/api/roles${qs(params)}`, opts);
export const createRole = (data) => api.post('/api/roles', data);
export const updateRole = (id, data) => api.put(`/api/roles/${id}`, data);
export const removeRole = (id) => api.del(`/api/roles/${id}`);
export const getRolePermissions = (id) => api.get(`/api/roles/${id}/permissions`);
export const setRolePermissions = (id, permissions) => api.put(`/api/roles/${id}/permissions`, { permissions });
