import { api, qs } from './client';
export const listVehicles = (params, opts) => api.get(`/api/vehicles${qs(params)}`, opts);
export const createVehicle = (data) => api.post('/api/vehicles', data);
