import { api, qs } from './client';
export const listUsers = (params, opts) => api.get(`/api/users${qs(params)}`, opts);
export const getUser = (id) => api.get(`/api/users/${id}`);
export const createUser = (data) => api.post('/api/users', data);
export const updateUser = (id, data) => api.put(`/api/users/${id}`, data);
export const removeUser = (id) => api.del(`/api/users/${id}`);
