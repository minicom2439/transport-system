import { api, qs } from './client';
export const parksApi = {
  list: (p, o) => api.get(`/api/parks${qs(p)}`, o),
  create: (d) => api.post('/api/parks', d),
  update: (id, d) => api.put(`/api/parks/${id}`, d),
  remove: (id) => api.del(`/api/parks/${id}`),
};
