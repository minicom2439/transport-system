import { api } from './client';
export const getSectionsAll = () => api.get('/api/meta/sections-all');
export const getActions = () => api.get('/api/meta/actions');
export const getUnitOptions = () => api.get('/api/meta/units');
export const getMyAdminDomain = () => api.get('/api/meta/my-admin-domain');
