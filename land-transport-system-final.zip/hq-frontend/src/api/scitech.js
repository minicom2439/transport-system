import { api, qs } from './client';
const crud = (base) => ({ list: (p, o) => api.get(`${base}${qs(p)}`, o), create: (d) => api.post(base, d), update: (id, d) => api.put(`${base}/${id}`, d), remove: (id) => api.del(`${base}/${id}`) });
export const gpsApi = crud('/api/gps-devices');
export const locationsApi = { list: (p, o) => api.get(`/api/vehicle-locations${qs(p)}`, o) };
