import { api, qs } from './client';
export const listConditions = (params, opts) => api.get(`/api/operating-conditions${qs(params)}`, opts);
export const createCondition = (d) => api.post('/api/operating-conditions', d);
export const updateCondition = (id, d) => api.put(`/api/operating-conditions/${id}`, d);
export const removeCondition = (id) => api.del(`/api/operating-conditions/${id}`);
export const conditionAction = (id, action, body) => api.post(`/api/operating-conditions/${id}/${action}`, body);
export const conditionHistory = (id) => api.get(`/api/operating-conditions/${id}/history`);
