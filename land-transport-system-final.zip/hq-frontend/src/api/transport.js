import { api, qs } from './client';
export const statsByUnit = (params) => api.get(`/api/transport/stats/by-unit${qs(params)}`);
