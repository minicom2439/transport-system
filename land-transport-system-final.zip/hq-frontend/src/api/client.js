// src/api/client.js
// fetch wrapper. credentials:'include' sends the session cookie.
// Accepts an optional { signal } for request cancellation (stale-result drops).
async function request(method, path, body, opts = {}) {
  const cfg = { method, credentials: 'include', headers: { Accept: 'application/json' } };
  if (body !== undefined) {
    cfg.headers['Content-Type'] = 'application/json';
    cfg.body = JSON.stringify(body);
  }
  if (opts.signal) cfg.signal = opts.signal;

  const res = await fetch(path, cfg);
  let payload = null;
  const text = await res.text();
  if (text) { try { payload = JSON.parse(text); } catch { payload = { raw: text }; } }

  if (!res.ok) {
    const err = new Error((payload && payload.error) || `Request failed (${res.status})`);
    err.status = res.status;
    err.payload = payload;
    err.fields = payload && payload.fields;
    throw err;
  }
  return payload;
}

export const api = {
  get: (p, opts) => request('GET', p, undefined, opts),
  post: (p, b, opts) => request('POST', p, b, opts),
  put: (p, b, opts) => request('PUT', p, b, opts),
  del: (p, opts) => request('DELETE', p, undefined, opts),
};

export function qs(params = {}) {
  const u = new URLSearchParams();
  Object.entries(params).forEach(([k, v]) => {
    if (v !== undefined && v !== null && v !== '') u.set(k, v);
  });
  const s = u.toString();
  return s ? `?${s}` : '';
}
