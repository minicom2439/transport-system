import { api, qs } from './client';
export const statsApi = { transport: (p, o) => api.get(`/api/stats/transport${qs(p)}`, o) };
export const searchApi = { run: (q, o) => api.get(`/api/search${qs({ q })}`, o) };
