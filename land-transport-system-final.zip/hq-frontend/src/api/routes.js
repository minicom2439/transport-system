import { api, qs } from './client';
export const routesApi = {
  list: (p, o) => api.get(`/api/routes${qs(p)}`, o),
  create: (d) => api.post('/api/routes', d),
  update: (id, d) => api.put(`/api/routes/${id}`, d),
  remove: (id) => api.del(`/api/routes/${id}`),
};
