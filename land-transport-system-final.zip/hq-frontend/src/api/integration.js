import { api, qs } from './client';
const ro = (base) => ({ list: (p, o) => api.get(`${base}${qs(p)}`, o) });
export const travelerStatsApi = ro('/api/integration/traveler-stats');
export const thingStatsApi = ro('/api/integration/thing-stats');
export const eInvoicesApi = ro('/api/integration/e-invoices');
export const intgParksApi = ro('/api/integration/parks');
export const intgAccidentsApi = ro('/api/integration/accidents');
export const intgLocationsApi = ro('/api/integration/locations');
