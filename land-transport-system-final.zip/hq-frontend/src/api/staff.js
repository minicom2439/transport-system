import { api, qs } from './client';
export const staffApi = {
  list: (p, o) => api.get(`/api/staff${qs(p)}`, o),
  create: (d) => api.post('/api/staff', d),
  update: (id, d) => api.put(`/api/staff/${id}`, d),
  remove: (id) => api.del(`/api/staff/${id}`),
};
