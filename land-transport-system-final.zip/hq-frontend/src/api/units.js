import { api, qs } from './client';
export const listUnits = (params, opts) => api.get(`/api/units${qs(params)}`, opts);
export const getUnit = (id) => api.get(`/api/units/${id}`);
export const createUnit = (data) => api.post('/api/units', data);
export const updateUnit = (id, data) => api.put(`/api/units/${id}`, data);
export const removeUnit = (id) => api.del(`/api/units/${id}`);
