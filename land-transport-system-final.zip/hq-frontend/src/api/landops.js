// src/api/landops.js — API objects for the land-ops resources.
import { api, qs } from './client';
const crud = (base) => ({
  list: (p, o) => api.get(`${base}${qs(p)}`, o),
  create: (d) => api.post(base, d),
  update: (id, d) => api.put(`${base}/${id}`, d),
  remove: (id) => api.del(`${base}/${id}`),
});
const workflow = (base) => ({
  ...crud(base),
  act: (id, action, body) => api.post(`${base}/${id}/${action}`, body),
  history: (id) => api.get(`${base}/${id}/history`),
});
const readonly = (base) => ({ list: (p, o) => api.get(`${base}${qs(p)}`, o) });

export const reportsApi = workflow('/api/reports');
export const schedulesApi = crud('/api/schedules');
export const transferSectionsApi = crud('/api/transfer-sections');
export const warehousesApi = crud('/api/warehouses');
export const routeCertsApi = workflow('/api/route-certificates');
export const ordersApi = readonly('/api/transport-orders');
export const unitStatsApi = readonly('/api/unit-stats');
export const conditionsApi = workflow('/api/operating-conditions');
export const financeApi = crud('/api/finance');
export const licensesApi = workflow('/api/licenses');
export const indicatorsApi = crud('/api/indicators');
export const onlineApi = readonly('/api/online-status');
export const parkVehiclesApi = readonly('/api/park-vehicles');
