import { api, qs } from './client';
const crud = (base) => ({ list: (p, o) => api.get(`${base}${qs(p)}`, o), create: (d) => api.post(base, d), update: (id, d) => api.put(`${base}/${id}`, d), remove: (id) => api.del(`${base}/${id}`) });
export const vehiclesApi = crud('/api/vehicles');
export const accidentsApi = crud('/api/accidents');
export const invoicesApi = crud('/api/invoices');
// generic lookup admin
export const lookupsAdmin = {
  list: (t) => api.get(`/api/lookups/${t}`),
  create: (t, d) => api.post(`/api/lookups/${t}`, d),
  update: (t, id, d) => api.put(`/api/lookups/${t}/${id}`, d),
  remove: (t, id) => api.del(`/api/lookups/${t}/${id}`),
};
export const commandOrdersApi = crud('/api/command-orders');
export const commandOrderAttachmentsApi = {
  list: (id, o) => api.get(`/api/command-orders/${id}/attachments`, o),
  upload: (id, d) => api.post(`/api/command-orders/${id}/attachments`, d),
  remove: (id, attId) => api.del(`/api/command-orders/${id}/attachments/${attId}`),
};
