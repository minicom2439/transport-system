// src/App.jsx — routes.
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './auth/AuthContext';
import { ToastProvider } from './components/Toast';
import { ConfirmProvider } from './components/ConfirmDialog';
import ProtectedRoute from './auth/ProtectedRoute';
import Layout from './components/Layout';
import LoginPage from './pages/LoginPage';
import DashboardPage from './pages/DashboardPage';
import UnitsPage from './pages/UnitsPage';
import VehiclesPage from './pages/VehiclesPage';
import TransportPage from './pages/TransportPage';
import UsersPage from './pages/UsersPage';
import RolesPage from './pages/RolesPage';
import AccountRequestsPage from './pages/AccountRequestsPage';
import RegisterPage from './pages/RegisterPage';
import OperatingConditionsPage from './pages/OperatingConditionsPage';
import StaffPage from './pages/StaffPage';
import ParksPage from './pages/ParksPage';
import RoutesPage from './pages/RoutesPage';
import ReportsPage from './pages/ReportsPage';
import SchedulesPage from './pages/SchedulesPage';
import TransferSectionsPage from './pages/TransferSectionsPage';
import WarehousesPage from './pages/WarehousesPage';
import RouteCertificatesPage from './pages/RouteCertificatesPage';
import TransportOrdersPage from './pages/TransportOrdersPage';
import UnitStatsPage from './pages/UnitStatsPage';
import BasicDataPage from './pages/BasicDataPage';
import AccidentsPage from './pages/AccidentsPage';
import InvoicesPage from './pages/InvoicesPage';
import FinancePage from './pages/FinancePage';
import LicensesPage from './pages/LicensesPage';
import TransportLedgerPage from './pages/TransportLedgerPage';
import NetworkOnlinePage from './pages/NetworkOnlinePage';
import ParkVehiclesPage from './pages/ParkVehiclesPage';
import CommandOrdersPage from './pages/CommandOrdersPage';
import RegisterGpsPage from './pages/RegisterGpsPage';
import VehicleLocationPage from './pages/VehicleLocationPage';
import NoticesPage from './pages/NoticesPage';
import ProgramsPage from './pages/ProgramsPage';
import FaqsPage from './pages/FaqsPage';
import FeedbackPage from './pages/FeedbackPage';
import SubmissionsPage from './pages/SubmissionsPage';
import TravelerStatsPage from './pages/TravelerStatsPage';
import ThingStatsPage from './pages/ThingStatsPage';
import EInvoicePage from './pages/EInvoicePage';
import IntegrationParksPage from './pages/IntegrationParksPage';
import IntegrationAccidentsPage from './pages/IntegrationAccidentsPage';
import IntegrationLocationsPage from './pages/IntegrationLocationsPage';
import MonthlyReportsPage from './pages/MonthlyReportsPage';
import EffortPlansPage from './pages/EffortPlansPage';
import ElectricityReportsPage from './pages/ElectricityReportsPage';
import EquipmentPage from './pages/EquipmentPage';
import EquipmentInspectionsPage from './pages/EquipmentInspectionsPage';
import NoAccidentPage from './pages/NoAccidentPage';
import WeeklySchedulePage from './pages/WeeklySchedulePage';
import BusinessDailyReportsPage from './pages/BusinessDailyReportsPage';
import FinanceStatsPage from './pages/FinanceStatsPage';
import GuardDutiesPage from './pages/GuardDutiesPage';
import DeptDailyReportsPage from './pages/DeptDailyReportsPage';
import UltimateStatsPage from './pages/UltimateStatsPage';
import IntegratedSearchPage from './pages/IntegratedSearchPage';

export default function App() {
  return (
    <AuthProvider>
      <ToastProvider>
      <ConfirmProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route path="/register" element={<RegisterPage />} />
          <Route element={<ProtectedRoute><Layout /></ProtectedRoute>}>
            <Route path="/" element={<DashboardPage />} />
            <Route path="/units" element={<UnitsPage />} />
            <Route path="/conditions" element={<OperatingConditionsPage />} />
            <Route path="/routes" element={<RoutesPage />} />
            <Route path="/route-certs" element={<RouteCertificatesPage />} />
            <Route path="/schedules" element={<SchedulesPage />} />
            <Route path="/warehouses" element={<WarehousesPage />} />
            <Route path="/transfer-sections" element={<TransferSectionsPage />} />
            <Route path="/orders" element={<TransportOrdersPage />} />
            <Route path="/reports" element={<ReportsPage />} />
            <Route path="/unit-stats" element={<UnitStatsPage />} />
            <Route path="/basic-data" element={<BasicDataPage />} />
            <Route path="/accidents" element={<AccidentsPage />} />
            <Route path="/invoices" element={<InvoicesPage />} />
            <Route path="/finance" element={<FinancePage />} />
            <Route path="/licenses" element={<LicensesPage />} />
            <Route path="/indicators" element={<TransportLedgerPage />} />
            <Route path="/online-status" element={<NetworkOnlinePage />} />
            <Route path="/park-vehicles" element={<ParkVehiclesPage />} />
            <Route path="/command-orders" element={<CommandOrdersPage />} />
            <Route path="/gps" element={<RegisterGpsPage />} />
            <Route path="/vehicle-locations" element={<VehicleLocationPage />} />
            <Route path="/notices" element={<NoticesPage />} />
            <Route path="/programs" element={<ProgramsPage />} />
            <Route path="/faqs" element={<FaqsPage />} />
            <Route path="/feedback" element={<FeedbackPage />} />
            <Route path="/submissions" element={<SubmissionsPage />} />
            <Route path="/integration/traveler" element={<TravelerStatsPage />} />
            <Route path="/integration/thing" element={<ThingStatsPage />} />
            <Route path="/integration/e-invoices" element={<EInvoicePage />} />
            <Route path="/integration/parks" element={<IntegrationParksPage />} />
            <Route path="/integration/accidents" element={<IntegrationAccidentsPage />} />
            <Route path="/integration/locations" element={<IntegrationLocationsPage />} />
            <Route path="/monthly-reports" element={<MonthlyReportsPage />} />
            <Route path="/effort-plans" element={<EffortPlansPage />} />
            <Route path="/electricity-reports" element={<ElectricityReportsPage />} />
            <Route path="/equipment" element={<EquipmentPage />} />
            <Route path="/equipment-inspections" element={<EquipmentInspectionsPage />} />
            <Route path="/no-accident" element={<NoAccidentPage />} />
            <Route path="/weekly-schedules" element={<WeeklySchedulePage />} />
            <Route path="/business-daily" element={<BusinessDailyReportsPage />} />
            <Route path="/finance-stats" element={<FinanceStatsPage />} />
            <Route path="/guard-duties" element={<GuardDutiesPage />} />
            <Route path="/ultimate-stats" element={<UltimateStatsPage />} />
            <Route path="/search" element={<IntegratedSearchPage />} />
            <Route path="/ow/water" element={<DeptDailyReportsPage apiPath="water" section="ow_water" title="Water Transport Daily Report" subtitle="Daily reports filed under water transport operations." />} />
            <Route path="/ow/revenue" element={<DeptDailyReportsPage apiPath="revenue" section="ow_revenue" title="Revenue Examination Daily Report" subtitle="Daily reports filed by the revenue examination office." />} />
            <Route path="/effort-manage/daily" element={<DeptDailyReportsPage apiPath="effort" section="em_daily" title="Business Daily Report" subtitle="Effort Manage department daily reports." />} />
            <Route path="/first-business/daily" element={<DeptDailyReportsPage apiPath="first-business" section="fbc_daily" title="Business Daily Report" subtitle="First Business Comprehensive department daily reports." />} />
            <Route path="/parks" element={<ParksPage />} />
            <Route path="/staff" element={<StaffPage />} />
            <Route path="/vehicles" element={<VehiclesPage />} />
            <Route path="/transport" element={<TransportPage />} />
            <Route path="/admin/users" element={<UsersPage />} />
            <Route path="/admin/roles" element={<RolesPage />} />
            <Route path="/admin/requests" element={<AccountRequestsPage />} />
          </Route>
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </BrowserRouter>
      </ConfirmProvider>
      </ToastProvider>
    </AuthProvider>
  );
}
