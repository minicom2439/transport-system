import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Dev server proxies API + health to the Express backend so the session
// cookie stays same-origin (no CORS, cookie just works). In production the
// built files in dist/ are served by the backend at the same origin.
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      '/api': { target: 'http://localhost:4000', changeOrigin: true },
      '/health': { target: 'http://localhost:4000', changeOrigin: true },
    },
  },
  build: { outDir: 'dist', sourcemap: false },
});
