# HQ Land Transport Management System — Frontend

React 18 + Vite. **Offline / air-gapped**: no CDN, no web fonts, no network at
runtime. All dependencies are bundled at build time; the output is static files.

## Design
An operations console, not a marketing site: calm steel neutrals with one deep-teal
accent, system fonts (offline) with tabular numerals for data, and a persistent
left **system rail** that mirrors your five-system tree. Visible keyboard focus and
reduced-motion are respected.

## Structure
```
src/
  api/         fetch client (credentials: include) + one module per resource
  auth/        AuthContext (user + permissions + can()) and ProtectedRoute
  components/  reusable shell: Sidebar, Layout, TreeView, DataTable, Modal, Field, Icons
  pages/       Login, Dashboard, Units (full slice), Vehicles, Transport
  utils/       exportExcel (SheetJS, offline)
  styles/      tokens.css (design system) + global.css
```

The **Units page** is the reference pattern most screens reuse: region `TreeView`
(left) + units `DataTable` (right, with column filter + pagination) + create/edit
`Modal` + Excel export — every action shown only if the user holds the matching
permission (`can(section, action)`, mirroring the backend gates).

## Run in development
The backend must be running first (see backend README), over plain HTTP with
`COOKIE_SECURE=false`:
```bash
# terminal 1 — backend
cd ../backend && npm run db:reset && COOKIE_SECURE=false npm start

# terminal 2 — frontend
npm install --nodedir=/usr   # see backend README "Air-gapped install"
npm run dev                  # http://localhost:5173
```
Vite proxies `/api` and `/health` to the backend on :4000, so the session cookie
stays same-origin and just works. Log in with `admin` / `admin123`.

## Build for production (served by the backend, same origin)
```bash
npm run build                # outputs static files to dist/
```
Serve `dist/` from the Express backend so the UI and API share one origin (this is
what makes the session cookie work without CORS). Add to the backend's `app.js`,
**after** the `/api` routes and **before** the error handlers:
```js
const path = require('path');
const distDir = path.join(__dirname, '../../frontend/dist'); // adjust path
app.use(express.static(distDir));
// SPA fallback: send index.html for any non-API GET (client-side routing)
app.get(/^(?!\/api|\/health).*/, (req, res) =>
  res.sendFile(path.join(distDir, 'index.html')));
```
With this, the whole system is one server on the isolated network: API under
`/api`, the app everywhere else.

## Air-gapped notes
- All deps are pure JS — no native builds, unlike the backend. `npm install` on a
  connected machine then copy `node_modules` (or just commit the built `dist/`).
- The bundle includes SheetJS (Excel export), which is most of its size; everything
  is local, nothing is fetched at runtime.
