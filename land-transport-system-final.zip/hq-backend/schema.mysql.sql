-- =====================================================================
--  HQ Land Transport Management System — MySQL Schema (canonical)
--  Engine: InnoDB | Charset: utf8mb4
--  Source of truth for the DB team. Generated from data_model_v1.
--  Create order respects foreign-key dependencies.
-- =====================================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ---------------------------------------------------------------------
--  CONVENTIONS
--  - id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY on every table
--  - created_at / updated_at on every table
--  - created_by / updated_by (FK users) on business tables
--  - is_active flag for soft-delete on master/reference data
--  - lookups: id, name, code, description, is_active (+ timestamps)
-- ---------------------------------------------------------------------

-- =====================================================================
--  1. IDENTITY & ACCESS CORE (created early; referenced by audit cols)
-- =====================================================================

CREATE TABLE users (
  id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  username        VARCHAR(60)  NOT NULL,
  password_hash   VARCHAR(255) NOT NULL,
  full_name       VARCHAR(150) NOT NULL,
  is_super_admin  TINYINT(1)   NOT NULL DEFAULT 0,
  is_active       TINYINT(1)   NOT NULL DEFAULT 1,
  last_login_at   DATETIME     NULL,
  created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  created_by      BIGINT UNSIGNED NULL,
  updated_by      BIGINT UNSIGNED NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_users_username (username),
  CONSTRAINT fk_users_created_by FOREIGN KEY (created_by) REFERENCES users(id),
  CONSTRAINT fk_users_updated_by FOREIGN KEY (updated_by) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE roles (
  id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  name        VARCHAR(120) NOT NULL,
  code        VARCHAR(60)  NOT NULL,
  description VARCHAR(255) NULL,
  is_active   TINYINT(1)   NOT NULL DEFAULT 1,
  created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_roles_code (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE actions (
  id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  name        VARCHAR(60) NOT NULL,   -- view, add, edit, remove, export, approve, reject
  code        VARCHAR(30) NOT NULL,
  is_active   TINYINT(1)  NOT NULL DEFAULT 1,
  PRIMARY KEY (id),
  UNIQUE KEY uq_actions_code (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- The expandable system tree: 5 roots now; departments/modules/screens later.
CREATE TABLE system_sections (
  id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  parent_id   BIGINT UNSIGNED NULL,
  name        VARCHAR(200) NOT NULL,
  code        VARCHAR(80)  NOT NULL,
  node_type   TINYINT      NOT NULL DEFAULT 4,  -- 1=system,2=department,3=module,4=screen
  sort_order  INT          NOT NULL DEFAULT 0,
  is_active   TINYINT(1)   NOT NULL DEFAULT 1,
  created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_sections_code (code),
  KEY idx_sections_parent (parent_id),
  CONSTRAINT fk_sections_parent FOREIGN KEY (parent_id) REFERENCES system_sections(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================================
--  2. LOOKUP / REFERENCE TABLES
--     Shared shape: id, name, code, description, is_active, timestamps
-- =====================================================================

CREATE TABLE regions (
  id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  parent_id   BIGINT UNSIGNED NULL,
  name        VARCHAR(150) NOT NULL,
  level       TINYINT      NOT NULL DEFAULT 1,  -- 1=province,2=city,...
  code        VARCHAR(30)  NULL,
  is_active   TINYINT(1)   NOT NULL DEFAULT 1,
  created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_regions_parent (parent_id),
  CONSTRAINT fk_regions_parent FOREIGN KEY (parent_id) REFERENCES regions(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Generic lookups (one statement each, identical shape) -----------------
CREATE TABLE unit_types            (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, name VARCHAR(120) NOT NULL, code VARCHAR(40) NULL, description VARCHAR(255) NULL, is_active TINYINT(1) NOT NULL DEFAULT 1, PRIMARY KEY(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE unit_classifications  (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, name VARCHAR(120) NOT NULL, code VARCHAR(40) NULL, description VARCHAR(255) NULL, is_active TINYINT(1) NOT NULL DEFAULT 1, PRIMARY KEY(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci; -- Normal / Other
CREATE TABLE vehicle_types         (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, name VARCHAR(120) NOT NULL, code VARCHAR(40) NULL, description VARCHAR(255) NULL, is_active TINYINT(1) NOT NULL DEFAULT 1, PRIMARY KEY(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE structural_features   (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, name VARCHAR(120) NOT NULL, code VARCHAR(40) NULL, description VARCHAR(255) NULL, is_active TINYINT(1) NOT NULL DEFAULT 1, PRIMARY KEY(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE vehicle_forms         (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, name VARCHAR(120) NOT NULL, code VARCHAR(40) NULL, description VARCHAR(255) NULL, is_active TINYINT(1) NOT NULL DEFAULT 1, PRIMARY KEY(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE vehicle_uses          (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, name VARCHAR(120) NOT NULL, code VARCHAR(40) NULL, description VARCHAR(255) NULL, is_active TINYINT(1) NOT NULL DEFAULT 1, PRIMARY KEY(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE technical_statuses    (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, name VARCHAR(120) NOT NULL, code VARCHAR(40) NULL, description VARCHAR(255) NULL, is_active TINYINT(1) NOT NULL DEFAULT 1, PRIMARY KEY(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE equipment_categories  (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, name VARCHAR(120) NOT NULL, code VARCHAR(40) NULL, description VARCHAR(255) NULL, is_active TINYINT(1) NOT NULL DEFAULT 1, PRIMARY KEY(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE register_categories   (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, name VARCHAR(120) NOT NULL, code VARCHAR(40) NULL, description VARCHAR(255) NULL, is_active TINYINT(1) NOT NULL DEFAULT 1, PRIMARY KEY(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE safety_directives     (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, name VARCHAR(120) NOT NULL, code VARCHAR(40) NULL, description VARCHAR(255) NULL, is_active TINYINT(1) NOT NULL DEFAULT 1, PRIMARY KEY(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE vehicle_statuses      (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, name VARCHAR(120) NOT NULL, code VARCHAR(40) NULL, description VARCHAR(255) NULL, is_active TINYINT(1) NOT NULL DEFAULT 1, PRIMARY KEY(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE real_move_states      (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, name VARCHAR(120) NOT NULL, code VARCHAR(40) NULL, description VARCHAR(255) NULL, is_active TINYINT(1) NOT NULL DEFAULT 1, PRIMARY KEY(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE route_types           (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, name VARCHAR(120) NOT NULL, code VARCHAR(40) NULL, description VARCHAR(255) NULL, is_active TINYINT(1) NOT NULL DEFAULT 1, PRIMARY KEY(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci; -- traveler bus / small bus / freight
CREATE TABLE order_types           (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, name VARCHAR(120) NOT NULL, code VARCHAR(40) NULL, description VARCHAR(255) NULL, is_active TINYINT(1) NOT NULL DEFAULT 1, PRIMARY KEY(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci; -- baggage / long-distance freight
CREATE TABLE order_statuses        (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, name VARCHAR(120) NOT NULL, code VARCHAR(40) NULL, description VARCHAR(255) NULL, is_active TINYINT(1) NOT NULL DEFAULT 1, PRIMARY KEY(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci; -- pending / done ...
CREATE TABLE approval_statuses     (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, name VARCHAR(120) NOT NULL, code VARCHAR(40) NULL, description VARCHAR(255) NULL, is_active TINYINT(1) NOT NULL DEFAULT 1, PRIMARY KEY(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci; -- draft/submitted/approved/rejected/cancelled
CREATE TABLE accident_severities   (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, name VARCHAR(120) NOT NULL, code VARCHAR(40) NULL, description VARCHAR(255) NULL, is_active TINYINT(1) NOT NULL DEFAULT 1, PRIMARY KEY(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE schedule_types        (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, name VARCHAR(120) NOT NULL, code VARCHAR(40) NULL, description VARCHAR(255) NULL, is_active TINYINT(1) NOT NULL DEFAULT 1, PRIMARY KEY(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci; -- bus-daily/bus-fixed/security-duty/weekly-work
CREATE TABLE report_types          (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, name VARCHAR(120) NOT NULL, code VARCHAR(40) NULL, description VARCHAR(255) NULL, is_active TINYINT(1) NOT NULL DEFAULT 1, PRIMARY KEY(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE license_types         (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, name VARCHAR(120) NOT NULL, code VARCHAR(40) NULL, description VARCHAR(255) NULL, is_active TINYINT(1) NOT NULL DEFAULT 1, PRIMARY KEY(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE finance_categories    (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, name VARCHAR(120) NOT NULL, code VARCHAR(40) NULL, description VARCHAR(255) NULL, is_active TINYINT(1) NOT NULL DEFAULT 1, PRIMARY KEY(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================================
--  3. ORGANISATION: units, online state, parks, warehouses, staff
-- =====================================================================

CREATE TABLE units (
  id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  parent_id       BIGINT UNSIGNED NULL,
  region_id       BIGINT UNSIGNED NOT NULL,
  name            VARCHAR(200) NOT NULL,
  code            VARCHAR(50)  NULL,
  unit_type_id    BIGINT UNSIGNED NULL,
  classification_id BIGINT UNSIGNED NULL,
  address         VARCHAR(255) NULL,
  phone           VARCHAR(50)  NULL,
  is_active       TINYINT(1)   NOT NULL DEFAULT 1,
  created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  created_by      BIGINT UNSIGNED NULL,
  updated_by      BIGINT UNSIGNED NULL,
  PRIMARY KEY (id),
  KEY idx_units_parent (parent_id),
  KEY idx_units_region (region_id),
  CONSTRAINT fk_units_parent  FOREIGN KEY (parent_id) REFERENCES units(id),
  CONSTRAINT fk_units_region  FOREIGN KEY (region_id) REFERENCES regions(id),
  CONSTRAINT fk_units_type    FOREIGN KEY (unit_type_id) REFERENCES unit_types(id),
  CONSTRAINT fk_units_class   FOREIGN KEY (classification_id) REFERENCES unit_classifications(id),
  CONSTRAINT fk_units_cby     FOREIGN KEY (created_by) REFERENCES users(id),
  CONSTRAINT fk_units_uby     FOREIGN KEY (updated_by) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE unit_online_status (
  id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  unit_id      BIGINT UNSIGNED NOT NULL,
  is_online    TINYINT(1) NOT NULL DEFAULT 0,
  last_seen_at DATETIME NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_online_unit (unit_id),
  CONSTRAINT fk_online_unit FOREIGN KEY (unit_id) REFERENCES units(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE parks (
  id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  unit_id     BIGINT UNSIGNED NOT NULL,
  region_id   BIGINT UNSIGNED NULL,
  name        VARCHAR(200) NOT NULL,
  code        VARCHAR(50)  NULL,
  capacity    INT NULL,
  is_active   TINYINT(1) NOT NULL DEFAULT 1,
  created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  created_by  BIGINT UNSIGNED NULL,
  updated_by  BIGINT UNSIGNED NULL,
  PRIMARY KEY (id),
  KEY idx_parks_unit (unit_id),
  CONSTRAINT fk_parks_unit   FOREIGN KEY (unit_id) REFERENCES units(id),
  CONSTRAINT fk_parks_region FOREIGN KEY (region_id) REFERENCES regions(id),
  CONSTRAINT fk_parks_cby    FOREIGN KEY (created_by) REFERENCES users(id),
  CONSTRAINT fk_parks_uby    FOREIGN KEY (updated_by) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE warehouses (
  id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  unit_id       BIGINT UNSIGNED NOT NULL,
  region_id     BIGINT UNSIGNED NULL,
  name          VARCHAR(200) NOT NULL,
  code          VARCHAR(50)  NULL,
  capacity      DECIMAL(18,2) NULL,
  capacity_unit VARCHAR(20) NULL,
  is_active     TINYINT(1) NOT NULL DEFAULT 1,
  created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  created_by    BIGINT UNSIGNED NULL,
  updated_by    BIGINT UNSIGNED NULL,
  PRIMARY KEY (id),
  KEY idx_wh_unit (unit_id),
  CONSTRAINT fk_wh_unit   FOREIGN KEY (unit_id) REFERENCES units(id),
  CONSTRAINT fk_wh_region FOREIGN KEY (region_id) REFERENCES regions(id),
  CONSTRAINT fk_wh_cby    FOREIGN KEY (created_by) REFERENCES users(id),
  CONSTRAINT fk_wh_uby    FOREIGN KEY (updated_by) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE staff (
  id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  unit_id     BIGINT UNSIGNED NOT NULL,
  user_id     BIGINT UNSIGNED NULL,
  full_name   VARCHAR(150) NOT NULL,
  staff_no    VARCHAR(50)  NULL,
  position    VARCHAR(100) NULL,
  phone       VARCHAR(50)  NULL,
  date_joined DATE NULL,
  is_active   TINYINT(1) NOT NULL DEFAULT 1,
  created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  created_by  BIGINT UNSIGNED NULL,
  updated_by  BIGINT UNSIGNED NULL,
  PRIMARY KEY (id),
  KEY idx_staff_unit (unit_id),
  CONSTRAINT fk_staff_unit FOREIGN KEY (unit_id) REFERENCES units(id),
  CONSTRAINT fk_staff_user FOREIGN KEY (user_id) REFERENCES users(id),
  CONSTRAINT fk_staff_cby  FOREIGN KEY (created_by) REFERENCES users(id),
  CONSTRAINT fk_staff_uby  FOREIGN KEY (updated_by) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================================
--  4. VEHICLES & related
-- =====================================================================

CREATE TABLE vehicles (
  id                  BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  unit_id             BIGINT UNSIGNED NOT NULL,
  park_id             BIGINT UNSIGNED NULL,
  plate_no            VARCHAR(30) NOT NULL,
  vehicle_type_id     BIGINT UNSIGNED NULL,
  vehicle_form_id     BIGINT UNSIGNED NULL,
  use_id              BIGINT UNSIGNED NULL,
  technical_status_id BIGINT UNSIGNED NULL,
  equipment_category_id BIGINT UNSIGNED NULL,
  register_category_id  BIGINT UNSIGNED NULL,
  vehicle_status_id   BIGINT UNSIGNED NULL,
  structural_feature_id BIGINT UNSIGNED NULL,
  seat_count          INT NULL,
  load_capacity       DECIMAL(18,2) NULL,
  registered_on       DATE NULL,
  is_active           TINYINT(1) NOT NULL DEFAULT 1,
  created_at          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  created_by          BIGINT UNSIGNED NULL,
  updated_by          BIGINT UNSIGNED NULL,
  PRIMARY KEY (id),
  KEY idx_veh_unit (unit_id),
  KEY idx_veh_park (park_id),
  KEY idx_veh_type (vehicle_type_id),
  CONSTRAINT fk_veh_unit  FOREIGN KEY (unit_id) REFERENCES units(id),
  CONSTRAINT fk_veh_park  FOREIGN KEY (park_id) REFERENCES parks(id),
  CONSTRAINT fk_veh_type  FOREIGN KEY (vehicle_type_id) REFERENCES vehicle_types(id),
  CONSTRAINT fk_veh_form  FOREIGN KEY (vehicle_form_id) REFERENCES vehicle_forms(id),
  CONSTRAINT fk_veh_use   FOREIGN KEY (use_id) REFERENCES vehicle_uses(id),
  CONSTRAINT fk_veh_tech  FOREIGN KEY (technical_status_id) REFERENCES technical_statuses(id),
  CONSTRAINT fk_veh_equip FOREIGN KEY (equipment_category_id) REFERENCES equipment_categories(id),
  CONSTRAINT fk_veh_reg   FOREIGN KEY (register_category_id) REFERENCES register_categories(id),
  CONSTRAINT fk_veh_stat  FOREIGN KEY (vehicle_status_id) REFERENCES vehicle_statuses(id),
  CONSTRAINT fk_veh_struct FOREIGN KEY (structural_feature_id) REFERENCES structural_features(id),
  CONSTRAINT fk_veh_cby   FOREIGN KEY (created_by) REFERENCES users(id),
  CONSTRAINT fk_veh_uby   FOREIGN KEY (updated_by) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE gps_devices (
  id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  vehicle_id   BIGINT UNSIGNED NOT NULL,
  device_no    VARCHAR(60) NOT NULL,
  installed_on DATE NULL,
  is_active    TINYINT(1) NOT NULL DEFAULT 1,
  created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_gps_vehicle (vehicle_id),
  CONSTRAINT fk_gps_vehicle FOREIGN KEY (vehicle_id) REFERENCES vehicles(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE vehicle_locations (
  id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  vehicle_id  BIGINT UNSIGNED NOT NULL,
  recorded_at DATETIME NOT NULL,
  latitude    DECIMAL(10,7) NULL,
  longitude   DECIMAL(10,7) NULL,
  speed       DECIMAL(6,2)  NULL,
  PRIMARY KEY (id),
  KEY idx_vloc_vehicle_time (vehicle_id, recorded_at),
  CONSTRAINT fk_vloc_vehicle FOREIGN KEY (vehicle_id) REFERENCES vehicles(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================================
--  5. ROUTES, SECTIONS, APPROVALS, CERTIFICATES, CONDITIONS
-- =====================================================================

CREATE TABLE routes (
  id             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  unit_id        BIGINT UNSIGNED NOT NULL,
  route_no       VARCHAR(50) NOT NULL,
  name           VARCHAR(200) NULL,
  route_type_id  BIGINT UNSIGNED NULL,
  start_region_id BIGINT UNSIGNED NULL,
  end_region_id   BIGINT UNSIGNED NULL,
  distance_km    DECIMAL(8,2) NULL,
  is_active      TINYINT(1) NOT NULL DEFAULT 1,
  created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  created_by     BIGINT UNSIGNED NULL,
  updated_by     BIGINT UNSIGNED NULL,
  PRIMARY KEY (id),
  KEY idx_routes_unit (unit_id),
  CONSTRAINT fk_routes_unit  FOREIGN KEY (unit_id) REFERENCES units(id),
  CONSTRAINT fk_routes_type  FOREIGN KEY (route_type_id) REFERENCES route_types(id),
  CONSTRAINT fk_routes_start FOREIGN KEY (start_region_id) REFERENCES regions(id),
  CONSTRAINT fk_routes_end   FOREIGN KEY (end_region_id) REFERENCES regions(id),
  CONSTRAINT fk_routes_cby   FOREIGN KEY (created_by) REFERENCES users(id),
  CONSTRAINT fk_routes_uby   FOREIGN KEY (updated_by) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE transfer_sections (
  id             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  name           VARCHAR(200) NOT NULL,
  start_region_id BIGINT UNSIGNED NULL,
  end_region_id   BIGINT UNSIGNED NULL,
  is_active      TINYINT(1) NOT NULL DEFAULT 1,
  created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  created_by     BIGINT UNSIGNED NULL,
  PRIMARY KEY (id),
  CONSTRAINT fk_tsec_start FOREIGN KEY (start_region_id) REFERENCES regions(id),
  CONSTRAINT fk_tsec_end   FOREIGN KEY (end_region_id) REFERENCES regions(id),
  CONSTRAINT fk_tsec_cby   FOREIGN KEY (created_by) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Generic approval lifecycle (polymorphic owner via entity_type/entity_id)
CREATE TABLE approvals (
  id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  entity_type   VARCHAR(60) NOT NULL,
  entity_id     BIGINT UNSIGNED NULL,
  status_id     BIGINT UNSIGNED NOT NULL,
  submitted_by  BIGINT UNSIGNED NULL,
  submitted_at  DATETIME NULL,
  decided_by    BIGINT UNSIGNED NULL,
  decided_at    DATETIME NULL,
  comment       VARCHAR(500) NULL,
  created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_appr_entity (entity_type, entity_id),
  CONSTRAINT fk_appr_status FOREIGN KEY (status_id) REFERENCES approval_statuses(id),
  CONSTRAINT fk_appr_sub    FOREIGN KEY (submitted_by) REFERENCES users(id),
  CONSTRAINT fk_appr_dec    FOREIGN KEY (decided_by) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE approval_history (
  id             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  approval_id    BIGINT UNSIGNED NOT NULL,
  from_status_id BIGINT UNSIGNED NULL,
  to_status_id   BIGINT UNSIGNED NOT NULL,
  changed_by     BIGINT UNSIGNED NOT NULL,
  changed_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  comment        VARCHAR(500) NULL,
  PRIMARY KEY (id),
  KEY idx_apprh_approval (approval_id),
  CONSTRAINT fk_apprh_appr FOREIGN KEY (approval_id) REFERENCES approvals(id),
  CONSTRAINT fk_apprh_from FOREIGN KEY (from_status_id) REFERENCES approval_statuses(id),
  CONSTRAINT fk_apprh_to   FOREIGN KEY (to_status_id) REFERENCES approval_statuses(id),
  CONSTRAINT fk_apprh_by   FOREIGN KEY (changed_by) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE route_certificates (
  id             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  route_id       BIGINT UNSIGNED NOT NULL,
  unit_id        BIGINT UNSIGNED NOT NULL,
  certificate_no VARCHAR(60) NULL,
  cert_type_id   BIGINT UNSIGNED NULL,
  valid_from     DATE NULL,
  valid_to       DATE NULL,
  approval_id    BIGINT UNSIGNED NULL,
  is_active      TINYINT(1) NOT NULL DEFAULT 1,
  created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  created_by     BIGINT UNSIGNED NULL,
  updated_by     BIGINT UNSIGNED NULL,
  PRIMARY KEY (id),
  KEY idx_rc_route (route_id),
  KEY idx_rc_unit (unit_id),
  CONSTRAINT fk_rc_route FOREIGN KEY (route_id) REFERENCES routes(id),
  CONSTRAINT fk_rc_unit  FOREIGN KEY (unit_id) REFERENCES units(id),
  CONSTRAINT fk_rc_type  FOREIGN KEY (cert_type_id) REFERENCES route_types(id),
  CONSTRAINT fk_rc_appr  FOREIGN KEY (approval_id) REFERENCES approvals(id),
  CONSTRAINT fk_rc_cby   FOREIGN KEY (created_by) REFERENCES users(id),
  CONSTRAINT fk_rc_uby   FOREIGN KEY (updated_by) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Operating = business = sales conditions (single concept)
CREATE TABLE operating_conditions (
  id                 BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  unit_id            BIGINT UNSIGNED NOT NULL,
  title              VARCHAR(200) NOT NULL,
  condition_type_id  BIGINT UNSIGNED NULL,
  scope_description  TEXT NULL,
  allowed_vehicle_count INT NULL,
  allows_passenger   TINYINT(1) NOT NULL DEFAULT 0,
  allows_cargo       TINYINT(1) NOT NULL DEFAULT 0,
  valid_from         DATE NULL,
  valid_to           DATE NULL,
  approval_id        BIGINT UNSIGNED NULL,
  is_active          TINYINT(1) NOT NULL DEFAULT 1,
  created_at         DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at         DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  created_by         BIGINT UNSIGNED NULL,
  updated_by         BIGINT UNSIGNED NULL,
  PRIMARY KEY (id),
  KEY idx_oc_unit (unit_id),
  CONSTRAINT fk_oc_unit FOREIGN KEY (unit_id) REFERENCES units(id),
  CONSTRAINT fk_oc_appr FOREIGN KEY (approval_id) REFERENCES approvals(id),
  CONSTRAINT fk_oc_cby  FOREIGN KEY (created_by) REFERENCES users(id),
  CONSTRAINT fk_oc_uby  FOREIGN KEY (updated_by) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- condition_type_id intentionally has no FK target table yet (add lookup if needed)

-- =====================================================================
--  6. TRANSPORT RECORDS & ORDERS
-- =====================================================================

CREATE TABLE transport_records (
  id                 BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  vehicle_id         BIGINT UNSIGNED NOT NULL,
  unit_id            BIGINT UNSIGNED NOT NULL,   -- denormalised for fast roll-ups
  route_id           BIGINT UNSIGNED NULL,
  record_date        DATE NOT NULL,
  real_move_state_id BIGINT UNSIGNED NULL,
  transport_kind     TINYINT NOT NULL DEFAULT 1, -- 1=passenger,2=cargo,3=both
  trips              INT NOT NULL DEFAULT 0,
  distance_km        DECIMAL(10,2) NOT NULL DEFAULT 0,
  passengers_carried INT NOT NULL DEFAULT 0,
  cargo_weight       DECIMAL(14,2) NOT NULL DEFAULT 0,
  cargo_volume       DECIMAL(14,2) NOT NULL DEFAULT 0,
  revenue            DECIMAL(18,2) NOT NULL DEFAULT 0,
  created_at         DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at         DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_tr_vehicle_date (vehicle_id, record_date),
  KEY idx_tr_date (record_date),
  KEY idx_tr_unit_date (unit_id, record_date),
  KEY idx_tr_route_date (route_id, record_date),
  CONSTRAINT fk_tr_vehicle FOREIGN KEY (vehicle_id) REFERENCES vehicles(id),
  CONSTRAINT fk_tr_unit    FOREIGN KEY (unit_id) REFERENCES units(id),
  CONSTRAINT fk_tr_route   FOREIGN KEY (route_id) REFERENCES routes(id),
  CONSTRAINT fk_tr_rms     FOREIGN KEY (real_move_state_id) REFERENCES real_move_states(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE transport_orders (
  id               BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  order_no         VARCHAR(60) NOT NULL,
  order_type_id    BIGINT UNSIGNED NULL,
  unit_id          BIGINT UNSIGNED NULL,
  origin_region_id BIGINT UNSIGNED NULL,
  dest_region_id   BIGINT UNSIGNED NULL,
  order_date       DATETIME NULL,
  status_id        BIGINT UNSIGNED NULL,
  amount           DECIMAL(18,2) NULL,
  details          TEXT NULL,
  created_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_to_type (order_type_id),
  KEY idx_to_status (status_id),
  KEY idx_to_origin (origin_region_id),
  CONSTRAINT fk_to_type   FOREIGN KEY (order_type_id) REFERENCES order_types(id),
  CONSTRAINT fk_to_unit   FOREIGN KEY (unit_id) REFERENCES units(id),
  CONSTRAINT fk_to_origin FOREIGN KEY (origin_region_id) REFERENCES regions(id),
  CONSTRAINT fk_to_dest   FOREIGN KEY (dest_region_id) REFERENCES regions(id),
  CONSTRAINT fk_to_status FOREIGN KEY (status_id) REFERENCES order_statuses(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================================
--  7. REPORTS, SCHEDULES, COMMANDS, ACCIDENTS
-- =====================================================================

CREATE TABLE reports (
  id             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  report_type_id BIGINT UNSIGNED NOT NULL,
  scope_type     TINYINT NOT NULL DEFAULT 1, -- 1=unit,2=park,3=warehouse,4=dept,5=system
  scope_id       BIGINT UNSIGNED NULL,
  report_date    DATE NOT NULL,
  period         VARCHAR(20) NULL,
  title          VARCHAR(200) NULL,
  content        JSON NULL,
  approval_id    BIGINT UNSIGNED NULL,
  created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  created_by     BIGINT UNSIGNED NULL,
  updated_by     BIGINT UNSIGNED NULL,
  PRIMARY KEY (id),
  KEY idx_reports_type_date (report_type_id, report_date),
  KEY idx_reports_scope (scope_type, scope_id),
  CONSTRAINT fk_reports_type FOREIGN KEY (report_type_id) REFERENCES report_types(id),
  CONSTRAINT fk_reports_appr FOREIGN KEY (approval_id) REFERENCES approvals(id),
  CONSTRAINT fk_reports_cby  FOREIGN KEY (created_by) REFERENCES users(id),
  CONSTRAINT fk_reports_uby  FOREIGN KEY (updated_by) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE report_instructions (
  id             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  report_id      BIGINT UNSIGNED NULL,
  target_unit_id BIGINT UNSIGNED NOT NULL,
  body           TEXT NOT NULL,
  issued_by      BIGINT UNSIGNED NULL,
  created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_ri_report (report_id),
  CONSTRAINT fk_ri_report FOREIGN KEY (report_id) REFERENCES reports(id),
  CONSTRAINT fk_ri_unit   FOREIGN KEY (target_unit_id) REFERENCES units(id),
  CONSTRAINT fk_ri_by     FOREIGN KEY (issued_by) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE schedules (
  id               BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  schedule_type_id BIGINT UNSIGNED NOT NULL,
  park_id          BIGINT UNSIGNED NULL,
  unit_id          BIGINT UNSIGNED NULL,
  vehicle_id       BIGINT UNSIGNED NULL,
  route_id         BIGINT UNSIGNED NULL,
  schedule_date    DATE NULL,   -- NULL for "fixed" schedules
  start_time       TIME NULL,
  end_time         TIME NULL,
  notes            VARCHAR(255) NULL,
  created_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  created_by       BIGINT UNSIGNED NULL,
  PRIMARY KEY (id),
  KEY idx_sch_type (schedule_type_id),
  KEY idx_sch_park_date (park_id, schedule_date),
  CONSTRAINT fk_sch_type    FOREIGN KEY (schedule_type_id) REFERENCES schedule_types(id),
  CONSTRAINT fk_sch_park    FOREIGN KEY (park_id) REFERENCES parks(id),
  CONSTRAINT fk_sch_unit    FOREIGN KEY (unit_id) REFERENCES units(id),
  CONSTRAINT fk_sch_vehicle FOREIGN KEY (vehicle_id) REFERENCES vehicles(id),
  CONSTRAINT fk_sch_route   FOREIGN KEY (route_id) REFERENCES routes(id),
  CONSTRAINT fk_sch_cby     FOREIGN KEY (created_by) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE command_orders (
  id             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  target_unit_id BIGINT UNSIGNED NOT NULL,
  title          VARCHAR(200) NOT NULL,
  body           TEXT NULL,
  order_date     DATE NULL,
  status_id      BIGINT UNSIGNED NULL,
  created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  created_by     BIGINT UNSIGNED NULL,
  PRIMARY KEY (id),
  KEY idx_co_unit (target_unit_id),
  CONSTRAINT fk_co_unit   FOREIGN KEY (target_unit_id) REFERENCES units(id),
  CONSTRAINT fk_co_status FOREIGN KEY (status_id) REFERENCES order_statuses(id),
  CONSTRAINT fk_co_cby    FOREIGN KEY (created_by) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE accident_notifications (
  id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  unit_id     BIGINT UNSIGNED NOT NULL,
  vehicle_id  BIGINT UNSIGNED NULL,
  occurred_at DATETIME NOT NULL,
  location    VARCHAR(255) NULL,
  severity_id BIGINT UNSIGNED NULL,
  description TEXT NULL,
  status_id   BIGINT UNSIGNED NULL,
  created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  created_by  BIGINT UNSIGNED NULL,
  PRIMARY KEY (id),
  KEY idx_acc_unit (unit_id),
  CONSTRAINT fk_acc_unit     FOREIGN KEY (unit_id) REFERENCES units(id),
  CONSTRAINT fk_acc_vehicle  FOREIGN KEY (vehicle_id) REFERENCES vehicles(id),
  CONSTRAINT fk_acc_severity FOREIGN KEY (severity_id) REFERENCES accident_severities(id),
  CONSTRAINT fk_acc_status   FOREIGN KEY (status_id) REFERENCES order_statuses(id),
  CONSTRAINT fk_acc_cby      FOREIGN KEY (created_by) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================================
--  8. ACCESS CONTROL bridge tables + AUDIT
-- =====================================================================

CREATE TABLE role_permissions (
  id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  role_id    BIGINT UNSIGNED NOT NULL,
  section_id BIGINT UNSIGNED NOT NULL,
  action_id  BIGINT UNSIGNED NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_rp (role_id, section_id, action_id),
  CONSTRAINT fk_rp_role    FOREIGN KEY (role_id) REFERENCES roles(id),
  CONSTRAINT fk_rp_section FOREIGN KEY (section_id) REFERENCES system_sections(id),
  CONSTRAINT fk_rp_action  FOREIGN KEY (action_id) REFERENCES actions(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE user_roles (
  id      BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id BIGINT UNSIGNED NOT NULL,
  role_id BIGINT UNSIGNED NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_ur (user_id, role_id),
  CONSTRAINT fk_ur_user FOREIGN KEY (user_id) REFERENCES users(id),
  CONSTRAINT fk_ur_role FOREIGN KEY (role_id) REFERENCES roles(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE user_data_scopes (
  id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id    BIGINT UNSIGNED NOT NULL,
  scope_type TINYINT NOT NULL,   -- 1=unit, 2=region
  scope_id   BIGINT UNSIGNED NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_uds (user_id, scope_type, scope_id),
  KEY idx_uds_user (user_id),
  CONSTRAINT fk_uds_user FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE section_managers (
  id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id    BIGINT UNSIGNED NOT NULL,
  section_id BIGINT UNSIGNED NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by BIGINT UNSIGNED NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_sm (user_id, section_id),
  CONSTRAINT fk_sm_user    FOREIGN KEY (user_id) REFERENCES users(id),
  CONSTRAINT fk_sm_section FOREIGN KEY (section_id) REFERENCES system_sections(id),
  CONSTRAINT fk_sm_cby     FOREIGN KEY (created_by) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE audit_log (
  id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id     BIGINT UNSIGNED NULL,
  action      VARCHAR(20) NOT NULL,
  entity_type VARCHAR(60) NOT NULL,
  entity_id   BIGINT UNSIGNED NULL,
  before_json JSON NULL,
  after_json  JSON NULL,
  at          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  ip_or_host  VARCHAR(60) NULL,
  PRIMARY KEY (id),
  KEY idx_audit_entity (entity_type, entity_id),
  KEY idx_audit_user_time (user_id, at),
  CONSTRAINT fk_audit_user FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================================
--  9. FINANCE
-- =====================================================================

CREATE TABLE licenses (
  id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  unit_id         BIGINT UNSIGNED NOT NULL,
  license_no      VARCHAR(60) NULL,
  license_type_id BIGINT UNSIGNED NULL,
  valid_from      DATE NULL,
  valid_to        DATE NULL,
  approval_id     BIGINT UNSIGNED NULL,
  is_active       TINYINT(1) NOT NULL DEFAULT 1,
  created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  created_by      BIGINT UNSIGNED NULL,
  PRIMARY KEY (id),
  KEY idx_lic_unit (unit_id),
  CONSTRAINT fk_lic_unit FOREIGN KEY (unit_id) REFERENCES units(id),
  CONSTRAINT fk_lic_type FOREIGN KEY (license_type_id) REFERENCES license_types(id),
  CONSTRAINT fk_lic_appr FOREIGN KEY (approval_id) REFERENCES approvals(id),
  CONSTRAINT fk_lic_cby  FOREIGN KEY (created_by) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE invoices (
  id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  invoice_no VARCHAR(60) NOT NULL,
  unit_id    BIGINT UNSIGNED NULL,
  order_id   BIGINT UNSIGNED NULL,
  amount     DECIMAL(18,2) NOT NULL DEFAULT 0,
  issued_at  DATETIME NULL,
  status_id  BIGINT UNSIGNED NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_inv_unit (unit_id),
  CONSTRAINT fk_inv_unit   FOREIGN KEY (unit_id) REFERENCES units(id),
  CONSTRAINT fk_inv_order  FOREIGN KEY (order_id) REFERENCES transport_orders(id),
  CONSTRAINT fk_inv_status FOREIGN KEY (status_id) REFERENCES order_statuses(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE finance_records (
  id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  unit_id     BIGINT UNSIGNED NOT NULL,
  record_date DATE NOT NULL,
  category_id BIGINT UNSIGNED NULL,
  direction   TINYINT NOT NULL DEFAULT 1, -- 1=income, 2=expense
  amount      DECIMAL(18,2) NOT NULL DEFAULT 0,
  note        VARCHAR(255) NULL,
  created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  created_by  BIGINT UNSIGNED NULL,
  PRIMARY KEY (id),
  KEY idx_fin_unit_date (unit_id, record_date),
  CONSTRAINT fk_fin_unit FOREIGN KEY (unit_id) REFERENCES units(id),
  CONSTRAINT fk_fin_cat  FOREIGN KEY (category_id) REFERENCES finance_categories(id),
  CONSTRAINT fk_fin_cby  FOREIGN KEY (created_by) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================================
--  10. TRANSPORT COMMAND / NATIONAL INDICATORS
-- =====================================================================

CREATE TABLE transport_indicators (
  id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  name            VARCHAR(200) NOT NULL,
  code            VARCHAR(60) NULL,
  unit_of_measure VARCHAR(40) NULL,
  description     VARCHAR(255) NULL,
  is_active       TINYINT(1) NOT NULL DEFAULT 1,
  created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE indicator_values (
  id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  indicator_id BIGINT UNSIGNED NOT NULL,
  unit_id      BIGINT UNSIGNED NULL,
  region_id    BIGINT UNSIGNED NULL,
  period       VARCHAR(20) NULL,
  value        DECIMAL(18,2) NOT NULL DEFAULT 0,
  created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_iv_indicator (indicator_id),
  CONSTRAINT fk_iv_indicator FOREIGN KEY (indicator_id) REFERENCES transport_indicators(id),
  CONSTRAINT fk_iv_unit      FOREIGN KEY (unit_id) REFERENCES units(id),
  CONSTRAINT fk_iv_region    FOREIGN KEY (region_id) REFERENCES regions(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================================
--  11. INFORMATION SERVICE
-- =====================================================================

CREATE TABLE notices (
  id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  title        VARCHAR(200) NOT NULL,
  body         TEXT NULL,
  published_at DATETIME NULL,
  is_published TINYINT(1) NOT NULL DEFAULT 0,
  author_id    BIGINT UNSIGNED NULL,
  created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  CONSTRAINT fk_notices_author FOREIGN KEY (author_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE faqs (
  id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  question   VARCHAR(255) NOT NULL,
  answer     TEXT NULL,
  sort_order INT NOT NULL DEFAULT 0,
  is_active  TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE programs (
  id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  name        VARCHAR(200) NOT NULL,
  version     VARCHAR(40) NULL,
  file_path   VARCHAR(255) NULL,   -- local server path (no network)
  description VARCHAR(255) NULL,
  is_active   TINYINT(1) NOT NULL DEFAULT 1,
  created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE tech_data_submissions (
  id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  title        VARCHAR(200) NOT NULL,
  unit_id      BIGINT UNSIGNED NULL,
  submitted_by BIGINT UNSIGNED NULL,
  submitted_at DATETIME NULL,
  file_path    VARCHAR(255) NULL,
  status_id    BIGINT UNSIGNED NULL,
  created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  CONSTRAINT fk_tds_unit   FOREIGN KEY (unit_id) REFERENCES units(id),
  CONSTRAINT fk_tds_by     FOREIGN KEY (submitted_by) REFERENCES users(id),
  CONSTRAINT fk_tds_status FOREIGN KEY (status_id) REFERENCES order_statuses(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE feedback (
  id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  subject      VARCHAR(200) NULL,
  body         TEXT NOT NULL,
  submitted_by BIGINT UNSIGNED NULL,
  submitted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  is_read      TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  CONSTRAINT fk_fb_by FOREIGN KEY (submitted_by) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================================
--  12. ANALYTICS ROLL-UP TABLES (derived from transport_records)
-- =====================================================================

CREATE TABLE stat_transport_daily (
  id                 BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  stat_date          DATE NOT NULL,
  unit_id            BIGINT UNSIGNED NULL,
  route_id           BIGINT UNSIGNED NULL,
  region_id          BIGINT UNSIGNED NULL,
  vehicle_type_id    BIGINT UNSIGNED NULL,
  trips              INT NOT NULL DEFAULT 0,
  distance_km        DECIMAL(16,2) NOT NULL DEFAULT 0,
  passengers_carried BIGINT NOT NULL DEFAULT 0,
  cargo_weight       DECIMAL(18,2) NOT NULL DEFAULT 0,
  cargo_volume       DECIMAL(18,2) NOT NULL DEFAULT 0,
  revenue            DECIMAL(20,2) NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  KEY idx_std_date (stat_date),
  KEY idx_std_unit (unit_id, stat_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE stat_transport_monthly (
  id                 BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  stat_year          SMALLINT NOT NULL,
  stat_month         TINYINT NOT NULL,
  unit_id            BIGINT UNSIGNED NULL,
  route_id           BIGINT UNSIGNED NULL,
  region_id          BIGINT UNSIGNED NULL,
  vehicle_type_id    BIGINT UNSIGNED NULL,
  trips              BIGINT NOT NULL DEFAULT 0,
  distance_km        DECIMAL(18,2) NOT NULL DEFAULT 0,
  passengers_carried BIGINT NOT NULL DEFAULT 0,
  cargo_weight       DECIMAL(20,2) NOT NULL DEFAULT 0,
  cargo_volume       DECIMAL(20,2) NOT NULL DEFAULT 0,
  revenue            DECIMAL(22,2) NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  KEY idx_stm_period (stat_year, stat_month),
  KEY idx_stm_unit (unit_id, stat_year, stat_month)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE stat_transport_quarterly (
  id                 BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  stat_year          SMALLINT NOT NULL,
  stat_quarter       TINYINT NOT NULL,
  unit_id            BIGINT UNSIGNED NULL,
  route_id           BIGINT UNSIGNED NULL,
  region_id          BIGINT UNSIGNED NULL,
  vehicle_type_id    BIGINT UNSIGNED NULL,
  trips              BIGINT NOT NULL DEFAULT 0,
  distance_km        DECIMAL(18,2) NOT NULL DEFAULT 0,
  passengers_carried BIGINT NOT NULL DEFAULT 0,
  cargo_weight       DECIMAL(20,2) NOT NULL DEFAULT 0,
  cargo_volume       DECIMAL(20,2) NOT NULL DEFAULT 0,
  revenue            DECIMAL(22,2) NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  KEY idx_stq_period (stat_year, stat_quarter),
  KEY idx_stq_unit (unit_id, stat_year, stat_quarter)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE notifications (
  id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id     BIGINT UNSIGNED NOT NULL,
  type        VARCHAR(40) NOT NULL,          -- approval / accident / feedback / system
  title       VARCHAR(200) NOT NULL,
  body        VARCHAR(500) NULL,
  link        VARCHAR(120) NULL,             -- client route to open
  is_read     TINYINT(1) NOT NULL DEFAULT 0,
  created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_notif_user (user_id, is_read, created_at),
  CONSTRAINT fk_notif_user FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
-- =====================================================================
--  END OF SCHEMA
-- =====================================================================
