// src/db/session-store.js
// Minimal server-side session store backed by Knex, so sessions persist and
// work across restarts without any external service. Implements the
// express-session Store interface (get/set/destroy/touch). Pure-JS, offline.
const session = require('express-session');

// Call once at startup to create the table, avoiding a create race between
// concurrent first requests.
async function ensureSessionTable(knex) {
  const has = await knex.schema.hasTable('sessions');
  if (!has) {
    await knex.schema.createTable('sessions', (t) => {
      t.string('sid').primary();
      t.text('sess').notNullable();
      t.bigInteger('expired').notNullable();
    });
  }
}

function createKnexSessionStore(knex) {
  class KnexStore extends session.Store {
    async get(sid, cb) {
      try {
        const row = await knex('sessions').where({ sid }).first();
        if (!row) return cb(null, null);
        if (row.expired < Date.now()) {
          await knex('sessions').where({ sid }).del();
          return cb(null, null);
        }
        return cb(null, JSON.parse(row.sess));
      } catch (e) { return cb(e); }
    }

    async set(sid, sess, cb) {
      try {
        const expired = sess.cookie && sess.cookie.expires
          ? new Date(sess.cookie.expires).getTime()
          : Date.now() + 8 * 60 * 60 * 1000;
        const payload = JSON.stringify(sess);
        // Atomic upsert avoids a race between concurrent writes for one sid.
        await knex('sessions')
          .insert({ sid, sess: payload, expired })
          .onConflict('sid')
          .merge({ sess: payload, expired });
        return cb(null);
      } catch (e) { return cb(e); }
    }

    async destroy(sid, cb) {
      try { await knex('sessions').where({ sid }).del(); return cb(null); }
      catch (e) { return cb(e); }
    }

    async touch(sid, sess, cb) {
      try {
        const expired = sess.cookie && sess.cookie.expires
          ? new Date(sess.cookie.expires).getTime()
          : Date.now() + 8 * 60 * 60 * 1000;
        await knex('sessions').where({ sid }).update({ expired });
        return cb(null);
      } catch (e) { return cb(e); }
    }
  }
  return new KnexStore();
}

module.exports = createKnexSessionStore;
module.exports.ensureSessionTable = ensureSessionTable;
