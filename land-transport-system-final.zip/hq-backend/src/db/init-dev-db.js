// src/db/init-dev-db.js
// Development only: builds the SQLite stand-in from the SAME schema file the
// DB team works from (schema.sqlite.sql, generated from schema.mysql.sql).
// Production uses the DB team's real MySQL database — this script is not run there.
const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');
const config = require('../config');

if (config.isProduction) {
  console.error('Refusing to run dev DB init in production.');
  process.exit(1);
}

const dbFile = process.env.SQLITE_FILE || path.join(__dirname, '../../dev.db');
const schemaPath = path.join(__dirname, 'schema.sqlite.sql');

if (fs.existsSync(dbFile)) fs.unlinkSync(dbFile);

const schema = fs.readFileSync(schemaPath, 'utf8');
const db = new Database(dbFile);
db.exec(schema);

// Infra-only table for server-side sessions (not business data, so it lives
// outside the canonical schema). Created here for dev; documented for prod.
db.exec(`
  CREATE TABLE IF NOT EXISTS sessions (
    sid     TEXT PRIMARY KEY,
    sess    TEXT NOT NULL,
    expired INTEGER NOT NULL
  );
`);

const count = db.prepare(
  "SELECT count(*) AS n FROM sqlite_master WHERE type='table'"
).get().n;
db.close();

console.log(`Dev DB ready at ${dbFile} (${count} tables).`);
