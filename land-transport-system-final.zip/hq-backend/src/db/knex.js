// src/db/knex.js
// The ONE place a database connection is created. Every repository imports
// this instance; nothing else in the app constructs a connection.
const knexLib = require('knex');
const knexConfig = require('../../knexfile');
const config = require('../config');

const knex = knexLib(knexConfig[config.env]);

module.exports = knex;
