PRAGMA foreign_keys = ON;

CREATE TABLE users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username        TEXT  NOT NULL,
  password_hash   TEXT NOT NULL,
  full_name       TEXT NOT NULL,
  unit_id         INTEGER NULL,
  position        TEXT NULL,
  mobile_phone    TEXT  NULL,
  office_phone    TEXT  NULL,
  certificate_id  TEXT NULL,
  is_super_admin  INTEGER   NOT NULL DEFAULT 0,
  is_active       INTEGER   NOT NULL DEFAULT 1,
  last_login_at   TEXT     NULL,
  created_at      TEXT     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at      TEXT     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by      INTEGER NULL,
  updated_by      INTEGER NULL,
  CONSTRAINT fk_users_created_by FOREIGN KEY (created_by) REFERENCES users(id),
  CONSTRAINT fk_users_updated_by FOREIGN KEY (updated_by) REFERENCES users(id)
);

CREATE TABLE roles (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name        TEXT NOT NULL,
  code        TEXT  NOT NULL,
  description TEXT NULL,
  is_active   INTEGER   NOT NULL DEFAULT 1,
  created_at  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE actions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name        TEXT NOT NULL,
  code        TEXT NOT NULL,
  is_active   INTEGER  NOT NULL DEFAULT 1
);

CREATE TABLE system_sections (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  parent_id   INTEGER NULL,
  name        TEXT NOT NULL,
  code        TEXT  NOT NULL,
  node_type   INTEGER      NOT NULL DEFAULT 4,
  system_code TEXT  NOT NULL DEFAULT 'hq',
  sort_order  INTEGER          NOT NULL DEFAULT 0,
  is_active   INTEGER   NOT NULL DEFAULT 1,
  created_at  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_sections_parent FOREIGN KEY (parent_id) REFERENCES system_sections(id)
);

CREATE TABLE regions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  parent_id   INTEGER NULL,
  name        TEXT NOT NULL,
  level       INTEGER      NOT NULL DEFAULT 1,
  code        TEXT  NULL,
  is_active   INTEGER   NOT NULL DEFAULT 1,
  created_at  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_regions_parent FOREIGN KEY (parent_id) REFERENCES regions(id)
);

CREATE TABLE unit_types (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  code TEXT NULL,
  description TEXT NULL,
  is_active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE unit_classifications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  code TEXT NULL,
  description TEXT NULL,
  is_active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE vehicle_types (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  code TEXT NULL,
  description TEXT NULL,
  is_active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE structural_features (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  code TEXT NULL,
  description TEXT NULL,
  is_active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE vehicle_forms (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  code TEXT NULL,
  description TEXT NULL,
  is_active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE vehicle_uses (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  code TEXT NULL,
  description TEXT NULL,
  is_active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE technical_statuses (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  code TEXT NULL,
  description TEXT NULL,
  is_active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE equipment_categories (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  code TEXT NULL,
  description TEXT NULL,
  is_active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE register_categories (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  code TEXT NULL,
  description TEXT NULL,
  is_active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE safety_directives (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  code TEXT NULL,
  description TEXT NULL,
  is_active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE vehicle_statuses (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  code TEXT NULL,
  description TEXT NULL,
  is_active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE real_move_states (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  code TEXT NULL,
  description TEXT NULL,
  is_active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE route_types (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  code TEXT NULL,
  description TEXT NULL,
  is_active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE order_types (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  code TEXT NULL,
  description TEXT NULL,
  is_active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE order_statuses (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  code TEXT NULL,
  description TEXT NULL,
  is_active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE approval_statuses (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  code TEXT NULL,
  description TEXT NULL,
  is_active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE accident_severities (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  code TEXT NULL,
  description TEXT NULL,
  is_active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE schedule_types (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  code TEXT NULL,
  description TEXT NULL,
  is_active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE report_types (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  code TEXT NULL,
  description TEXT NULL,
  is_active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE license_types (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  code TEXT NULL,
  description TEXT NULL,
  is_active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE finance_categories (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  code TEXT NULL,
  description TEXT NULL,
  is_active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE units (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  parent_id       INTEGER NULL,
  region_id       INTEGER NOT NULL,
  name            TEXT NOT NULL,
  code            TEXT  NULL,
  unit_type_id    INTEGER NULL,
  classification_id INTEGER NULL,
  address         TEXT NULL,
  phone           TEXT  NULL,
  is_active       INTEGER   NOT NULL DEFAULT 1,
  created_at      TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at      TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by      INTEGER NULL,
  updated_by      INTEGER NULL,
  CONSTRAINT fk_units_parent  FOREIGN KEY (parent_id) REFERENCES units(id),
  CONSTRAINT fk_units_region  FOREIGN KEY (region_id) REFERENCES regions(id),
  CONSTRAINT fk_units_type    FOREIGN KEY (unit_type_id) REFERENCES unit_types(id),
  CONSTRAINT fk_units_class   FOREIGN KEY (classification_id) REFERENCES unit_classifications(id),
  CONSTRAINT fk_units_cby     FOREIGN KEY (created_by) REFERENCES users(id),
  CONSTRAINT fk_units_uby     FOREIGN KEY (updated_by) REFERENCES users(id)
);

CREATE TABLE unit_online_status (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  unit_id      INTEGER NOT NULL,
  is_online    INTEGER NOT NULL DEFAULT 0,
  last_seen_at TEXT NULL,
  CONSTRAINT fk_online_unit FOREIGN KEY (unit_id) REFERENCES units(id)
);

CREATE TABLE parks (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  unit_id     INTEGER NOT NULL,
  region_id   INTEGER NULL,
  name        TEXT NOT NULL,
  code        TEXT  NULL,
  capacity    INTEGER NULL,
  is_active   INTEGER NOT NULL DEFAULT 1,
  created_at  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by  INTEGER NULL,
  updated_by  INTEGER NULL,
  CONSTRAINT fk_parks_unit   FOREIGN KEY (unit_id) REFERENCES units(id),
  CONSTRAINT fk_parks_region FOREIGN KEY (region_id) REFERENCES regions(id),
  CONSTRAINT fk_parks_cby    FOREIGN KEY (created_by) REFERENCES users(id),
  CONSTRAINT fk_parks_uby    FOREIGN KEY (updated_by) REFERENCES users(id)
);

CREATE TABLE warehouses (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  unit_id       INTEGER NOT NULL,
  region_id     INTEGER NULL,
  name          TEXT NOT NULL,
  code          TEXT  NULL,
  capacity      NUMERIC NULL,
  capacity_unit TEXT NULL,
  is_active     INTEGER NOT NULL DEFAULT 1,
  created_at    TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at    TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by    INTEGER NULL,
  updated_by    INTEGER NULL,
  CONSTRAINT fk_wh_unit   FOREIGN KEY (unit_id) REFERENCES units(id),
  CONSTRAINT fk_wh_region FOREIGN KEY (region_id) REFERENCES regions(id),
  CONSTRAINT fk_wh_cby    FOREIGN KEY (created_by) REFERENCES users(id),
  CONSTRAINT fk_wh_uby    FOREIGN KEY (updated_by) REFERENCES users(id)
);

CREATE TABLE staff (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  unit_id     INTEGER NOT NULL,
  user_id     INTEGER NULL,
  full_name   TEXT NOT NULL,
  staff_no    TEXT  NULL,
  position    TEXT NULL,
  department_id INTEGER NULL,
  job_id      INTEGER NULL,
  photo_path  TEXT NULL,
  phone       TEXT  NULL,
  date_joined TEXT NULL,
  is_active   INTEGER NOT NULL DEFAULT 1,
  created_at  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by  INTEGER NULL,
  updated_by  INTEGER NULL,
  CONSTRAINT fk_staff_unit FOREIGN KEY (unit_id) REFERENCES units(id),
  CONSTRAINT fk_staff_user FOREIGN KEY (user_id) REFERENCES users(id),
  CONSTRAINT fk_staff_cby  FOREIGN KEY (created_by) REFERENCES users(id),
  CONSTRAINT fk_staff_uby  FOREIGN KEY (updated_by) REFERENCES users(id)
);

CREATE TABLE vehicles (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  unit_id             INTEGER NOT NULL,
  park_id             INTEGER NULL,
  plate_no            TEXT NOT NULL,
  vehicle_type_id     INTEGER NULL,
  vehicle_form_id     INTEGER NULL,
  use_id              INTEGER NULL,
  technical_status_id INTEGER NULL,
  equipment_category_id INTEGER NULL,
  register_category_id  INTEGER NULL,
  vehicle_status_id   INTEGER NULL,
  structural_feature_id INTEGER NULL,
  seat_count          INTEGER NULL,
  load_capacity       NUMERIC NULL,
  registered_on       TEXT NULL,
  is_active           INTEGER NOT NULL DEFAULT 1,
  created_at          TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at          TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by          INTEGER NULL,
  updated_by          INTEGER NULL,
  CONSTRAINT fk_veh_unit  FOREIGN KEY (unit_id) REFERENCES units(id),
  CONSTRAINT fk_veh_park  FOREIGN KEY (park_id) REFERENCES parks(id),
  CONSTRAINT fk_veh_type  FOREIGN KEY (vehicle_type_id) REFERENCES vehicle_types(id),
  CONSTRAINT fk_veh_form  FOREIGN KEY (vehicle_form_id) REFERENCES vehicle_forms(id),
  CONSTRAINT fk_veh_use   FOREIGN KEY (use_id) REFERENCES vehicle_uses(id),
  CONSTRAINT fk_veh_tech  FOREIGN KEY (technical_status_id) REFERENCES technical_statuses(id),
  CONSTRAINT fk_veh_equip FOREIGN KEY (equipment_category_id) REFERENCES equipment_categories(id),
  CONSTRAINT fk_veh_reg   FOREIGN KEY (register_category_id) REFERENCES register_categories(id),
  CONSTRAINT fk_veh_stat  FOREIGN KEY (vehicle_status_id) REFERENCES vehicle_statuses(id),
  CONSTRAINT fk_veh_struct FOREIGN KEY (structural_feature_id) REFERENCES structural_features(id),
  CONSTRAINT fk_veh_cby   FOREIGN KEY (created_by) REFERENCES users(id),
  CONSTRAINT fk_veh_uby   FOREIGN KEY (updated_by) REFERENCES users(id)
);

CREATE TABLE gps_devices (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  vehicle_id   INTEGER NOT NULL,
  device_no    TEXT NOT NULL,
  installed_on TEXT NULL,
  is_active    INTEGER NOT NULL DEFAULT 1,
  created_at   TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at   TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_gps_vehicle FOREIGN KEY (vehicle_id) REFERENCES vehicles(id)
);

CREATE TABLE vehicle_locations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  vehicle_id  INTEGER NOT NULL,
  recorded_at TEXT NOT NULL,
  latitude    NUMERIC NULL,
  longitude   NUMERIC NULL,
  speed       NUMERIC  NULL,
  CONSTRAINT fk_vloc_vehicle FOREIGN KEY (vehicle_id) REFERENCES vehicles(id)
);

CREATE TABLE routes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  unit_id        INTEGER NOT NULL,
  route_no       TEXT NOT NULL,
  name           TEXT NULL,
  route_type_id  INTEGER NULL,
  start_region_id INTEGER NULL,
  end_region_id   INTEGER NULL,
  distance_km    NUMERIC NULL,
  is_active      INTEGER NOT NULL DEFAULT 1,
  created_at     TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at     TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by     INTEGER NULL,
  updated_by     INTEGER NULL,
  CONSTRAINT fk_routes_unit  FOREIGN KEY (unit_id) REFERENCES units(id),
  CONSTRAINT fk_routes_type  FOREIGN KEY (route_type_id) REFERENCES route_types(id),
  CONSTRAINT fk_routes_start FOREIGN KEY (start_region_id) REFERENCES regions(id),
  CONSTRAINT fk_routes_end   FOREIGN KEY (end_region_id) REFERENCES regions(id),
  CONSTRAINT fk_routes_cby   FOREIGN KEY (created_by) REFERENCES users(id),
  CONSTRAINT fk_routes_uby   FOREIGN KEY (updated_by) REFERENCES users(id)
);

CREATE TABLE transfer_sections (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name           TEXT NOT NULL,
  start_region_id INTEGER NULL,
  end_region_id   INTEGER NULL,
  is_active      INTEGER NOT NULL DEFAULT 1,
  created_at     TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at     TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by     INTEGER NULL,
  CONSTRAINT fk_tsec_start FOREIGN KEY (start_region_id) REFERENCES regions(id),
  CONSTRAINT fk_tsec_end   FOREIGN KEY (end_region_id) REFERENCES regions(id),
  CONSTRAINT fk_tsec_cby   FOREIGN KEY (created_by) REFERENCES users(id)
);

CREATE TABLE approvals (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  entity_type   TEXT NOT NULL,
  entity_id     INTEGER NULL,
  status_id     INTEGER NOT NULL,
  submitted_by  INTEGER NULL,
  submitted_at  TEXT NULL,
  decided_by    INTEGER NULL,
  decided_at    TEXT NULL,
  comment       TEXT NULL,
  created_at    TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at    TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_appr_status FOREIGN KEY (status_id) REFERENCES approval_statuses(id),
  CONSTRAINT fk_appr_sub    FOREIGN KEY (submitted_by) REFERENCES users(id),
  CONSTRAINT fk_appr_dec    FOREIGN KEY (decided_by) REFERENCES users(id)
);

CREATE TABLE approval_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  approval_id    INTEGER NOT NULL,
  from_status_id INTEGER NULL,
  to_status_id   INTEGER NOT NULL,
  changed_by     INTEGER NOT NULL,
  changed_at     TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  comment        TEXT NULL,
  CONSTRAINT fk_apprh_appr FOREIGN KEY (approval_id) REFERENCES approvals(id),
  CONSTRAINT fk_apprh_from FOREIGN KEY (from_status_id) REFERENCES approval_statuses(id),
  CONSTRAINT fk_apprh_to   FOREIGN KEY (to_status_id) REFERENCES approval_statuses(id),
  CONSTRAINT fk_apprh_by   FOREIGN KEY (changed_by) REFERENCES users(id)
);

CREATE TABLE route_certificates (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  route_id       INTEGER NOT NULL,
  unit_id        INTEGER NOT NULL,
  certificate_no TEXT NULL,
  cert_type_id   INTEGER NULL,
  valid_from     TEXT NULL,
  valid_to       TEXT NULL,
  approval_id    INTEGER NULL,
  is_active      INTEGER NOT NULL DEFAULT 1,
  created_at     TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at     TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by     INTEGER NULL,
  updated_by     INTEGER NULL,
  CONSTRAINT fk_rc_route FOREIGN KEY (route_id) REFERENCES routes(id),
  CONSTRAINT fk_rc_unit  FOREIGN KEY (unit_id) REFERENCES units(id),
  CONSTRAINT fk_rc_type  FOREIGN KEY (cert_type_id) REFERENCES route_types(id),
  CONSTRAINT fk_rc_appr  FOREIGN KEY (approval_id) REFERENCES approvals(id),
  CONSTRAINT fk_rc_cby   FOREIGN KEY (created_by) REFERENCES users(id),
  CONSTRAINT fk_rc_uby   FOREIGN KEY (updated_by) REFERENCES users(id)
);

CREATE TABLE operating_conditions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  unit_id            INTEGER NOT NULL,
  title              TEXT NOT NULL,
  condition_type_id  INTEGER NULL,
  scope_description  TEXT NULL,
  allowed_vehicle_count INTEGER NULL,
  allows_passenger   INTEGER NOT NULL DEFAULT 0,
  allows_cargo       INTEGER NOT NULL DEFAULT 0,
  valid_from         TEXT NULL,
  valid_to           TEXT NULL,
  approval_id        INTEGER NULL,
  is_active          INTEGER NOT NULL DEFAULT 1,
  created_at         TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at         TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by         INTEGER NULL,
  updated_by         INTEGER NULL,
  CONSTRAINT fk_oc_unit FOREIGN KEY (unit_id) REFERENCES units(id),
  CONSTRAINT fk_oc_appr FOREIGN KEY (approval_id) REFERENCES approvals(id),
  CONSTRAINT fk_oc_cby  FOREIGN KEY (created_by) REFERENCES users(id),
  CONSTRAINT fk_oc_uby  FOREIGN KEY (updated_by) REFERENCES users(id)
);

CREATE TABLE transport_records (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  vehicle_id         INTEGER NOT NULL,
  unit_id            INTEGER NOT NULL,
  route_id           INTEGER NULL,
  record_date        TEXT NOT NULL,
  real_move_state_id INTEGER NULL,
  transport_kind     INTEGER NOT NULL DEFAULT 1,
  trips              INTEGER NOT NULL DEFAULT 0,
  distance_km        NUMERIC NOT NULL DEFAULT 0,
  passengers_carried INTEGER NOT NULL DEFAULT 0,
  cargo_weight       NUMERIC NOT NULL DEFAULT 0,
  cargo_volume       NUMERIC NOT NULL DEFAULT 0,
  revenue            NUMERIC NOT NULL DEFAULT 0,
  created_at         TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at         TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_tr_vehicle FOREIGN KEY (vehicle_id) REFERENCES vehicles(id),
  CONSTRAINT fk_tr_unit    FOREIGN KEY (unit_id) REFERENCES units(id),
  CONSTRAINT fk_tr_route   FOREIGN KEY (route_id) REFERENCES routes(id),
  CONSTRAINT fk_tr_rms     FOREIGN KEY (real_move_state_id) REFERENCES real_move_states(id)
);

CREATE TABLE transport_orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_no         TEXT NOT NULL,
  order_type_id    INTEGER NULL,
  unit_id          INTEGER NULL,
  origin_region_id INTEGER NULL,
  dest_region_id   INTEGER NULL,
  order_date       TEXT NULL,
  status_id        INTEGER NULL,
  amount           NUMERIC NULL,
  details          TEXT NULL,
  created_at       TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at       TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_to_type   FOREIGN KEY (order_type_id) REFERENCES order_types(id),
  CONSTRAINT fk_to_unit   FOREIGN KEY (unit_id) REFERENCES units(id),
  CONSTRAINT fk_to_origin FOREIGN KEY (origin_region_id) REFERENCES regions(id),
  CONSTRAINT fk_to_dest   FOREIGN KEY (dest_region_id) REFERENCES regions(id),
  CONSTRAINT fk_to_status FOREIGN KEY (status_id) REFERENCES order_statuses(id)
);

CREATE TABLE reports (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  report_type_id INTEGER NOT NULL,
  scope_type     INTEGER NOT NULL DEFAULT 1,
  scope_id       INTEGER NULL,
  report_date    TEXT NOT NULL,
  period         TEXT NULL,
  title          TEXT NULL,
  content        TEXT NULL,
  approval_id    INTEGER NULL,
  command        TEXT NULL,
  created_at     TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at     TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by     INTEGER NULL,
  updated_by     INTEGER NULL,
  CONSTRAINT fk_reports_type FOREIGN KEY (report_type_id) REFERENCES report_types(id),
  CONSTRAINT fk_reports_appr FOREIGN KEY (approval_id) REFERENCES approvals(id),
  CONSTRAINT fk_reports_cby  FOREIGN KEY (created_by) REFERENCES users(id),
  CONSTRAINT fk_reports_uby  FOREIGN KEY (updated_by) REFERENCES users(id)
);

CREATE TABLE schedules (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  schedule_type_id INTEGER NOT NULL,
  park_id          INTEGER NULL,
  unit_id          INTEGER NULL,
  vehicle_id       INTEGER NULL,
  route_id         INTEGER NULL,
  schedule_date    TEXT NULL,
  start_time       TEXT NULL,
  end_time         TEXT NULL,
  notes            TEXT NULL,
  created_at       TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at       TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by       INTEGER NULL,
  CONSTRAINT fk_sch_type    FOREIGN KEY (schedule_type_id) REFERENCES schedule_types(id),
  CONSTRAINT fk_sch_park    FOREIGN KEY (park_id) REFERENCES parks(id),
  CONSTRAINT fk_sch_unit    FOREIGN KEY (unit_id) REFERENCES units(id),
  CONSTRAINT fk_sch_vehicle FOREIGN KEY (vehicle_id) REFERENCES vehicles(id),
  CONSTRAINT fk_sch_route   FOREIGN KEY (route_id) REFERENCES routes(id),
  CONSTRAINT fk_sch_cby     FOREIGN KEY (created_by) REFERENCES users(id)
);

CREATE TABLE command_orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  target_unit_id       INTEGER NOT NULL,
  title                TEXT NOT NULL,
  short_title          TEXT NULL,
  body                 TEXT NULL,
  instruction_category TEXT NULL,
  order_number         TEXT NULL,
  order_classification TEXT NULL,
  order_date           TEXT NULL,
  status_id            INTEGER NULL,
  receipt_status       TEXT NOT NULL DEFAULT 'pending',
  received_at          TEXT NULL,
  received_by          INTEGER NULL,
  execution_status     TEXT NOT NULL DEFAULT 'none',
  execution_report     TEXT NULL,
  execution_reported_at TEXT NULL,
  execution_reported_by INTEGER NULL,
  created_at           TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at           TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by           INTEGER NULL,
  CONSTRAINT fk_co_unit   FOREIGN KEY (target_unit_id) REFERENCES units(id),
  CONSTRAINT fk_co_status FOREIGN KEY (status_id) REFERENCES order_statuses(id),
  CONSTRAINT fk_co_cby    FOREIGN KEY (created_by) REFERENCES users(id)
);

CREATE TABLE accident_notifications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  unit_id     INTEGER NOT NULL,
  vehicle_id  INTEGER NULL,
  occurred_at TEXT NOT NULL,
  location    TEXT NULL,
  severity_id INTEGER NULL,
  description TEXT NULL,
  status_id   INTEGER NULL,
  created_at  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by  INTEGER NULL,
  CONSTRAINT fk_acc_unit     FOREIGN KEY (unit_id) REFERENCES units(id),
  CONSTRAINT fk_acc_vehicle  FOREIGN KEY (vehicle_id) REFERENCES vehicles(id),
  CONSTRAINT fk_acc_severity FOREIGN KEY (severity_id) REFERENCES accident_severities(id),
  CONSTRAINT fk_acc_status   FOREIGN KEY (status_id) REFERENCES order_statuses(id),
  CONSTRAINT fk_acc_cby      FOREIGN KEY (created_by) REFERENCES users(id)
);

CREATE TABLE role_permissions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  role_id    INTEGER NOT NULL,
  section_id INTEGER NOT NULL,
  action_id  INTEGER NOT NULL,
  CONSTRAINT fk_rp_role    FOREIGN KEY (role_id) REFERENCES roles(id),
  CONSTRAINT fk_rp_section FOREIGN KEY (section_id) REFERENCES system_sections(id),
  CONSTRAINT fk_rp_action  FOREIGN KEY (action_id) REFERENCES actions(id)
);

CREATE TABLE user_roles (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  role_id INTEGER NOT NULL,
  CONSTRAINT fk_ur_user FOREIGN KEY (user_id) REFERENCES users(id),
  CONSTRAINT fk_ur_role FOREIGN KEY (role_id) REFERENCES roles(id)
);

CREATE TABLE user_data_scopes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id    INTEGER NOT NULL,
  scope_type INTEGER NOT NULL,
  scope_id   INTEGER NOT NULL,
  CONSTRAINT fk_uds_user FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE section_managers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id    INTEGER NOT NULL,
  section_id INTEGER NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by INTEGER NULL,
  CONSTRAINT fk_sm_user    FOREIGN KEY (user_id) REFERENCES users(id),
  CONSTRAINT fk_sm_section FOREIGN KEY (section_id) REFERENCES system_sections(id),
  CONSTRAINT fk_sm_cby     FOREIGN KEY (created_by) REFERENCES users(id)
);

CREATE TABLE audit_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id     INTEGER NULL,
  action      TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_id   INTEGER NULL,
  before_json TEXT NULL,
  after_json  TEXT NULL,
  at          TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  ip_or_host  TEXT NULL,
  CONSTRAINT fk_audit_user FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE licenses (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  unit_id         INTEGER NOT NULL,
  license_no      TEXT NULL,
  license_type_id INTEGER NULL,
  valid_from      TEXT NULL,
  valid_to        TEXT NULL,
  approval_id     INTEGER NULL,
  is_active       INTEGER NOT NULL DEFAULT 1,
  created_at      TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at      TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by      INTEGER NULL,
  CONSTRAINT fk_lic_unit FOREIGN KEY (unit_id) REFERENCES units(id),
  CONSTRAINT fk_lic_type FOREIGN KEY (license_type_id) REFERENCES license_types(id),
  CONSTRAINT fk_lic_appr FOREIGN KEY (approval_id) REFERENCES approvals(id),
  CONSTRAINT fk_lic_cby  FOREIGN KEY (created_by) REFERENCES users(id)
);

CREATE TABLE invoices (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  invoice_no TEXT NOT NULL,
  unit_id    INTEGER NULL,
  order_id   INTEGER NULL,
  amount     NUMERIC NOT NULL DEFAULT 0,
  issued_at  TEXT NULL,
  status_id  INTEGER NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_inv_unit   FOREIGN KEY (unit_id) REFERENCES units(id),
  CONSTRAINT fk_inv_order  FOREIGN KEY (order_id) REFERENCES transport_orders(id),
  CONSTRAINT fk_inv_status FOREIGN KEY (status_id) REFERENCES order_statuses(id)
);

CREATE TABLE finance_records (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  unit_id     INTEGER NOT NULL,
  record_date TEXT NOT NULL,
  category_id INTEGER NULL,
  direction   INTEGER NOT NULL DEFAULT 1,
  amount      NUMERIC NOT NULL DEFAULT 0,
  note        TEXT NULL,
  created_at  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by  INTEGER NULL,
  CONSTRAINT fk_fin_unit FOREIGN KEY (unit_id) REFERENCES units(id),
  CONSTRAINT fk_fin_cat  FOREIGN KEY (category_id) REFERENCES finance_categories(id),
  CONSTRAINT fk_fin_cby  FOREIGN KEY (created_by) REFERENCES users(id)
);

CREATE TABLE transport_indicators (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name            TEXT NOT NULL,
  code            TEXT NULL,
  unit_of_measure TEXT NULL,
  description     TEXT NULL,
  is_active       INTEGER NOT NULL DEFAULT 1,
  created_at      TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at      TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE indicator_values (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  indicator_id INTEGER NOT NULL,
  unit_id      INTEGER NULL,
  region_id    INTEGER NULL,
  period       TEXT NULL,
  value        NUMERIC NOT NULL DEFAULT 0,
  created_at   TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_iv_indicator FOREIGN KEY (indicator_id) REFERENCES transport_indicators(id),
  CONSTRAINT fk_iv_unit      FOREIGN KEY (unit_id) REFERENCES units(id),
  CONSTRAINT fk_iv_region    FOREIGN KEY (region_id) REFERENCES regions(id)
);

CREATE TABLE notices (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title        TEXT NOT NULL,
  body         TEXT NULL,
  published_at TEXT NULL,
  is_published INTEGER NOT NULL DEFAULT 0,
  author_id    INTEGER NULL,
  created_at   TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at   TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_notices_author FOREIGN KEY (author_id) REFERENCES users(id)
);

CREATE TABLE faqs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  question   TEXT NOT NULL,
  answer     TEXT NULL,
  sort_order INTEGER NOT NULL DEFAULT 0,
  is_active  INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE programs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name        TEXT NOT NULL,
  version     TEXT NULL,
  file_path   TEXT NULL,
  description TEXT NULL,
  is_active   INTEGER NOT NULL DEFAULT 1,
  created_at  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE tech_data_submissions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title        TEXT NOT NULL,
  unit_id      INTEGER NULL,
  submitted_by INTEGER NULL,
  submitted_at TEXT NULL,
  file_path    TEXT NULL,
  status_id    INTEGER NULL,
  approval_id  INTEGER NULL,
  command      TEXT NULL,
  created_at   TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_tds_unit   FOREIGN KEY (unit_id) REFERENCES units(id),
  CONSTRAINT fk_tds_by     FOREIGN KEY (submitted_by) REFERENCES users(id),
  CONSTRAINT fk_tds_appr   FOREIGN KEY (approval_id) REFERENCES approvals(id),
  CONSTRAINT fk_tds_status FOREIGN KEY (status_id) REFERENCES order_statuses(id)
);

CREATE TABLE feedback (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  subject      TEXT NULL,
  body         TEXT NOT NULL,
  submitted_by INTEGER NULL,
  submitted_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  is_read      INTEGER NOT NULL DEFAULT 0,
  CONSTRAINT fk_fb_by FOREIGN KEY (submitted_by) REFERENCES users(id)
);

CREATE TABLE stat_transport_daily (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  stat_date          TEXT NOT NULL,
  unit_id            INTEGER NULL,
  route_id           INTEGER NULL,
  region_id          INTEGER NULL,
  vehicle_type_id    INTEGER NULL,
  trips              INTEGER NOT NULL DEFAULT 0,
  distance_km        NUMERIC NOT NULL DEFAULT 0,
  passengers_carried INTEGER NOT NULL DEFAULT 0,
  cargo_weight       NUMERIC NOT NULL DEFAULT 0,
  cargo_volume       NUMERIC NOT NULL DEFAULT 0,
  revenue            NUMERIC NOT NULL DEFAULT 0
);

CREATE TABLE stat_transport_monthly (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  stat_year          INTEGER NOT NULL,
  stat_month         INTEGER NOT NULL,
  unit_id            INTEGER NULL,
  route_id           INTEGER NULL,
  region_id          INTEGER NULL,
  vehicle_type_id    INTEGER NULL,
  trips              INTEGER NOT NULL DEFAULT 0,
  distance_km        NUMERIC NOT NULL DEFAULT 0,
  passengers_carried INTEGER NOT NULL DEFAULT 0,
  cargo_weight       NUMERIC NOT NULL DEFAULT 0,
  cargo_volume       NUMERIC NOT NULL DEFAULT 0,
  revenue            NUMERIC NOT NULL DEFAULT 0
);

CREATE TABLE stat_transport_quarterly (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  stat_year          INTEGER NOT NULL,
  stat_quarter       INTEGER NOT NULL,
  unit_id            INTEGER NULL,
  route_id           INTEGER NULL,
  region_id          INTEGER NULL,
  vehicle_type_id    INTEGER NULL,
  trips              INTEGER NOT NULL DEFAULT 0,
  distance_km        NUMERIC NOT NULL DEFAULT 0,
  passengers_carried INTEGER NOT NULL DEFAULT 0,
  cargo_weight       NUMERIC NOT NULL DEFAULT 0,
  cargo_volume       NUMERIC NOT NULL DEFAULT 0,
  revenue            NUMERIC NOT NULL DEFAULT 0
);

CREATE TABLE notifications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id     INTEGER NOT NULL,
  type        TEXT NOT NULL,
  title       TEXT NOT NULL,
  body        TEXT NULL,
  link        TEXT NULL,
  is_read     INTEGER NOT NULL DEFAULT 0,
  created_at  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_notif_user FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE account_requests (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username        TEXT  NOT NULL,
  full_name       TEXT NOT NULL,
  password_hash   TEXT NOT NULL,
  unit_id         INTEGER NULL,
  position        TEXT NULL,
  mobile_phone    TEXT  NULL,
  office_phone    TEXT  NULL,
  certificate_id  TEXT NULL,
  note            TEXT NULL,
  status          TEXT  NOT NULL DEFAULT 'pending',
  requested_at    TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  decided_by      INTEGER NULL,
  decided_at      TEXT NULL,
  created_user_id INTEGER NULL,
  CONSTRAINT fk_areq_decided FOREIGN KEY (decided_by) REFERENCES users(id),
  CONSTRAINT fk_areq_user FOREIGN KEY (created_user_id) REFERENCES users(id)
);

CREATE TABLE business_daily_reports (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  department    TEXT  NOT NULL,
  unit_id       INTEGER NULL,
  report_date   TEXT NOT NULL,
  title         TEXT NOT NULL,
  content       TEXT NULL,
  status_id     INTEGER NULL,
  approval_id   INTEGER NULL,
  command       TEXT NULL,
  is_active     INTEGER NOT NULL DEFAULT 1,
  created_at    TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at    TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by    INTEGER NULL,
  updated_by    INTEGER NULL,
  CONSTRAINT fk_bdr_unit   FOREIGN KEY (unit_id) REFERENCES units(id),
  CONSTRAINT fk_bdr_status FOREIGN KEY (status_id) REFERENCES order_statuses(id),
  CONSTRAINT fk_bdr_appr   FOREIGN KEY (approval_id) REFERENCES approvals(id),
  CONSTRAINT fk_bdr_cby    FOREIGN KEY (created_by) REFERENCES users(id),
  CONSTRAINT fk_bdr_uby    FOREIGN KEY (updated_by) REFERENCES users(id)
);

CREATE TABLE equipment (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  unit_id       INTEGER NULL,
  name          TEXT NOT NULL,
  code          TEXT  NULL,
  category      TEXT NULL,
  serial_no     TEXT NULL,
  status        TEXT  NULL,
  registered_on TEXT NULL,
  is_active     INTEGER NOT NULL DEFAULT 1,
  created_at    TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at    TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by    INTEGER NULL,
  updated_by    INTEGER NULL,
  CONSTRAINT fk_equip_unit FOREIGN KEY (unit_id) REFERENCES units(id),
  CONSTRAINT fk_equip_cby  FOREIGN KEY (created_by) REFERENCES users(id),
  CONSTRAINT fk_equip_uby  FOREIGN KEY (updated_by) REFERENCES users(id)
);

CREATE TABLE equipment_inspections (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  equipment_id    INTEGER NULL,
  unit_id         INTEGER NULL,
  inspection_date TEXT NOT NULL,
  inspection_type TEXT NULL,
  result          TEXT NULL,
  inspector       TEXT NULL,
  notes           TEXT NULL,
  is_active       INTEGER NOT NULL DEFAULT 1,
  created_at      TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at      TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by      INTEGER NULL,
  updated_by      INTEGER NULL,
  CONSTRAINT fk_einsp_equip FOREIGN KEY (equipment_id) REFERENCES equipment(id),
  CONSTRAINT fk_einsp_unit  FOREIGN KEY (unit_id) REFERENCES units(id),
  CONSTRAINT fk_einsp_cby   FOREIGN KEY (created_by) REFERENCES users(id),
  CONSTRAINT fk_einsp_uby   FOREIGN KEY (updated_by) REFERENCES users(id)
);

CREATE TABLE monthly_reports (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  unit_id     INTEGER NULL,
  stat_year   INTEGER NOT NULL,
  stat_month  INTEGER NOT NULL,
  title       TEXT NOT NULL,
  content     TEXT NULL,
  status_id   INTEGER NULL,
  approval_id INTEGER NULL,
  command     TEXT NULL,
  is_active   INTEGER NOT NULL DEFAULT 1,
  created_at  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by  INTEGER NULL,
  updated_by  INTEGER NULL,
  CONSTRAINT fk_mr_unit   FOREIGN KEY (unit_id) REFERENCES units(id),
  CONSTRAINT fk_mr_appr   FOREIGN KEY (approval_id) REFERENCES approvals(id),
  CONSTRAINT fk_mr_status FOREIGN KEY (status_id) REFERENCES order_statuses(id),
  CONSTRAINT fk_mr_cby    FOREIGN KEY (created_by) REFERENCES users(id),
  CONSTRAINT fk_mr_uby    FOREIGN KEY (updated_by) REFERENCES users(id)
);

CREATE TABLE effort_plans (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  unit_id     INTEGER NULL,
  period      TEXT NULL,
  title       TEXT NOT NULL,
  target_value NUMERIC NULL,
  actual_value NUMERIC NULL,
  notes       TEXT NULL,
  status_id   INTEGER NULL,
  approval_id INTEGER NULL,
  command     TEXT NULL,
  is_active   INTEGER NOT NULL DEFAULT 1,
  created_at  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by  INTEGER NULL,
  updated_by  INTEGER NULL,
  CONSTRAINT fk_ep_unit   FOREIGN KEY (unit_id) REFERENCES units(id),
  CONSTRAINT fk_ep_appr   FOREIGN KEY (approval_id) REFERENCES approvals(id),
  CONSTRAINT fk_ep_status FOREIGN KEY (status_id) REFERENCES order_statuses(id),
  CONSTRAINT fk_ep_cby    FOREIGN KEY (created_by) REFERENCES users(id),
  CONSTRAINT fk_ep_uby    FOREIGN KEY (updated_by) REFERENCES users(id)
);

CREATE TABLE electricity_reports (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  unit_id         INTEGER NULL,
  report_date     TEXT NOT NULL,
  consumption_kwh NUMERIC NULL,
  peak_kwh        NUMERIC NULL,
  notes           TEXT NULL,
  is_active       INTEGER NOT NULL DEFAULT 1,
  created_at      TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at      TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by      INTEGER NULL,
  updated_by      INTEGER NULL,
  CONSTRAINT fk_elec_unit FOREIGN KEY (unit_id) REFERENCES units(id),
  CONSTRAINT fk_elec_cby  FOREIGN KEY (created_by) REFERENCES users(id),
  CONSTRAINT fk_elec_uby  FOREIGN KEY (updated_by) REFERENCES users(id)
);

CREATE TABLE no_accident_records (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  unit_id            INTEGER NULL,
  as_of_date         TEXT NOT NULL,
  accident_free_days INTEGER NOT NULL DEFAULT 0,
  notes              TEXT NULL,
  is_active          INTEGER NOT NULL DEFAULT 1,
  created_at         TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at         TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by         INTEGER NULL,
  updated_by         INTEGER NULL,
  CONSTRAINT fk_noacc_unit FOREIGN KEY (unit_id) REFERENCES units(id),
  CONSTRAINT fk_noacc_cby  FOREIGN KEY (created_by) REFERENCES users(id),
  CONSTRAINT fk_noacc_uby  FOREIGN KEY (updated_by) REFERENCES users(id)
);

CREATE TABLE weekly_schedules (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  unit_id     INTEGER NULL,
  week_start  TEXT NOT NULL,
  title       TEXT NOT NULL,
  content     TEXT NULL,
  is_active   INTEGER NOT NULL DEFAULT 1,
  created_at  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by  INTEGER NULL,
  updated_by  INTEGER NULL,
  CONSTRAINT fk_wsch_unit FOREIGN KEY (unit_id) REFERENCES units(id),
  CONSTRAINT fk_wsch_cby  FOREIGN KEY (created_by) REFERENCES users(id),
  CONSTRAINT fk_wsch_uby  FOREIGN KEY (updated_by) REFERENCES users(id)
);

CREATE TABLE guard_duties (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  unit_id     INTEGER NULL,
  duty_date   TEXT NOT NULL,
  shift       TEXT NULL,
  post        TEXT NULL,
  guard_name  TEXT NULL,
  notes       TEXT NULL,
  is_active   INTEGER NOT NULL DEFAULT 1,
  created_at  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by  INTEGER NULL,
  updated_by  INTEGER NULL,
  CONSTRAINT fk_guard_unit FOREIGN KEY (unit_id) REFERENCES units(id),
  CONSTRAINT fk_guard_cby  FOREIGN KEY (created_by) REFERENCES users(id),
  CONSTRAINT fk_guard_uby  FOREIGN KEY (updated_by) REFERENCES users(id)
);

CREATE TABLE file_transfers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  sender_unit_id INTEGER NULL,
  title          TEXT NOT NULL,
  report_title   TEXT NULL,
  file_name      TEXT NOT NULL,
  file_size      INTEGER NULL,
  file_path      TEXT NULL,
  content_type   TEXT NULL,
  blob_id        INTEGER NULL,
  sent_at        TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  is_active      INTEGER NOT NULL DEFAULT 1,
  created_at     TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at     TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by     INTEGER NULL,
  updated_by     INTEGER NULL,
  CONSTRAINT fk_ft_sender FOREIGN KEY (sender_unit_id) REFERENCES units(id),
  CONSTRAINT fk_ft_cby    FOREIGN KEY (created_by) REFERENCES users(id),
  CONSTRAINT fk_ft_uby    FOREIGN KEY (updated_by) REFERENCES users(id)
);

CREATE TABLE file_transfer_recipients (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  file_id     INTEGER NOT NULL,
  unit_id     INTEGER NOT NULL,
  received_at TEXT NULL,
  CONSTRAINT fk_ftr_file FOREIGN KEY (file_id) REFERENCES file_transfers(id),
  CONSTRAINT fk_ftr_unit FOREIGN KEY (unit_id) REFERENCES units(id)
);

CREATE TABLE staff_org (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  unit_id     INTEGER NULL,
  org_type    INTEGER NOT NULL DEFAULT 1,
  name        TEXT NOT NULL,
  code        TEXT  NULL,
  is_active   INTEGER NOT NULL DEFAULT 1,
  created_at  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by  INTEGER NULL,
  updated_by  INTEGER NULL,
  CONSTRAINT fk_so_unit FOREIGN KEY (unit_id) REFERENCES units(id)
);

CREATE TABLE attendance_records (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  unit_id     INTEGER NULL,
  staff_id    INTEGER NOT NULL,
  attend_date TEXT NOT NULL,
  status      TEXT NOT NULL DEFAULT 'present',
  note        TEXT NULL,
  created_at  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by  INTEGER NULL,
  updated_by  INTEGER NULL,
  CONSTRAINT fk_att_staff FOREIGN KEY (staff_id) REFERENCES staff(id),
  CONSTRAINT fk_att_unit  FOREIGN KEY (unit_id) REFERENCES units(id)
);

CREATE TABLE transport_plans (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  unit_id            INTEGER NULL,
  vehicle_id         INTEGER NOT NULL,
  plan_date          TEXT NOT NULL,
  route_id           INTEGER NULL,
  vehicle_status     TEXT NULL,
  operational_status TEXT NULL,
  departure_point    TEXT NULL,
  arrival_point      TEXT NULL,
  distance_km        NUMERIC NULL,
  out_passengers     INTEGER NULL,
  out_tons           NUMERIC NULL,
  in_passengers      INTEGER NULL,
  in_tons            NUMERIC NULL,
  trips              INTEGER NULL,
  transport_category TEXT NULL,
  remarks            TEXT NULL,
  status             TEXT NOT NULL DEFAULT 'draft',
  is_active          INTEGER NOT NULL DEFAULT 1,
  created_at         TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at         TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by         INTEGER NULL,
  updated_by         INTEGER NULL,
  CONSTRAINT fk_tp_vehicle FOREIGN KEY (vehicle_id) REFERENCES vehicles(id),
  CONSTRAINT fk_tp_unit    FOREIGN KEY (unit_id) REFERENCES units(id),
  CONSTRAINT fk_tp_route   FOREIGN KEY (route_id) REFERENCES routes(id)
);

CREATE TABLE price_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  category        TEXT NOT NULL,
  name            TEXT NOT NULL,
  amount          NUMERIC NOT NULL DEFAULT 0,
  unit_of_measure TEXT NULL,
  description     TEXT NULL,
  is_active       INTEGER NOT NULL DEFAULT 1,
  created_at      TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at      TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by      INTEGER NULL,
  updated_by      INTEGER NULL
);

CREATE TABLE payments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  unit_id      INTEGER NULL,
  payment_date TEXT NOT NULL,
  category     TEXT NULL,
  description  TEXT NULL,
  amount       NUMERIC NOT NULL DEFAULT 0,
  reference_no TEXT NULL,
  status       TEXT NOT NULL DEFAULT 'paid',
  is_active    INTEGER NOT NULL DEFAULT 1,
  created_at   TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at   TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by   INTEGER NULL,
  updated_by   INTEGER NULL,
  CONSTRAINT fk_pay_unit FOREIGN KEY (unit_id) REFERENCES units(id)
);

CREATE TABLE parking_reservations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  unit_id       INTEGER NULL,
  park_id       INTEGER NULL,
  reserver_name TEXT NULL,
  contact       TEXT  NULL,
  vehicle_plate TEXT  NULL,
  slot_no       TEXT  NULL,
  reserved_from TEXT NULL,
  reserved_to   TEXT NULL,
  status        TEXT NOT NULL DEFAULT 'reserved',
  notes         TEXT NULL,
  is_active     INTEGER NOT NULL DEFAULT 1,
  created_at    TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at    TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by    INTEGER NULL,
  updated_by    INTEGER NULL,
  CONSTRAINT fk_resv_unit FOREIGN KEY (unit_id) REFERENCES units(id),
  CONSTRAINT fk_resv_park FOREIGN KEY (park_id) REFERENCES parks(id)
);

CREATE TABLE place_names (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name        TEXT NOT NULL,
  code        TEXT  NULL,
  category    TEXT  NULL,
  latitude    NUMERIC NULL,
  longitude   NUMERIC NULL,
  description TEXT NULL,
  is_active   INTEGER NOT NULL DEFAULT 1,
  created_at  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by  INTEGER NULL,
  updated_by  INTEGER NULL
);

CREATE TABLE command_order_attachments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  command_order_id INTEGER NOT NULL,
  file_name        TEXT NOT NULL,
  file_path        TEXT NULL,
  blob_id          INTEGER NULL,
  file_size        INTEGER NULL,
  content_type     TEXT NULL,
  uploaded_at      TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  uploaded_by      INTEGER NULL,
  CONSTRAINT fk_coa_order FOREIGN KEY (command_order_id) REFERENCES command_orders(id),
  CONSTRAINT fk_coa_blob FOREIGN KEY (blob_id) REFERENCES file_blobs(id)
);

CREATE TABLE file_blobs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  sha256       CHAR(64) NULL,
  byte_size    INTEGER NOT NULL,
  content_type TEXT NULL,
  content      LONGBLOB NOT NULL,
  created_at   TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by   INTEGER NULL
);

CREATE UNIQUE INDEX uq_users_username ON users (username);
CREATE UNIQUE INDEX uq_roles_code ON roles (code);
CREATE UNIQUE INDEX uq_actions_code ON actions (code);
CREATE UNIQUE INDEX uq_sections_code ON system_sections (code);
CREATE INDEX idx_sections_parent ON system_sections (parent_id);
CREATE INDEX idx_regions_parent ON regions (parent_id);
CREATE INDEX idx_units_parent ON units (parent_id);
CREATE INDEX idx_units_region ON units (region_id);
CREATE UNIQUE INDEX uq_online_unit ON unit_online_status (unit_id);
CREATE INDEX idx_parks_unit ON parks (unit_id);
CREATE INDEX idx_wh_unit ON warehouses (unit_id);
CREATE INDEX idx_staff_unit ON staff (unit_id);
CREATE INDEX idx_veh_unit ON vehicles (unit_id);
CREATE INDEX idx_veh_park ON vehicles (park_id);
CREATE INDEX idx_veh_type ON vehicles (vehicle_type_id);
CREATE INDEX idx_gps_vehicle ON gps_devices (vehicle_id);
CREATE INDEX idx_vloc_vehicle_time ON vehicle_locations (vehicle_id, recorded_at);
CREATE INDEX idx_routes_unit ON routes (unit_id);
CREATE INDEX idx_appr_entity ON approvals (entity_type, entity_id);
CREATE INDEX idx_apprh_approval ON approval_history (approval_id);
CREATE INDEX idx_rc_route ON route_certificates (route_id);
CREATE INDEX idx_rc_unit ON route_certificates (unit_id);
CREATE INDEX idx_oc_unit ON operating_conditions (unit_id);
CREATE UNIQUE INDEX uq_tr_vehicle_date ON transport_records (vehicle_id, record_date);
CREATE INDEX idx_tr_date ON transport_records (record_date);
CREATE INDEX idx_tr_unit_date ON transport_records (unit_id, record_date);
CREATE INDEX idx_tr_route_date ON transport_records (route_id, record_date);
CREATE INDEX idx_to_type ON transport_orders (order_type_id);
CREATE INDEX idx_to_status ON transport_orders (status_id);
CREATE INDEX idx_to_origin ON transport_orders (origin_region_id);
CREATE INDEX idx_reports_type_date ON reports (report_type_id, report_date);
CREATE INDEX idx_reports_scope ON reports (scope_type, scope_id);
CREATE INDEX idx_sch_type ON schedules (schedule_type_id);
CREATE INDEX idx_sch_park_date ON schedules (park_id, schedule_date);
CREATE INDEX idx_co_unit ON command_orders (target_unit_id);
CREATE INDEX idx_acc_unit ON accident_notifications (unit_id);
CREATE UNIQUE INDEX uq_rp ON role_permissions (role_id, section_id, action_id);
CREATE UNIQUE INDEX uq_ur ON user_roles (user_id, role_id);
CREATE UNIQUE INDEX uq_uds ON user_data_scopes (user_id, scope_type, scope_id);
CREATE INDEX idx_uds_user ON user_data_scopes (user_id);
CREATE UNIQUE INDEX uq_sm ON section_managers (user_id, section_id);
CREATE INDEX idx_audit_entity ON audit_log (entity_type, entity_id);
CREATE INDEX idx_audit_user_time ON audit_log (user_id, at);
CREATE INDEX idx_lic_unit ON licenses (unit_id);
CREATE INDEX idx_inv_unit ON invoices (unit_id);
CREATE INDEX idx_fin_unit_date ON finance_records (unit_id, record_date);
CREATE INDEX idx_iv_indicator ON indicator_values (indicator_id);
CREATE INDEX idx_std_date ON stat_transport_daily (stat_date);
CREATE INDEX idx_std_unit ON stat_transport_daily (unit_id, stat_date);
CREATE INDEX idx_stm_period ON stat_transport_monthly (stat_year, stat_month);
CREATE INDEX idx_stm_unit ON stat_transport_monthly (unit_id, stat_year, stat_month);
CREATE INDEX idx_stq_period ON stat_transport_quarterly (stat_year, stat_quarter);
CREATE INDEX idx_stq_unit ON stat_transport_quarterly (unit_id, stat_year, stat_quarter);
CREATE INDEX idx_notif_user ON notifications (user_id, is_read, created_at);
CREATE INDEX idx_areq_status ON account_requests (status, requested_at);
CREATE INDEX idx_bdr_dept ON business_daily_reports (department, report_date);
CREATE INDEX idx_bdr_unit ON business_daily_reports (unit_id);
CREATE INDEX idx_equip_unit ON equipment (unit_id);
CREATE INDEX idx_einsp_unit ON equipment_inspections (unit_id);
CREATE INDEX idx_einsp_equip ON equipment_inspections (equipment_id);
CREATE INDEX idx_mr_unit ON monthly_reports (unit_id, stat_year, stat_month);
CREATE INDEX idx_ep_unit ON effort_plans (unit_id);
CREATE INDEX idx_elec_unit ON electricity_reports (unit_id, report_date);
CREATE INDEX idx_noacc_unit ON no_accident_records (unit_id);
CREATE INDEX idx_wsch_unit ON weekly_schedules (unit_id, week_start);
CREATE INDEX idx_guard_unit ON guard_duties (unit_id, duty_date);
CREATE INDEX idx_ft_sender ON file_transfers (sender_unit_id, sent_at);
CREATE INDEX idx_ftr_file ON file_transfer_recipients (file_id);
CREATE INDEX idx_ftr_unit ON file_transfer_recipients (unit_id);
CREATE INDEX idx_so_unit ON staff_org (unit_id, org_type);
CREATE UNIQUE INDEX uq_att ON attendance_records (staff_id, attend_date);
CREATE INDEX idx_att_unit ON attendance_records (unit_id, attend_date);
CREATE UNIQUE INDEX uq_plan ON transport_plans (vehicle_id, plan_date);
CREATE INDEX idx_plan_unit ON transport_plans (unit_id, plan_date);
CREATE INDEX idx_price_cat ON price_items (category);
CREATE INDEX idx_pay_unit ON payments (unit_id, payment_date);
CREATE INDEX idx_resv ON parking_reservations (unit_id, park_id, reserved_from);
CREATE INDEX idx_place_cat ON place_names (category);
CREATE INDEX idx_coa_order ON command_order_attachments (command_order_id);
CREATE INDEX idx_blob_sha ON file_blobs (sha256);
