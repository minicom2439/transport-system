// src/middleware/audit.middleware.js
// Records a write action to the audit log AFTER the response is sent, so it
// never slows the request or breaks it if logging fails.
const auditRepo = require('../repositories/audit.repository');

function audit(action, entityType) {
  return (req, res, next) => {
    res.on('finish', () => {
      // Only log successful writes.
      if (res.statusCode >= 200 && res.statusCode < 300) {
        auditRepo.write({
          userId: req.session && req.session.user ? req.session.user.id : null,
          action,
          entityType,
          entityId: req.params.id ? Number(req.params.id) : (res.locals.createdId || null),
          after: req.body && Object.keys(req.body).length ? req.body : null,
          host: req.ip,
        }).catch(() => { /* never throw from audit */ });
      }
    });
    next();
  };
}

module.exports = { audit };
