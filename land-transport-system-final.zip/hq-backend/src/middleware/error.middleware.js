// src/middleware/error.middleware.js

function notFound(req, res) {
  res.status(404).json({ error: 'Not found' });
}

// Database constraint violations are caused by bad client input, not server
// faults, so they map to 400 — without leaking the underlying SQL/table names.
const CONSTRAINT_CODES = new Set([
  // SQLite
  'SQLITE_CONSTRAINT', 'SQLITE_CONSTRAINT_FOREIGNKEY', 'SQLITE_CONSTRAINT_UNIQUE',
  'SQLITE_CONSTRAINT_NOTNULL', 'SQLITE_CONSTRAINT_PRIMARYKEY', 'SQLITE_CONSTRAINT_CHECK',
  // MySQL
  'ER_NO_REFERENCED_ROW', 'ER_NO_REFERENCED_ROW_2', 'ER_ROW_IS_REFERENCED',
  'ER_ROW_IS_REFERENCED_2', 'ER_DUP_ENTRY', 'ER_BAD_NULL_ERROR',
]);

function isConstraint(err) {
  return CONSTRAINT_CODES.has(err.code)
    || (typeof err.message === 'string' && /constraint failed/i.test(err.message));
}

// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  if (err.name === 'ForbiddenError') {
    return res.status(403).json({ error: err.message });
  }
  if (err.name === 'ValidationError') {
    return res.status(400).json({ error: err.message, fields: err.fields || {} });
  }
  if (isConstraint(err)) {
    // Logged at low severity; this is expected on bad input.
    console.warn('Constraint violation:', err.code || err.message);
    return res.status(400).json({ error: 'Invalid reference or duplicate value' });
  }
  console.error(err);
  return res.status(err.status || 500).json({
    error: err.publicMessage || 'Internal server error',
  });
}

module.exports = { notFound, errorHandler };
