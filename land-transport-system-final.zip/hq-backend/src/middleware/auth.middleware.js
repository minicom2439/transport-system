// src/middleware/auth.middleware.js
// Gate that requires a logged-in session.
function requireLogin(req, res, next) {
  if (req.session && req.session.user) return next();
  return res.status(401).json({ error: 'Authentication required' });
}

module.exports = { requireLogin };
