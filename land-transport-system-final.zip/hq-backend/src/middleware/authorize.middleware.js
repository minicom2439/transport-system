// src/middleware/authorize.middleware.js
// Permission gate: requirePermission(sectionCode, actionCode).
// Reads the access object cached on the session (no DB hit per request).
const { can } = require('../services/permission.service');

function requirePermission(sectionCode, actionCode) {
  return (req, res, next) => {
    const user = req.session && req.session.user;
    if (!user) return res.status(401).json({ error: 'Authentication required' });
    const access = {
      isSuperAdmin: user.access.isSuperAdmin,
      permissions: new Set(user.access.permissions),
    };
    if (can(access, sectionCode, actionCode)) return next();
    return res.status(403).json({
      error: 'Forbidden',
      needed: `${sectionCode}:${actionCode}`,
    });
  };
}

module.exports = { requirePermission };
