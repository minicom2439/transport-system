module.exports = require('./_crud.factory')(require('../services/faq.service'), 'info_faqs', 'faqs');
