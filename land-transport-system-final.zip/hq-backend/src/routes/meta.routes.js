// src/routes/meta.routes.js
const express = require('express');
const metaService = require('../services/meta.service');
const { requireLogin } = require('../middleware/auth.middleware');

const router = express.Router();

// Reference geography for trees/filters/dropdowns.
router.get('/regions', requireLogin, async (req, res, next) => {
  try { res.json({ data: await metaService.regionsTree() }); } catch (e) { next(e); }
});

// Sidebar navigation, filtered to what the current user may view.
router.get('/nav', requireLogin, async (req, res, next) => {
  try { res.json({ data: await metaService.navForUser(req.session.user) }); } catch (e) { next(e); }
});


router.get('/sections-all', requireLogin, async (req, res, next) => {
  try { res.json({ data: await metaService.allSectionsTree() }); } catch (e) { next(e); }
});
router.get('/actions', requireLogin, async (req, res, next) => {
  try { res.json({ data: await metaService.allActions() }); } catch (e) { next(e); }
});
router.get('/units', requireLogin, async (req, res, next) => {
  try { res.json({ data: await metaService.unitOptions() }); } catch (e) { next(e); }
});


router.get('/my-admin-domain', requireLogin, async (req, res, next) => {
  try { res.json({ data: await metaService.myAdminDomain(req.session.user) }); } catch (e) { next(e); }
});


router.get('/lookup/:name', requireLogin, async (req, res, next) => {
  try { res.json({ data: await metaService.lookup(req.params.name) }); } catch (e) { next(e); }
});

module.exports = router;
