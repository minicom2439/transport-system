// A read-only dashboard of business_daily_reports for one department, gated on
// its own nav section. The authoritative submit/review/command workflow lives
// on the Comprehensive "Business Daily Reports" screen (spans all departments).
const express = require('express');
const repo = require('../repositories/business-daily.repository');
const { parseListParams } = require('../repositories/list-query');
const { dataScopeClause } = require('../services/permission.service');
const { requireLogin } = require('../middleware/auth.middleware');
const { requirePermission } = require('../middleware/authorize.middleware');
module.exports = (section, department) => {
  const router = express.Router();
  router.get('/', requireLogin, requirePermission(section, 'view'), async (req, res, next) => {
    try {
      const params = parseListParams({ ...req.query, filters: JSON.stringify([{ field: 'department', op: 'eq', value: department }, ...(req.query.filters ? JSON.parse(req.query.filters) : [])]) });
      const a = req.session.user.access;
      const scope = dataScopeClause({ isSuperAdmin: a.isSuperAdmin, dataScopes: a.dataScopes }, { unitColumn: 'business_daily_reports.unit_id' });
      const { data, total } = await repo.search(params, scope);
      res.json({ data, total, page: params.page, limit: params.limit, sort: params.sort, dir: params.dir });
    } catch (e) { next(e); }
  });
  return router;
};
