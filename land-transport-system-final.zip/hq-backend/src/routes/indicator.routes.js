module.exports = require('./_crud.factory')(require('../services/indicator.service'), 'land_ops_indicators', 'transport_indicators');
