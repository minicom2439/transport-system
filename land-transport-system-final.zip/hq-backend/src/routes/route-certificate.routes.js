module.exports = require('./_workflow.factory')(require('../services/route-certificate.service'), 'land_ops_route_certs', 'route_certificates');
