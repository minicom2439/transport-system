module.exports = require('./_crud.factory')(require('../services/schedule.service'), 'land_ops_schedules', 'schedules');
