module.exports = require('./_crud.factory')(require('../services/electricity-report.service'), 'pp_electricity', 'electricity_reports');
