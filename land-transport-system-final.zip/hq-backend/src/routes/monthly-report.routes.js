module.exports = require('./_workflow.factory')(require('../services/monthly-report.service'), 'pp_monthly', 'monthly_reports');
