module.exports = require('./_workflow.factory')(require('../services/report.service'), 'land_ops_reports', 'reports');
