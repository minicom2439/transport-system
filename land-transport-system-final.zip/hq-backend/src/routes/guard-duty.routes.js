module.exports = require('./_crud.factory')(require('../services/guard-duty.service'), 'cmp_defense', 'guard_duties');
