module.exports = require('./_crud.factory')(require('../services/route.service'), 'land_ops_routes', 'routes');
