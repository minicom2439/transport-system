module.exports = require('./_dailyByDept.factory')('ow_water', 'water');
