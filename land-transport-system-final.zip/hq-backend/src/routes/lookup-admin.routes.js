const express = require('express');
const svc = require('../services/lookup-admin.service');
const { requireLogin } = require('../middleware/auth.middleware');
const { requirePermission } = require('../middleware/authorize.middleware');
const { audit } = require('../middleware/audit.middleware');

const router = express.Router();
const S = 'vehicle_admin_basic_data';
const T = (req) => req.params.table;
router.get('/:table', requireLogin, requirePermission(S, 'view'), async (req, res, next) => { try { res.json({ data: await svc.list(T(req)) }); } catch (e) { next(e); } });
router.post('/:table', requireLogin, requirePermission(S, 'add'), audit('create', 'lookup'), async (req, res, next) => { try { res.status(201).json({ data: await svc.create(T(req), req.body) }); } catch (e) { next(e); } });
router.put('/:table/:id', requireLogin, requirePermission(S, 'edit'), audit('update', 'lookup'), async (req, res, next) => { try { res.json({ data: await svc.update(T(req), Number(req.params.id), req.body) }); } catch (e) { next(e); } });
router.delete('/:table/:id', requireLogin, requirePermission(S, 'remove'), audit('delete', 'lookup'), async (req, res, next) => { try { await svc.remove(T(req), Number(req.params.id)); res.json({ ok: true }); } catch (e) { next(e); } });
module.exports = router;
