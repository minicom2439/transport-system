const express = require('express');
const svc = require('../services/search.service');
const { requireLogin } = require('../middleware/auth.middleware');
const { requirePermission } = require('../middleware/authorize.middleware');
const router = express.Router();
router.get('/', requireLogin, requirePermission('info_search', 'view'), async (req, res, next) => { try { res.json(await svc.search(req)); } catch (e) { next(e); } });
module.exports = router;
