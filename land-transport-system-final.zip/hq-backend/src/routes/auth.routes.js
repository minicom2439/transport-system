// src/routes/auth.routes.js
const express = require('express');
const authService = require('../services/auth.service');
const registrationService = require('../services/registration.service');
const auditRepo = require('../repositories/audit.repository');

const router = express.Router();

router.post('/login', async (req, res, next) => {
  try {
    const { username, password } = req.body || {};
    if (!username || !password) {
      return res.status(400).json({ error: 'username and password required' });
    }
    const user = await authService.authenticate(username, password);
    if (!user) return res.status(401).json({ error: 'Invalid credentials' });

    // Regenerate the session ID on login to prevent session fixation.
    req.session.regenerate((regenErr) => {
      if (regenErr) return next(regenErr);
      req.session.user = user;
      req.session.save((saveErr) => {
        if (saveErr) return next(saveErr);
        auditRepo.write({
          userId: user.id, action: 'login', entityType: 'users', entityId: user.id, host: req.ip,
        }).catch(() => {});
        res.json({
          user: {
            id: user.id, username: user.username, fullName: user.fullName, isSuperAdmin: user.isSuperAdmin,
          },
        });
      });
    });
  } catch (e) { next(e); }
});

router.post('/logout', (req, res) => {
  req.session.destroy(() => {
    res.clearCookie('sid');
    res.json({ ok: true });
  });
});

router.get('/me', (req, res) => {
  if (!req.session.user) return res.status(401).json({ error: 'Not logged in' });
  const u = req.session.user;
  res.json({
    user: { id: u.id, username: u.username, fullName: u.fullName, isSuperAdmin: u.isSuperAdmin },
    access: u.access,
  });
});


// Public self-registration -> creates a PENDING request (no session needed).
router.post('/register', async (req, res, next) => {
  try { res.status(201).json({ data: await registrationService.register(req.body || {}) }); }
  catch (e) { next(e); }
});

module.exports = router;
