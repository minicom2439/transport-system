// src/routes/_crud.factory.js — standard CRUD router for a scoped master-data resource.
const express = require('express');
const { requireLogin } = require('../middleware/auth.middleware');
const { requirePermission } = require('../middleware/authorize.middleware');
const { audit } = require('../middleware/audit.middleware');

module.exports = function crudRouter(svc, section, table) {
  const router = express.Router();
  const uid = (req) => req.session.user.id;
  router.get('/', requireLogin, requirePermission(section, 'view'), async (req, res, next) => {
    try { res.json(await svc.list(req)); } catch (e) { next(e); }
  });
  router.post('/', requireLogin, requirePermission(section, 'add'), audit('create', table), async (req, res, next) => {
    try { const row = await svc.create(req.body, uid(req)); res.locals.createdId = row.id; res.status(201).json({ data: row }); } catch (e) { next(e); }
  });
  router.put('/:id', requireLogin, requirePermission(section, 'edit'), audit('update', table), async (req, res, next) => {
    try { res.json({ data: await svc.update(Number(req.params.id), req.body, uid(req)) }); } catch (e) { next(e); }
  });
  router.delete('/:id', requireLogin, requirePermission(section, 'remove'), audit('delete', table), async (req, res, next) => {
    try { await svc.remove(Number(req.params.id)); res.json({ ok: true }); } catch (e) { next(e); }
  });
  return router;
};
