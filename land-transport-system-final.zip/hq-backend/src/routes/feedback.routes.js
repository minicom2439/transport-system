module.exports = require('./_crud.factory')(require('../services/feedback.service'), 'info_feedback', 'feedback');
