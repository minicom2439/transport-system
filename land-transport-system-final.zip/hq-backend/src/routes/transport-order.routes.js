module.exports = require('./_readonly.factory')(require('../services/transport-order.service'), 'land_ops_orders');
