// src/routes/index.js
const express = require('express');
const router = express.Router();

router.use('/auth', require('./auth.routes'));
router.use('/units', require('./unit.routes'));
router.use('/vehicles', require('./vehicle.routes'));
router.use('/transport', require('./transport.routes'));
router.use('/meta', require('./meta.routes'));
router.use('/notifications', require('./notification.routes'));
router.use('/users', require('./user.routes'));
router.use('/roles', require('./role.routes'));
router.use('/account-requests', require('./account-request.routes'));
router.use('/operating-conditions', require('./operating-condition.routes'));
router.use('/staff', require('./staff.routes'));
router.use('/parks', require('./park.routes'));
router.use('/routes', require('./route.routes'));
router.use('/reports', require('./report.routes'));
router.use('/schedules', require('./schedule.routes'));
router.use('/transfer-sections', require('./transfer-section.routes'));
router.use('/warehouses', require('./warehouse.routes'));
router.use('/route-certificates', require('./route-certificate.routes'));
router.use('/transport-orders', require('./transport-order.routes'));
router.use('/unit-stats', require('./unit-stat.routes'));
router.use('/lookups', require('./lookup-admin.routes'));
router.use('/finance', require('./finance.routes'));
router.use('/licenses', require('./license.routes'));
router.use('/indicators', require('./indicator.routes'));
router.use('/online-status', require('./online.routes'));
router.use('/park-vehicles', require('./park-vehicle.routes'));
router.use('/command-orders', require('./command-order.routes'));
router.use('/command-orders', require('./command-order-attachment.routes'));
router.use('/gps-devices', require('./gps.routes'));
router.use('/vehicle-locations', require('./vehicle-location.routes'));
router.use('/notices', require('./notice.routes'));
router.use('/programs', require('./program.routes'));
router.use('/faqs', require('./faq.routes'));
router.use('/feedback', require('./feedback.routes'));
router.use('/submissions', require('./submission.routes'));
router.use('/integration', require('./integration.routes'));
router.use('/monthly-reports', require('./monthly-report.routes'));
router.use('/effort-plans', require('./effort-plan.routes'));
router.use('/electricity-reports', require('./electricity-report.routes'));
router.use('/equipment', require('./equipment.routes'));
router.use('/equipment-inspections', require('./equipment-inspection.routes'));
router.use('/no-accident', require('./no-accident.routes'));
router.use('/weekly-schedules', require('./weekly-schedule.routes'));
router.use('/business-daily-reports', require('./business-daily.routes'));
router.use('/finance-stats', require('./finance-stats.routes'));
router.use('/guard-duties', require('./guard-duty.routes'));
router.use('/stats', require('./stats.routes'));
router.use('/search', require('./search.routes'));
router.use('/dept-daily/water', require('./ow-water.routes'));
router.use('/dept-daily/revenue', require('./ow-revenue.routes'));
router.use('/dept-daily/effort', require('./em-daily.routes'));
router.use('/dept-daily/first-business', require('./fbc-daily.routes'));




router.use('/accidents', require('./accident.routes'));
router.use('/invoices', require('./invoice.routes'));


module.exports = router;
