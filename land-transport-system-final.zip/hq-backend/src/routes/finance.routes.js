module.exports = require('./_crud.factory')(require('../services/finance.service'), 'land_ops_finance', 'finance_records');
