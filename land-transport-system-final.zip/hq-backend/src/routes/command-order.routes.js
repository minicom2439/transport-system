module.exports = require('./_crud.factory')(require('../services/command-order.service'), 'vehicle_admin_command_orders', 'command_orders');
