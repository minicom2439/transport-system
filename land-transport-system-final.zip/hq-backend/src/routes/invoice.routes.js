module.exports = require('./_crud.factory')(require('../services/invoice.service'), 'vehicle_admin_invoices', 'invoices');
