module.exports = require('./_crud.factory')(require('../services/weekly-schedule.service'), 'cmp_weekly', 'weekly_schedules');
