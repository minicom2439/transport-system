module.exports = require('./_dailyByDept.factory')('ow_revenue', 'revenue');
