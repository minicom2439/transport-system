module.exports = require('./_crud.factory')(require('../services/notice.service'), 'info_notices', 'notices');
