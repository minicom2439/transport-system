// src/routes/transport.routes.js
const express = require('express');
const transportService = require('../services/transport.service');
const { requireLogin } = require('../middleware/auth.middleware');
const { requirePermission } = require('../middleware/authorize.middleware');

const router = express.Router();
const SECTION = 'integration_traveler_stats';

router.get('/stats/by-unit', requireLogin, requirePermission(SECTION, 'view'), async (req, res, next) => {
  try { res.json({ data: await transportService.statsByUnit(req) }); } catch (e) { next(e); }
});

module.exports = router;
