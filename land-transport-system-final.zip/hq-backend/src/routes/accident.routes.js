module.exports = require('./_crud.factory')(require('../services/accident.service'), 'vehicle_admin_accidents', 'accident_notifications');
