module.exports = require('./_crud.factory')(require('../services/vehicle.service'), 'vehicle_admin_register', 'vehicles');
