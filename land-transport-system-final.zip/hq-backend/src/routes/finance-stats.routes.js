const { makeReadService } = require('../services/master-data.factory');
const svc = makeReadService(require('../repositories/finance.repository'), { scopeColumn: 'finance_records.unit_id' });
module.exports = require('./_readonly.factory')(svc, 'fin_stats');
