// src/routes/integration.routes.js
// Integration Management = HQ read-only oversight of subordinate data through the
// shared database. Each sub-route reuses an existing repository via a read service.
const express = require('express');
const readonly = require('./_readonly.factory');
const { makeReadService } = require('../services/master-data.factory');

const unitStatService = require('../services/unit-stat.service');       // stat_transport_monthly
const vehicleLocationService = require('../services/vehicle-location.service');
const invoiceReadService = makeReadService(require('../repositories/invoice.repository'), { scopeColumn: 'invoices.unit_id' });
const parkReadService = makeReadService(require('../repositories/park.repository'), { scopeColumn: 'parks.unit_id' });
const accidentReadService = makeReadService(require('../repositories/accident.repository'), { scopeColumn: 'accident_notifications.unit_id' });

const router = express.Router();
router.use('/traveler-stats', readonly(unitStatService, 'integration_traveler_stats'));
router.use('/thing-stats', readonly(unitStatService, 'integration_thing_stats'));
router.use('/e-invoices', readonly(invoiceReadService, 'integration_einvoice'));
router.use('/parks', readonly(parkReadService, 'integration_parks'));
router.use('/accidents', readonly(accidentReadService, 'integration_accidents'));
router.use('/locations', readonly(vehicleLocationService, 'integration_locations'));
module.exports = router;
