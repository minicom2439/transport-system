module.exports = require('./_crud.factory')(require('../services/program.service'), 'info_programs', 'programs');
