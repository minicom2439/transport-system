module.exports = require('./_crud.factory')(require('../services/equipment.service'), 'eqr_equipment', 'equipment');
