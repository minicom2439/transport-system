module.exports = require('./_crud.factory')(require('../services/gps.service'), 'sci_gps', 'gps_devices');
