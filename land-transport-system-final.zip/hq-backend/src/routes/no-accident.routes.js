module.exports = require('./_crud.factory')(require('../services/no-accident.service'), 'eqr_no_accident', 'no_accident_records');
