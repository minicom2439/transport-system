module.exports = require('./_crud.factory')(require('../services/warehouse.service'), 'land_ops_warehouses', 'warehouses');
