module.exports = require('./_crud.factory')(require('../services/staff.service'), 'other_staff', 'staff');
