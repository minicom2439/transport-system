const express = require('express');
const svc = require('../services/business-daily.service');
const { requireLogin } = require('../middleware/auth.middleware');
const { requirePermission } = require('../middleware/authorize.middleware');
const { audit } = require('../middleware/audit.middleware');
const S = 'cmp_daily_reports', T = 'business_daily_reports';
const router = express.Router();
const uid = (req) => req.session.user.id;
router.get('/', requireLogin, requirePermission(S, 'view'), async (req, res, next) => { try { res.json(await svc.list(req)); } catch (e) { next(e); } });
router.get('/:id/history', requireLogin, requirePermission(S, 'view'), async (req, res, next) => { try { res.json({ data: await svc.history(Number(req.params.id)) }); } catch (e) { next(e); } });
router.post('/', requireLogin, requirePermission(S, 'add'), audit('create', T), async (req, res, next) => { try { const r = await svc.create(req.body, uid(req)); res.status(201).json({ data: r }); } catch (e) { next(e); } });
router.put('/:id', requireLogin, requirePermission(S, 'edit'), audit('update', T), async (req, res, next) => { try { res.json({ data: await svc.update(Number(req.params.id), req.body, uid(req)) }); } catch (e) { next(e); } });
router.delete('/:id', requireLogin, requirePermission(S, 'remove'), audit('delete', T), async (req, res, next) => { try { await svc.remove(Number(req.params.id)); res.json({ ok: true }); } catch (e) { next(e); } });
router.post('/:id/submit', requireLogin, requirePermission(S, 'edit'), audit('submit', T), async (req, res, next) => { try { res.json({ data: await svc.act(Number(req.params.id), 'submit', uid(req)) }); } catch (e) { next(e); } });
router.post('/:id/cancel', requireLogin, requirePermission(S, 'edit'), audit('cancel', T), async (req, res, next) => { try { res.json({ data: await svc.act(Number(req.params.id), 'cancel', uid(req)) }); } catch (e) { next(e); } });
// review: approve with an optional business daily command, or reject with comment
router.post('/:id/approve', requireLogin, requirePermission(S, 'approve'), audit('approve', T), async (req, res, next) => { try { res.json({ data: await svc.act(Number(req.params.id), 'approve', uid(req), req.body && req.body.comment, { command: req.body && req.body.command }) }); } catch (e) { next(e); } });
router.post('/:id/reject', requireLogin, requirePermission(S, 'reject'), audit('reject', T), async (req, res, next) => { try { res.json({ data: await svc.act(Number(req.params.id), 'reject', uid(req), req.body && req.body.comment) }); } catch (e) { next(e); } });
module.exports = router;
