// src/routes/unit.routes.js
const express = require('express');
const unitService = require('../services/unit.service');
const { requireLogin } = require('../middleware/auth.middleware');
const { requirePermission } = require('../middleware/authorize.middleware');
const { audit } = require('../middleware/audit.middleware');

const router = express.Router();
const SECTION = 'land_ops_units'; // a screen node code in system_sections

router.get('/', requireLogin, requirePermission(SECTION, 'view'), async (req, res, next) => {
  try { res.json(await unitService.list(req)); } catch (e) { next(e); }
});

router.get('/:id', requireLogin, requirePermission(SECTION, 'view'), async (req, res, next) => {
  try {
    const unit = await unitService.getById(Number(req.params.id));
    if (!unit) return res.status(404).json({ error: 'Not found' });
    res.json({ data: unit });
  } catch (e) { next(e); }
});

router.post('/', requireLogin, requirePermission(SECTION, 'add'), audit('create', 'units'), async (req, res, next) => {
  try {
    const created = await unitService.create(req.body, req.session.user.id);
    res.locals.createdId = created.id;
    res.status(201).json({ data: created });
  } catch (e) { next(e); }
});

router.put('/:id', requireLogin, requirePermission(SECTION, 'edit'), audit('update', 'units'), async (req, res, next) => {
  try { res.json({ data: await unitService.update(Number(req.params.id), req.body, req.session.user.id) }); }
  catch (e) { next(e); }
});

router.delete('/:id', requireLogin, requirePermission(SECTION, 'remove'), audit('delete', 'units'), async (req, res, next) => {
  try { await unitService.remove(Number(req.params.id)); res.json({ ok: true }); }
  catch (e) { next(e); }
});

module.exports = router;
