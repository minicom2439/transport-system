module.exports = require('./_dailyByDept.factory')('em_daily', 'effort');
