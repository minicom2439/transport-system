module.exports = require('./_crud.factory')(require('../services/transfer-section.service'), 'land_ops_transfer_sections', 'transfer_sections');
