const express = require('express');
const svc = require('../services/user.service');
const { requireLogin } = require('../middleware/auth.middleware');
const { requirePermission } = require('../middleware/authorize.middleware');
const { audit } = require('../middleware/audit.middleware');

const router = express.Router();
const S = 'admin_users';

router.get('/', requireLogin, requirePermission(S, 'view'), async (req, res, next) => {
  try { res.json(await svc.list(req)); } catch (e) { next(e); }
});
router.get('/:id', requireLogin, requirePermission(S, 'view'), async (req, res, next) => {
  try { const u = await svc.getOne(Number(req.params.id)); if (!u) return res.status(404).json({ error: 'Not found' }); res.json({ data: u }); } catch (e) { next(e); }
});
router.post('/', requireLogin, requirePermission(S, 'add'), audit('create', 'users'), async (req, res, next) => {
  try { const u = await svc.create(req.body, { id: req.session.user.id, isSuperAdmin: req.session.user.isSuperAdmin }); res.locals.createdId = u.id; res.status(201).json({ data: u }); } catch (e) { next(e); }
});
router.put('/:id', requireLogin, requirePermission(S, 'edit'), audit('update', 'users'), async (req, res, next) => {
  try { res.json({ data: await svc.update(Number(req.params.id), req.body, { id: req.session.user.id, isSuperAdmin: req.session.user.isSuperAdmin }) }); } catch (e) { next(e); }
});
router.delete('/:id', requireLogin, requirePermission(S, 'remove'), audit('delete', 'users'), async (req, res, next) => {
  try { await svc.remove(Number(req.params.id), { id: req.session.user.id, isSuperAdmin: req.session.user.isSuperAdmin }); res.json({ ok: true }); } catch (e) { next(e); }
});

module.exports = router;
