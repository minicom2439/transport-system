module.exports = require('./_crud.factory')(require('../services/park.service'), 'vehicle_admin_parks', 'parks');
