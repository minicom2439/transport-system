module.exports = require('./_crud.factory')(require('../services/equipment-inspection.service'), 'eqr_inspections', 'equipment_inspections');
