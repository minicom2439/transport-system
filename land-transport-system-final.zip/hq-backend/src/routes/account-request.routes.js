const express = require('express');
const svc = require('../services/registration.service');
const { requireLogin } = require('../middleware/auth.middleware');
const { requirePermission } = require('../middleware/authorize.middleware');
const { audit } = require('../middleware/audit.middleware');

const router = express.Router();
const S = 'admin_requests';

router.get('/', requireLogin, requirePermission(S, 'view'), async (req, res, next) => {
  try { res.json({ data: await svc.listPending() }); } catch (e) { next(e); }
});
router.post('/:id/approve', requireLogin, requirePermission(S, 'edit'), audit('approve', 'account_requests'), async (req, res, next) => {
  try { await svc.approve(Number(req.params.id), req.session.user.id); res.json({ ok: true }); }
  catch (e) { next(e); }
});
router.post('/:id/reject', requireLogin, requirePermission(S, 'edit'), audit('reject', 'account_requests'), async (req, res, next) => {
  try { await svc.reject(Number(req.params.id), req.session.user.id); res.json({ ok: true }); }
  catch (e) { next(e); }
});

module.exports = router;
