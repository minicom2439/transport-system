// src/routes/notification.routes.js
const express = require('express');
const repo = require('../repositories/notification.repository');
const { requireLogin } = require('../middleware/auth.middleware');

const router = express.Router();

router.get('/', requireLogin, async (req, res, next) => {
  try { res.json({ data: await repo.listForUser(req.session.user.id) }); } catch (e) { next(e); }
});
router.get('/unread-count', requireLogin, async (req, res, next) => {
  try { res.json({ count: await repo.unreadCount(req.session.user.id) }); } catch (e) { next(e); }
});
router.post('/:id/read', requireLogin, async (req, res, next) => {
  try { await repo.markRead(Number(req.params.id), req.session.user.id); res.json({ ok: true }); } catch (e) { next(e); }
});
router.post('/read-all', requireLogin, async (req, res, next) => {
  try { await repo.markAllRead(req.session.user.id); res.json({ ok: true }); } catch (e) { next(e); }
});

module.exports = router;
