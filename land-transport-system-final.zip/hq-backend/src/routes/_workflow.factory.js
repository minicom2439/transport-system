const express = require('express');
const { requireLogin } = require('../middleware/auth.middleware');
const { requirePermission } = require('../middleware/authorize.middleware');
const { audit } = require('../middleware/audit.middleware');
module.exports = function workflowRouter(svc, section, table) {
  const router = express.Router();
  const uid = (req) => req.session.user.id;
  router.get('/', requireLogin, requirePermission(section, 'view'), async (req, res, next) => { try { res.json(await svc.list(req)); } catch (e) { next(e); } });
  router.get('/:id/history', requireLogin, requirePermission(section, 'view'), async (req, res, next) => { try { res.json({ data: await svc.history(Number(req.params.id)) }); } catch (e) { next(e); } });
  router.post('/', requireLogin, requirePermission(section, 'add'), audit('create', table), async (req, res, next) => { try { const r = await svc.create(req.body, uid(req)); res.locals.createdId = r.id; res.status(201).json({ data: r }); } catch (e) { next(e); } });
  router.put('/:id', requireLogin, requirePermission(section, 'edit'), audit('update', table), async (req, res, next) => { try { res.json({ data: await svc.update(Number(req.params.id), req.body, uid(req)) }); } catch (e) { next(e); } });
  router.delete('/:id', requireLogin, requirePermission(section, 'remove'), audit('delete', table), async (req, res, next) => { try { await svc.remove(Number(req.params.id)); res.json({ ok: true }); } catch (e) { next(e); } });
  router.post('/:id/submit', requireLogin, requirePermission(section, 'edit'), audit('submit', table), async (req, res, next) => { try { res.json({ data: await svc.act(Number(req.params.id), 'submit', uid(req)) }); } catch (e) { next(e); } });
  router.post('/:id/cancel', requireLogin, requirePermission(section, 'edit'), audit('cancel', table), async (req, res, next) => { try { res.json({ data: await svc.act(Number(req.params.id), 'cancel', uid(req)) }); } catch (e) { next(e); } });
  router.post('/:id/approve', requireLogin, requirePermission(section, 'approve'), audit('approve', table), async (req, res, next) => { try { res.json({ data: await svc.act(Number(req.params.id), 'approve', uid(req), req.body && req.body.comment, { command: req.body && req.body.command }) }); } catch (e) { next(e); } });
  router.post('/:id/reject', requireLogin, requirePermission(section, 'reject'), audit('reject', table), async (req, res, next) => { try { res.json({ data: await svc.act(Number(req.params.id), 'reject', uid(req), req.body && req.body.comment) }); } catch (e) { next(e); } });
  return router;
};
