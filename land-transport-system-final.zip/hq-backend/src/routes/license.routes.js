module.exports = require('./_workflow.factory')(require('../services/license.service'), 'land_ops_licenses', 'licenses');
