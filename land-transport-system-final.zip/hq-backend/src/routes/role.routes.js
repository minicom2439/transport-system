const express = require('express');
const svc = require('../services/role.service');
const { requireLogin } = require('../middleware/auth.middleware');
const { requirePermission } = require('../middleware/authorize.middleware');
const { audit } = require('../middleware/audit.middleware');

const router = express.Router();
const S = 'admin_roles';

router.get('/', requireLogin, requirePermission(S, 'view'), async (req, res, next) => {
  try { res.json(await svc.list(req)); } catch (e) { next(e); }
});
router.get('/:id/permissions', requireLogin, requirePermission(S, 'view'), async (req, res, next) => {
  try { res.json({ data: await svc.getPermissions(Number(req.params.id)) }); } catch (e) { next(e); }
});
router.post('/', requireLogin, requirePermission(S, 'add'), audit('create', 'roles'), async (req, res, next) => {
  try { const r = await svc.create(req.body, req.session.user.id); res.locals.createdId = r.id; res.status(201).json({ data: r }); } catch (e) { next(e); }
});
router.put('/:id', requireLogin, requirePermission(S, 'edit'), audit('update', 'roles'), async (req, res, next) => {
  try { res.json({ data: await svc.update(Number(req.params.id), req.body) }); } catch (e) { next(e); }
});
router.put('/:id/permissions', requireLogin, requirePermission(S, 'edit'), audit('update', 'role_permissions'), async (req, res, next) => {
  try { await svc.setPermissions(Number(req.params.id), req.body, { id: req.session.user.id, isSuperAdmin: req.session.user.isSuperAdmin }); res.json({ ok: true }); } catch (e) { next(e); }
});
router.delete('/:id', requireLogin, requirePermission(S, 'remove'), audit('delete', 'roles'), async (req, res, next) => {
  try { await svc.remove(Number(req.params.id), { id: req.session.user.id, isSuperAdmin: req.session.user.isSuperAdmin }); res.json({ ok: true }); } catch (e) { next(e); }
});

module.exports = router;
