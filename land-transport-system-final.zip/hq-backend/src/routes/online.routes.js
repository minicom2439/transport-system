module.exports = require('./_readonly.factory')(require('../services/online.service'), 'land_ops_online');
