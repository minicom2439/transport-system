const express = require('express');
const svc = require('../services/stats.service');
const { requireLogin } = require('../middleware/auth.middleware');
const { requirePermission } = require('../middleware/authorize.middleware');
const router = express.Router();
router.get('/transport', requireLogin, requirePermission('land_ops_ultimate_stats', 'view'), async (req, res, next) => { try { res.json(await svc.transport(req)); } catch (e) { next(e); } });
module.exports = router;
