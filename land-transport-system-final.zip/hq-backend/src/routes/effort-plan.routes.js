module.exports = require('./_workflow.factory')(require('../services/effort-plan.service'), 'pp_effort', 'effort_plans');
