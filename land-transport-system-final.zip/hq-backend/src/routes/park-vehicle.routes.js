module.exports = require('./_readonly.factory')(require('../services/park-vehicle.service'), 'land_ops_park_vehicles');
