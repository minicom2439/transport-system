const express = require('express');
const { requireLogin } = require('../middleware/auth.middleware');
const { requirePermission } = require('../middleware/authorize.middleware');
module.exports = function readonlyRouter(svc, section) {
  const router = express.Router();
  router.get('/', requireLogin, requirePermission(section, 'view'), async (req, res, next) => {
    try { res.json(await svc.list(req)); } catch (e) { next(e); }
  });
  return router;
};
