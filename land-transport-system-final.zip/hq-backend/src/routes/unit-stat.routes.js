module.exports = require('./_readonly.factory')(require('../services/unit-stat.service'), 'land_ops_unit_stats');
