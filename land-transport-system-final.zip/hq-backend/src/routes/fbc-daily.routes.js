module.exports = require('./_dailyByDept.factory')('fbc_daily', 'first_business');
