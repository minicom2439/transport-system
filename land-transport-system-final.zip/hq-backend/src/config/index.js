// src/config/index.js
require('dotenv').config();
const path = require('path');

const env = process.env.NODE_ENV || 'development';

// Secure cookies require HTTPS. On an air-gapped LAN served over plain HTTP,
// set COOKIE_SECURE=false or logins will silently fail (browser won't send
// the session cookie). Defaults to true in production unless overridden.
const cookieSecure = process.env.COOKIE_SECURE !== undefined
  ? process.env.COOKIE_SECURE === 'true'
  : env === 'production';

module.exports = {
  env,
  isProduction: env === 'production',
  systemCode: process.env.SYSTEM_CODE || 'hq',  // which app's nav tree this server owns
  port: Number(process.env.PORT) || 4000,
  // Serve the built frontend from this same server (single-origin deploy on an
  // isolated LAN). Build the frontend, drop its dist into backend/public (or
  // point CLIENT_DIST elsewhere), and set SERVE_CLIENT=true.
  serveClient: process.env.SERVE_CLIENT === 'true',
  maxUploadMb: Number(process.env.MAX_UPLOAD_MB) || 25,
  get maxUploadBytes() { return this.maxUploadMb * 1024 * 1024; },
  jsonBodyLimit: process.env.JSON_BODY_LIMIT || `${Math.ceil((Number(process.env.MAX_UPLOAD_MB) || 25) * 1.5) + 2}mb`,
  clientDist: process.env.CLIENT_DIST || path.resolve(__dirname, '..', '..', 'public'),
  session: {
    secret: process.env.SESSION_SECRET || 'change-me',
    maxAgeMs: 8 * 60 * 60 * 1000,
    cookieSecure,
  },
};
