// src/server.js
const createApp = require('./app');
const config = require('./config');
const knex = require('./db/knex');
const { ensureSessionTable } = require('./db/session-store');

async function start() {
  await ensureSessionTable(knex); // create sessions table once before traffic

  const app = createApp();
  const server = app.listen(config.port, () => {
    console.log(`HQ Transport backend listening on http://localhost:${config.port} (${config.env})`);
  });

  // Close the HTTP server and DB pool cleanly on shutdown.
  const shutdown = (sig) => {
    console.log(`\n${sig} received, shutting down...`);
    server.close(() => {
      knex.destroy().then(() => process.exit(0)).catch(() => process.exit(1));
    });
    // Force-exit if it hangs.
    setTimeout(() => process.exit(1), 10000).unref();
  };
  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('SIGTERM', () => shutdown('SIGTERM'));
}

start().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
