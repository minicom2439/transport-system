// src/app.js
const express = require('express');
const path = require('path');
const session = require('express-session');
const config = require('./config');
const knex = require('./db/knex');
const createKnexSessionStore = require('./db/session-store');
const routes = require('./routes');
const { notFound, errorHandler } = require('./middleware/error.middleware');

function createApp() {
  const app = express();

  app.set('trust proxy', 1);
  app.use(express.json({ limit: config.jsonBodyLimit }));
  app.use(express.urlencoded({ extended: true }));

  app.use(session({
    name: 'sid',
    secret: config.session.secret,
    store: createKnexSessionStore(knex),
    resave: false,
    saveUninitialized: false,
    rolling: true,
    cookie: {
      httpOnly: true,
      sameSite: 'lax',
      secure: config.session.cookieSecure, // env-configurable; false for plain-HTTP LAN
      maxAge: config.session.maxAgeMs,
    },
  }));

  app.get('/health', async (req, res) => {
    try {
      await knex.raw('select 1');
      res.json({ status: 'ok', env: config.env, db: 'up' });
    } catch (e) {
      res.status(503).json({ status: 'degraded', env: config.env, db: 'down' });
    }
  });
  app.use('/api', routes);

  // Optional: serve the built SPA from this same server (one process on the LAN).
  if (config.serveClient) {
    app.use(express.static(config.clientDist));
    // SPA fallback for client-side routes. The negative lookahead keeps /api and
    // /health returning real JSON (so unknown API paths still 404 as JSON).
    app.get(/^\/(?!api(?:\/|$)|health(?:\/|$)).*/, (req, res, next) => {
      res.sendFile(path.join(config.clientDist, 'index.html'), (err) => { if (err) next(); });
    });
  }

  app.use(notFound);
  app.use(errorHandler);

  return app;
}

module.exports = createApp;
