// src/services/lookup-admin.service.js
const { lookupRepo } = require('../repositories/lookup.repository');
const { ValidationError } = require('./errors');

// Whitelist of tables manageable through Basic Data.
const WHITELIST = new Set([
  'vehicle_types', 'vehicle_forms', 'vehicle_uses', 'technical_statuses',
  'equipment_categories', 'register_categories', 'vehicle_statuses',
  'structural_features', 'real_move_states', 'safety_directives',
  'accident_severities', 'order_statuses', 'order_types', 'report_types',
  'schedule_types', 'route_types', 'finance_categories', 'license_types',
]);

function repoFor(table) {
  if (!WHITELIST.has(table)) throw new ValidationError({ _: 'Unknown reference table.' });
  return lookupRepo(table);
}
function validate(b) {
  if (!b.name || !String(b.name).trim()) throw new ValidationError({ name: 'Name is required.' });
  return { name: String(b.name).trim(), code: b.code ? String(b.code).trim() : null, description: b.description ? String(b.description) : null };
}
module.exports = {
  WHITELIST,
  list: (t) => repoFor(t).list(),
  create: (t, b) => repoFor(t).create(validate(b)),
  update: (t, id, b) => repoFor(t).update(id, validate(b)),
  remove: (t, id) => repoFor(t).remove(id),
};
