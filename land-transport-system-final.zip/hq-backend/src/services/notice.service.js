const repo = require('../repositories/notice.repository');
const { makeService, requireFields } = require('./master-data.factory');
const validate = (b) => requireFields(b, { title: { label: 'Title', required: true }, body: { label: 'Body' }, published_at: { label: 'Publish date' }, is_published: { label: 'Published', type: 'bool' } });
module.exports = makeService(repo, { validate, createdBy: false, updatedBy: false, ownerColumn: 'author_id' });
