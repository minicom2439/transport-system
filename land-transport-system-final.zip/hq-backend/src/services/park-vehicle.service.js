const repo = require('../repositories/vehicle.repository');
const { makeReadService } = require('./master-data.factory');
module.exports = makeReadService(repo, { scopeColumn: 'vehicles.unit_id' });
