// src/services/master-data.factory.js
const { parseListParams } = require('../repositories/list-query');
const { dataScopeClause } = require('./permission.service');
const { ValidationError } = require('./errors');

// updatedBy/createdBy flags accommodate tables that lack those columns.
function makeService(repo, { scopeColumn, validate, createdBy = true, updatedBy = true, ownerColumn = null } = {}) {
  function accessOf(req) { const a = req.session.user.access; return { isSuperAdmin: a.isSuperAdmin, dataScopes: a.dataScopes }; }
  async function list(req) {
    const params = parseListParams(req.query);
    const scope = scopeColumn ? dataScopeClause(accessOf(req), { unitColumn: scopeColumn }) : null;
    const { data, total } = await repo.search(params, scope);
    return { data, total, page: params.page, limit: params.limit, sort: params.sort, dir: params.dir };
  }
  function create(body, userId) {
    const d = validate(body);
    // Drop nulls so columns with NOT NULL DEFAULTs use their default.
    Object.keys(d).forEach((k) => { if (d[k] === null || d[k] === undefined) delete d[k]; });
    if (createdBy) d.created_by = userId;
    if (ownerColumn) d[ownerColumn] = userId;
    return repo.create(d);
  }
  function update(id, body, userId) { const d = validate(body); if (updatedBy) d.updated_by = userId; return repo.update(id, d); }
  function remove(id) { return repo.remove(id); }
  return { list, create, update, remove };
}

function requireFields(body, specs) {
  const fields = {}; const out = {};
  for (const [key, spec] of Object.entries(specs)) {
    const raw = body[key];
    if (spec.required && (raw === undefined || raw === null || String(raw).trim() === '')) { fields[key] = spec.label + ' is required.'; continue; }
    if (raw === undefined || raw === null || raw === '') { out[key] = null; continue; }
    out[key] = spec.type === 'number' ? Number(raw) : spec.type === 'bool' ? (raw ? 1 : 0) : String(raw).trim();
  }
  if (Object.keys(fields).length) throw new ValidationError(fields);
  return out;
}

// Read-only list service (orders, statistics).
function makeReadService(repo, { scopeColumn } = {}) {
  function accessOf(req) { const a = req.session.user.access; return { isSuperAdmin: a.isSuperAdmin, dataScopes: a.dataScopes }; }
  return {
    async list(req) {
      const params = parseListParams(req.query);
      const scope = scopeColumn ? dataScopeClause(accessOf(req), { unitColumn: scopeColumn }) : null;
      const { data, total } = await repo.search(params, scope);
      return { data, total, page: params.page, limit: params.limit, sort: params.sort, dir: params.dir };
    },
  };
}

module.exports = { makeService, requireFields, makeReadService };
