const repo = require('../repositories/indicator.repository');
const { makeService, requireFields } = require('./master-data.factory');
const validate = (b) => requireFields(b, { name: { label: 'Name', required: true }, code: { label: 'Code' }, unit_of_measure: { label: 'Unit of measure' }, description: { label: 'Description' } });
module.exports = makeService(repo, { validate, createdBy: false, updatedBy: false });
