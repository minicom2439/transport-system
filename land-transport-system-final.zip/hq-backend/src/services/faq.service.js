const repo = require('../repositories/faq.repository');
const { makeService, requireFields } = require('./master-data.factory');
const validate = (b) => requireFields(b, { question: { label: 'Question', required: true }, answer: { label: 'Answer' }, sort_order: { label: 'Sort order', type: 'number' } });
module.exports = makeService(repo, { validate, createdBy: false, updatedBy: false });
