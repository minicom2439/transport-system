const repo = require('../repositories/license.repository');
const { makeWorkflowService } = require('./workflow-resource.factory');
const { requireFields } = require('./master-data.factory');
const validate = (b) => requireFields(b, { license_no: { label: 'License no' }, license_type_id: { label: 'Type', type: 'number' }, unit_id: { label: 'Unit', required: true, type: 'number' }, valid_from: { label: 'Valid from' }, valid_to: { label: 'Valid to' } });
module.exports = makeWorkflowService(repo, { entity: 'license', scopeColumn: 'licenses.unit_id', validate });
