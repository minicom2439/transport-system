const repo = require('../repositories/invoice.repository');
const { makeService, requireFields } = require('./master-data.factory');
const validate = (b) => requireFields(b, { invoice_no: { label: 'Invoice no', required: true }, unit_id: { label: 'Unit', type: 'number' }, order_id: { label: 'Order', type: 'number' }, amount: { label: 'Amount', type: 'number' }, issued_at: { label: 'Issued at' }, status_id: { label: 'Status', type: 'number' } });
module.exports = makeService(repo, { scopeColumn: 'invoices.unit_id', validate, createdBy: false, updatedBy: false });
