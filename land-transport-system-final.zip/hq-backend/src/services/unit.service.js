// src/services/unit.service.js
const unitRepo = require('../repositories/unit.repository');
const { dataScopeClause } = require('./permission.service');
const { parseListParams } = require('../repositories/list-query');
const { ValidationError } = require('./errors');

function accessOf(req) {
  const a = req.session.user.access;
  return { isSuperAdmin: a.isSuperAdmin, dataScopes: a.dataScopes };
}

async function list(req) {
  const params = parseListParams(req.query);
  const scope = dataScopeClause(accessOf(req), { unitColumn: 'units.id', regionColumn: 'units.region_id' });
  const { data, total } = await unitRepo.search(params, scope);
  return { data, total, page: params.page, limit: params.limit, sort: params.sort, dir: params.dir };
}

function getById(id) { return unitRepo.findById(id); }

function validate(data) {
  const fields = {};
  if (!data.name || !String(data.name).trim()) fields.name = 'Name is required.';
  if (!data.region_id || Number.isNaN(Number(data.region_id))) fields.region_id = 'Region is required.';
  if (Object.keys(fields).length) throw new ValidationError(fields);
  return { name: String(data.name).trim(), code: data.code ? String(data.code).trim() : null, region_id: Number(data.region_id) };
}

function create(data, userId) { return unitRepo.create({ ...validate(data), created_by: userId }); }
function update(id, data, userId) { return unitRepo.update(id, { ...validate(data), updated_by: userId }); }
function remove(id) { return unitRepo.remove(id); }

module.exports = { list, getById, create, update, remove };
