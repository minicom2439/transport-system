const repo = require('../repositories/staff.repository');
const { makeService, requireFields } = require('./master-data.factory');
const validate = (b) => requireFields(b, {
  full_name: { label: 'Full name', required: true },
  unit_id: { label: 'Unit', required: true, type: 'number' },
  staff_no: { label: 'Staff no' }, position: { label: 'Position' },
  phone: { label: 'Phone' }, date_joined: { label: 'Date joined' },
});
module.exports = makeService(repo, { scopeColumn: 'staff.unit_id', validate });
