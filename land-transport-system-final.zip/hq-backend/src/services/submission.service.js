// Science & Technology Data Submission: a Unit submits data; an admin reviews
// it and may issue an instruction (command). Table has no updated_by column.
const repo = require('../repositories/submission.repository');
const { parseListParams } = require('../repositories/list-query');
const { dataScopeClause } = require('./permission.service');
const { ValidationError } = require('./errors');
const { requireFields } = require('./master-data.factory');
const workflow = require('./workflow.service');
const validate = (b) => requireFields(b, { title: { label: 'Title', required: true }, unit_id: { label: 'Unit', type: 'number' }, file_path: { label: 'File path' } });
const accessOf = (req) => { const a = req.session.user.access; return { isSuperAdmin: a.isSuperAdmin, dataScopes: a.dataScopes }; };
async function list(req) {
  const params = parseListParams(req.query);
  const scope = dataScopeClause(accessOf(req), { unitColumn: 'tech_data_submissions.unit_id' });
  const { data, total } = await repo.search(params, scope);
  return { data, total, page: params.page, limit: params.limit, sort: params.sort, dir: params.dir };
}
async function create(body, userId) {
  const d = validate(body);
  Object.keys(d).forEach((k) => { if (d[k] === null || d[k] === undefined) delete d[k]; });
  const row = await repo.create({ ...d, submitted_by: userId, submitted_at: new Date().toISOString() });
  const approvalId = await workflow.createDraft('tech_data_submission', row.id, userId);
  await repo.update(row.id, { approval_id: approvalId });
  return repo.detail(row.id);
}
async function update(id, body, userId) {
  const cur = await repo.detail(id);
  if (!cur) throw new ValidationError({ _: 'Not found.' });
  if (!['draft', 'rejected'].includes(cur.status)) throw new ValidationError({ _: `A ${cur.status} submission cannot be edited.` });
  await repo.update(id, validate(body));
  if (cur.status === 'rejected') await workflow.transition(cur.approval_id, 'reopen', userId);
  return repo.detail(id);
}
function remove(id) { return repo.remove(id); }
async function act(id, action, userId, comment, extra = {}) {
  const cur = await repo.detail(id);
  if (!cur) throw new ValidationError({ _: 'Not found.' });
  if (action === 'approve' && extra.command !== undefined) await repo.update(id, { command: extra.command });
  await workflow.transition(cur.approval_id, action, userId, comment);
  return repo.detail(id);
}
function history(id) { return repo.detail(id).then((c) => (c ? workflow.history(c.approval_id) : [])); }
module.exports = { list, create, update, remove, act, history };
