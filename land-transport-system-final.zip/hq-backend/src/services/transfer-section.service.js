const repo = require('../repositories/transfer-section.repository');
const { makeService, requireFields } = require('./master-data.factory');
const validate = (b) => requireFields(b, { name: { label: 'Name', required: true }, start_region_id: { label: 'Start area', type: 'number' }, end_region_id: { label: 'Arrive area', type: 'number' } });
module.exports = makeService(repo, { validate, updatedBy: false }); // no updated_by col
