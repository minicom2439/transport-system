// src/services/workflow-resource.factory.js
// Builds a service for an approval-workflow resource (create-as-draft, edit only
// when draft/rejected with auto-reopen, submit/approve/reject/cancel, history).
const { parseListParams } = require('../repositories/list-query');
const { dataScopeClause } = require('./permission.service');
const { ValidationError } = require('./errors');
const workflow = require('./workflow.service');

function makeWorkflowService(repo, { entity, scopeColumn, validate, commandColumn = null }) {
  function accessOf(req) { const a = req.session.user.access; return { isSuperAdmin: a.isSuperAdmin, dataScopes: a.dataScopes }; }
  async function list(req) {
    const params = parseListParams(req.query);
    const scope = scopeColumn ? dataScopeClause(accessOf(req), { unitColumn: scopeColumn }) : null;
    const { data, total } = await repo.search(params, scope);
    return { data, total, page: params.page, limit: params.limit, sort: params.sort, dir: params.dir };
  }
  async function create(body, userId) {
    const d = validate(body);
    Object.keys(d).forEach((k) => { if (d[k] === null || d[k] === undefined) delete d[k]; });
    const row = await repo.create({ ...d, created_by: userId });
    const approvalId = await workflow.createDraft(entity, row.id, userId);
    await repo.update(row.id, { approval_id: approvalId });
    return repo.detail(row.id);
  }
  async function update(id, body, userId) {
    const cur = await repo.detail(id);
    if (!cur) throw new ValidationError({ _: 'Not found.' });
    if (!['draft', 'rejected'].includes(cur.status)) throw new ValidationError({ _: `A ${cur.status} item cannot be edited.` });
    await repo.update(id, { ...validate(body), updated_by: userId });
    if (cur.status === 'rejected') await workflow.transition(cur.approval_id, 'reopen', userId);
    return repo.detail(id);
  }
  function remove(id) { return repo.remove(id); }
  async function act(id, action, userId, comment, extra = {}) {
    const cur = await repo.detail(id);
    if (!cur) throw new ValidationError({ _: 'Not found.' });
    // an admin's review can carry a command/instruction back to the unit
    if (action === 'approve' && commandColumn && extra.command !== undefined) await repo.update(id, { [commandColumn]: extra.command, updated_by: userId });
    await workflow.transition(cur.approval_id, action, userId, comment);
    return repo.detail(id);
  }
  function history(id) { return repo.detail(id).then((c) => (c ? workflow.history(c.approval_id) : [])); }
  return { list, create, update, remove, act, history };
}

module.exports = { makeWorkflowService };
