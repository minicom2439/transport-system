const repo = require('../repositories/unit-stat.repository');
const { makeReadService } = require('./master-data.factory');
module.exports = makeReadService(repo, { scopeColumn: 'stat_transport_monthly.unit_id' });
