const repo = require('../repositories/gps.repository');
const { makeService, requireFields } = require('./master-data.factory');
const validate = (b) => requireFields(b, { vehicle_id: { label: 'Vehicle', required: true, type: 'number' }, device_no: { label: 'Device no', required: true }, installed_on: { label: 'Installed on' } });
module.exports = makeService(repo, { scopeColumn: 'v.unit_id', validate, createdBy: false, updatedBy: false });
