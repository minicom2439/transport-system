// src/services/operating-condition.service.js
const repo = require('../repositories/operating-condition.repository');
const knex = require('../db/knex');
const { parseListParams } = require('../repositories/list-query');
const { dataScopeClause } = require('./permission.service');
const { ValidationError } = require('./errors');
const workflow = require('./workflow.service');

const ENTITY = 'operating_condition';

function accessOf(req) { const a = req.session.user.access; return { isSuperAdmin: a.isSuperAdmin, dataScopes: a.dataScopes }; }

async function list(req) {
  const params = parseListParams(req.query);
  const scope = dataScopeClause(accessOf(req), { unitColumn: 'operating_conditions.unit_id' });
  const { data, total } = await repo.search(params, scope);
  return { data, total, page: params.page, limit: params.limit, sort: params.sort, dir: params.dir };
}

function validate(body) {
  const fields = {};
  if (!body.title || !String(body.title).trim()) fields.title = 'Title is required.';
  if (!body.unit_id || Number.isNaN(Number(body.unit_id))) fields.unit_id = 'Unit is required.';
  if (Object.keys(fields).length) throw new ValidationError(fields);
  return {
    title: String(body.title).trim(),
    unit_id: Number(body.unit_id),
    scope_description: body.scope_description ? String(body.scope_description) : null,
    allowed_vehicle_count: body.allowed_vehicle_count ? Number(body.allowed_vehicle_count) : null,
    allows_passenger: body.allows_passenger ? 1 : 0,
    allows_cargo: body.allows_cargo ? 1 : 0,
    valid_from: body.valid_from || null,
    valid_to: body.valid_to || null,
  };
}

async function create(body, userId) {
  const data = validate(body);
  const condition = await repo.create({ ...data, created_by: userId });
  const approvalId = await workflow.createDraft(ENTITY, condition.id, userId);
  await repo.update(condition.id, { approval_id: approvalId });
  return repo.detail(condition.id);
}

async function update(id, body, userId) {
  const current = await repo.detail(id);
  if (!current) throw new ValidationError({ _: 'Not found.' });
  if (!['draft', 'rejected'].includes(current.status)) {
    throw new ValidationError({ _: `A ${current.status} condition cannot be edited.` });
  }
  const data = validate(body);
  await repo.update(id, { ...data, updated_by: userId });
  if (current.status === 'rejected') await workflow.transition(current.approval_id, 'reopen', userId);
  return repo.detail(id);
}

function remove(id) { return repo.remove(id); }

async function act(id, action, userId, comment) {
  const c = await repo.detail(id);
  if (!c) throw new ValidationError({ _: 'Not found.' });
  await workflow.transition(c.approval_id, action, userId, comment);
  return repo.detail(id);
}

function history(id) { return repo.detail(id).then((c) => (c ? workflow.history(c.approval_id) : [])); }

module.exports = { list, create, update, remove, act, history };
