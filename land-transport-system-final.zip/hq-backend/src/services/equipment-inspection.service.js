const repo = require('../repositories/equipment-inspection.repository');
const { makeService, requireFields } = require('./master-data.factory');
const validate = (b) => requireFields(b, { equipment_id: { label: 'Equipment', type: 'number' }, unit_id: { label: 'Unit', type: 'number' }, inspection_date: { label: 'Date', required: true }, inspection_type: { label: 'Type' }, result: { label: 'Result' }, inspector: { label: 'Inspector' }, notes: { label: 'Notes' } });
module.exports = makeService(repo, { scopeColumn: 'equipment_inspections.unit_id', validate });
