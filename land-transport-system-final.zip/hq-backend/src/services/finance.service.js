const repo = require('../repositories/finance.repository');
const { makeService, requireFields } = require('./master-data.factory');
const validate = (b) => requireFields(b, { unit_id: { label: 'Unit', type: 'number' }, record_date: { label: 'Date', required: true }, category_id: { label: 'Category', type: 'number' }, direction: { label: 'Direction', type: 'number' }, amount: { label: 'Amount', required: true, type: 'number' }, note: { label: 'Note' } });
module.exports = makeService(repo, { scopeColumn: 'finance_records.unit_id', validate, updatedBy: false });
