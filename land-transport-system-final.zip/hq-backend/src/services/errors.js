// src/services/errors.js — typed errors the API layer understands.
class ValidationError extends Error {
  constructor(fields, message = 'Validation failed') {
    super(message); this.name = 'ValidationError'; this.status = 400; this.fields = fields;
  }
}
class ForbiddenError extends Error {
  constructor(message = 'Forbidden') { super(message); this.name = 'ForbiddenError'; this.status = 403; }
}
module.exports = { ValidationError, ForbiddenError };
