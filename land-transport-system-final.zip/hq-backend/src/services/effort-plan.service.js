const repo = require('../repositories/effort-plan.repository');
const { makeWorkflowService } = require('./workflow-resource.factory');
const { requireFields } = require('./master-data.factory');
const validate = (b) => requireFields(b, { unit_id: { label: 'Unit', type: 'number' }, period: { label: 'Period', required: true }, title: { label: 'Title', required: true }, target_value: { label: 'Target', type: 'number' }, actual_value: { label: 'Actual', type: 'number' }, notes: { label: 'Notes' } });
module.exports = makeWorkflowService(repo, { entity: 'effort_plan', scopeColumn: 'effort_plans.unit_id', validate, commandColumn: 'command' });
