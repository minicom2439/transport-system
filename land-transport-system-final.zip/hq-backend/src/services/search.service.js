// Integrated Search (Information Service): keyword search across key entities.
const knex = require('../db/knex');
const like = (q) => `%${q}%`;
async function search(req) {
  const q = (req.query.q || '').trim();
  if (q.length < 2) return { q, groups: [] };
  const L = like(q);
  const [units, vehicles, routes, equipment, notices, reports] = await Promise.all([
    knex('units').where('name', 'like', L).orWhere('code', 'like', L).select('id', 'name', 'code').limit(6),
    knex('vehicles').where('plate_no', 'like', L).select('id', 'plate_no').limit(6),
    knex('routes').where('is_active', 1).andWhere((b) => b.where('name', 'like', L).orWhere('route_no', 'like', L)).select('id', 'name', 'route_no').limit(6),
    knex('equipment').where('is_active', 1).andWhere((b) => b.where('name', 'like', L).orWhere('code', 'like', L)).select('id', 'name', 'code').limit(6),
    knex('notices').where('title', 'like', L).select('id', 'title').limit(6),
    knex('business_daily_reports').where('is_active', 1).andWhere('title', 'like', L).select('id', 'title', 'department').limit(6),
  ]);
  const groups = [
    { type: 'Units', items: units.map((r) => ({ id: r.id, label: r.name, sub: r.code })) },
    { type: 'Vehicles', items: vehicles.map((r) => ({ id: r.id, label: r.plate_no })) },
    { type: 'Routes', items: routes.map((r) => ({ id: r.id, label: r.name, sub: r.route_no })) },
    { type: 'Equipment', items: equipment.map((r) => ({ id: r.id, label: r.name, sub: r.code })) },
    { type: 'Notices', items: notices.map((r) => ({ id: r.id, label: r.title })) },
    { type: 'Daily reports', items: reports.map((r) => ({ id: r.id, label: r.title, sub: r.department })) },
  ].filter((g) => g.items.length);
  return { q, groups };
}
module.exports = { search };
