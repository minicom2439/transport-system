const knex = require('../db/knex');
const blobRepo = require('../repositories/file-blob.repository');
const config = require('../config');
const { ValidationError } = require('./errors');
const { dataScopeClause } = require('./permission.service');
const notFound = () => { throw Object.assign(new Error('Order not found'), { status: 404, publicMessage: 'Order not found' }); };
const scopeOf = (req) => { const a = req.session.user.access; return dataScopeClause({ isSuperAdmin: a.isSuperAdmin, dataScopes: a.dataScopes }, { unitColumn: 'command_orders.target_unit_id' }); };
async function findOrder(req) { let qb = knex('command_orders').where('command_orders.id', Number(req.params.id)); const sc = scopeOf(req); if (typeof sc === 'function') qb = sc(qb); return qb.first(); }
async function list(req) { const o = await findOrder(req); if (!o) notFound(); return knex('command_order_attachments').where({ command_order_id: o.id }).select('id', 'file_name', 'file_size', 'content_type', 'uploaded_at').orderBy('id'); }
async function upload(req) {
  const o = await findOrder(req); if (!o) notFound();
  const b = req.body || {};
  if (!b.file_name) throw new ValidationError({ file_name: 'File name is required.' });
  if (!b.data_base64) throw new ValidationError({ file: 'Please attach a file.' });
  let buf; try { buf = Buffer.from(String(b.data_base64), 'base64'); } catch (e) { throw new ValidationError({ file: 'Invalid file data.' }); }
  if (!buf.length) throw new ValidationError({ file: 'The file is empty.' });
  if (buf.length > config.maxUploadBytes) throw new ValidationError({ file: `File exceeds the ${config.maxUploadMb} MB limit.` });
  const blob = await blobRepo.insert({ buffer: buf, content_type: b.content_type, created_by: req.session.user.id });
  const [id] = await knex('command_order_attachments').insert({ command_order_id: o.id, file_name: b.file_name, blob_id: blob.id, file_size: blob.byte_size, content_type: b.content_type || null, uploaded_by: req.session.user.id });
  return { id, file_name: b.file_name, file_size: blob.byte_size };
}
async function remove(req) {
  const o = await findOrder(req); if (!o) notFound();
  const att = await knex('command_order_attachments').where({ id: Number(req.params.attId), command_order_id: o.id }).first(); if (!att) notFound();
  await knex('command_order_attachments').where({ id: att.id }).del();
  return { ok: true };
}
module.exports = { list, upload, remove };
