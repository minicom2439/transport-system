const repo = require('../repositories/report.repository');
const { makeWorkflowService } = require('./workflow-resource.factory');
const { requireFields } = require('./master-data.factory');
const validate = (b) => requireFields(b, { report_type_id: { label: 'Report type', type: 'number' }, report_date: { label: 'Report date', required: true }, period: { label: 'Period' }, title: { label: 'Title', required: true }, content: { label: 'Content' } });
module.exports = makeWorkflowService(repo, { entity: 'business_report', validate, commandColumn: 'command' });
