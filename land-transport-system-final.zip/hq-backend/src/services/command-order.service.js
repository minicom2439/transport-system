const repo = require('../repositories/command-order.repository');
const { makeService, requireFields } = require('./master-data.factory');
const validate = (b) => requireFields(b, { target_unit_id: { label: 'Target unit', required: true, type: 'number' }, title: { label: 'Title', required: true }, short_title: { label: 'Short title' }, body: { label: 'Instruction details' }, instruction_category: { label: 'Instruction category' }, order_number: { label: 'Order number' }, order_classification: { label: 'Order classification' }, order_date: { label: 'Date' }, status_id: { label: 'Status', type: 'number' } });
module.exports = makeService(repo, { scopeColumn: 'command_orders.target_unit_id', validate, updatedBy: false });
