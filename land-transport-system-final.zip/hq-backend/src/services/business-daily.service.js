// src/services/business-daily.service.js
// Submit/review workflow: a Unit writes & submits a daily report; an admin
// reviews it and issues a "business daily command" (directive) on approval.
const repo = require('../repositories/business-daily.repository');
const { parseListParams } = require('../repositories/list-query');
const { dataScopeClause } = require('./permission.service');
const { ValidationError } = require('./errors');
const { requireFields } = require('./master-data.factory');
const workflow = require('./workflow.service');

const validate = (b) => requireFields(b, { department: { label: 'Department' }, unit_id: { label: 'Unit', type: 'number' }, report_date: { label: 'Date', required: true }, title: { label: 'Title', required: true }, content: { label: 'Content' } });
const accessOf = (req) => { const a = req.session.user.access; return { isSuperAdmin: a.isSuperAdmin, dataScopes: a.dataScopes }; };

async function list(req) {
  const params = parseListParams(req.query);
  const scope = dataScopeClause(accessOf(req), { unitColumn: 'business_daily_reports.unit_id' });
  const { data, total } = await repo.search(params, scope);
  return { data, total, page: params.page, limit: params.limit, sort: params.sort, dir: params.dir };
}
async function create(body, userId) {
  const d = validate(body);
  Object.keys(d).forEach((k) => { if (d[k] === null || d[k] === undefined) delete d[k]; });
  const row = await repo.create({ ...d, created_by: userId });
  const approvalId = await workflow.createDraft('business_daily_report', row.id, userId);
  await repo.update(row.id, { approval_id: approvalId });
  return repo.detail(row.id);
}
async function update(id, body, userId) {
  const cur = await repo.detail(id);
  if (!cur) throw new ValidationError({ _: 'Not found.' });
  if (!['draft', 'rejected'].includes(cur.status)) throw new ValidationError({ _: `A ${cur.status} report cannot be edited.` });
  await repo.update(id, { ...validate(body), updated_by: userId });
  if (cur.status === 'rejected') await workflow.transition(cur.approval_id, 'reopen', userId);
  return repo.detail(id);
}
function remove(id) { return repo.remove(id); }
async function act(id, action, userId, comment, extra = {}) {
  const cur = await repo.detail(id);
  if (!cur) throw new ValidationError({ _: 'Not found.' });
  // an admin's review can carry a business daily command
  if (action === 'approve' && extra.command !== undefined) await repo.update(id, { command: extra.command, updated_by: userId });
  await workflow.transition(cur.approval_id, action, userId, comment);
  return repo.detail(id);
}
function history(id) { return repo.detail(id).then((c) => (c ? workflow.history(c.approval_id) : [])); }
module.exports = { list, create, update, remove, act, history };
