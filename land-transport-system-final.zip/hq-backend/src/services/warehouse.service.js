const repo = require('../repositories/warehouse.repository');
const { makeService, requireFields } = require('./master-data.factory');
const validate = (b) => requireFields(b, { name: { label: 'Name', required: true }, unit_id: { label: 'Unit', required: true, type: 'number' }, region_id: { label: 'Region', type: 'number' }, code: { label: 'Code' }, capacity: { label: 'Capacity', type: 'number' }, capacity_unit: { label: 'Capacity unit' } });
module.exports = makeService(repo, { scopeColumn: 'warehouses.unit_id', validate });
