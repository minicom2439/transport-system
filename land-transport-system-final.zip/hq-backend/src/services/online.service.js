const repo = require('../repositories/online.repository');
const { makeReadService } = require('./master-data.factory');
module.exports = makeReadService(repo, { scopeColumn: 'unit_online_status.unit_id' });
