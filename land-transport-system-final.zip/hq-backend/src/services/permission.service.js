// src/services/permission.service.js
// Resolves the full access picture for a user. Loaded once at login and
// cached on the session, so per-request checks are in-memory and cheap.
const knex = require('../db/knex');
const userRepo = require('../repositories/user.repository');

async function loadAccess(user) {
  if (user.is_super_admin) {
    return { isSuperAdmin: true, permissions: new Set(), dataScopes: [], managedSectionCodes: [] };
  }
  const [perms, scopes, managed] = await Promise.all([
    userRepo.permissions(user.id),
    userRepo.dataScopes(user.id),
    userRepo.managedSections(user.id),
  ]);
  return {
    isSuperAdmin: false,
    permissions: new Set(perms),
    dataScopes: scopes,
    managedSectionCodes: managed.map((m) => m.code),
  };
}

function can(access, sectionCode, actionCode) {
  if (!access) return false;
  if (access.isSuperAdmin) return true;
  return access.permissions.has(`${sectionCode}:${actionCode}`);
}

/**
 * Build a knex scope function restricting rows to the user's data scope.
 * Rules:
 *  - super admin or no scope rows -> no restriction (null)
 *  - unit scope   -> column IN (unit ids)
 *  - region scope -> via regionColumn if available, otherwise resolved to the
 *    units in those regions through unitColumn (so it can't be bypassed)
 *  - scoped user but nothing applicable to this query -> FAIL CLOSED (no rows)
 */
function dataScopeClause(access, { unitColumn, regionColumn } = {}) {
  if (!access || access.isSuperAdmin) return null;
  const unitIds = access.dataScopes.filter((s) => s.scope_type === 1).map((s) => s.scope_id);
  const regionIds = access.dataScopes.filter((s) => s.scope_type === 2).map((s) => s.scope_id);
  if (unitIds.length === 0 && regionIds.length === 0) return null;

  return (query) => query.where((b) => {
    let applied = false;
    if (unitColumn && unitIds.length) { b.orWhereIn(unitColumn, unitIds); applied = true; }
    if (regionColumn && regionIds.length) { b.orWhereIn(regionColumn, regionIds); applied = true; }
    if (!regionColumn && unitColumn && regionIds.length) {
      b.orWhereIn(unitColumn, knex('units').select('id').whereIn('region_id', regionIds));
      applied = true;
    }
    if (!applied) { b.whereRaw('1 = 0'); } // deny rather than leak
  });
}

module.exports = { loadAccess, can, dataScopeClause };
