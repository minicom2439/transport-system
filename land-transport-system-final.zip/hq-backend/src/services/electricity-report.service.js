const repo = require('../repositories/electricity-report.repository');
const { makeService, requireFields } = require('./master-data.factory');
const validate = (b) => requireFields(b, { unit_id: { label: 'Unit', type: 'number' }, report_date: { label: 'Date', required: true }, consumption_kwh: { label: 'Consumption (kWh)', type: 'number' }, peak_kwh: { label: 'Peak (kWh)', type: 'number' }, notes: { label: 'Notes' } });
module.exports = makeService(repo, { scopeColumn: 'electricity_reports.unit_id', validate });
