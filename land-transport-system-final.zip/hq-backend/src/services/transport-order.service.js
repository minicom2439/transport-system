const repo = require('../repositories/transport-order.repository');
const { makeReadService } = require('./master-data.factory');
module.exports = makeReadService(repo, { scopeColumn: 'transport_orders.unit_id' });
