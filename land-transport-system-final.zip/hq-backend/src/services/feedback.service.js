const repo = require('../repositories/feedback.repository');
const { makeService, requireFields } = require('./master-data.factory');
const validate = (b) => requireFields(b, { subject: { label: 'Subject' }, body: { label: 'Message', required: true }, is_read: { label: 'Read', type: 'bool' } });
module.exports = makeService(repo, { validate, createdBy: false, updatedBy: false, ownerColumn: 'submitted_by' });
