const repo = require('../repositories/vehicle.repository');
const { makeService, requireFields } = require('./master-data.factory');
const validate = (b) => requireFields(b, {
  plate_no: { label: 'Plate number', required: true },
  unit_id: { label: 'Unit', required: true, type: 'number' },
  park_id: { label: 'Park', type: 'number' },
  vehicle_type_id: { label: 'Vehicle type', type: 'number' },
  vehicle_form_id: { label: 'Form', type: 'number' },
  use_id: { label: 'Use', type: 'number' },
  technical_status_id: { label: 'Technical status', type: 'number' },
  equipment_category_id: { label: 'Equipment category', type: 'number' },
  register_category_id: { label: 'Register category', type: 'number' },
  vehicle_status_id: { label: 'Vehicle status', type: 'number' },
  structural_feature_id: { label: 'Structural feature', type: 'number' },
  seat_count: { label: 'Seats', type: 'number' },
  load_capacity: { label: 'Load capacity', type: 'number' },
  registered_on: { label: 'Registered on' },
});
module.exports = makeService(repo, { scopeColumn: 'vehicles.unit_id', validate });
