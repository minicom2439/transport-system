const repo = require('../repositories/vehicle-location.repository');
const { makeReadService } = require('./master-data.factory');
module.exports = makeReadService(repo, { scopeColumn: 'v.unit_id' });
