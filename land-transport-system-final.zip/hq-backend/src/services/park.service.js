const repo = require('../repositories/park.repository');
const { makeService, requireFields } = require('./master-data.factory');
const validate = (b) => requireFields(b, {
  name: { label: 'Name', required: true },
  unit_id: { label: 'Unit', required: true, type: 'number' },
  region_id: { label: 'Region', type: 'number' },
  code: { label: 'Code' }, capacity: { label: 'Capacity', type: 'number' },
});
module.exports = makeService(repo, { scopeColumn: 'parks.unit_id', validate });
