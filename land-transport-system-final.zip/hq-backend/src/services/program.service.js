const repo = require('../repositories/program.repository');
const { makeService, requireFields } = require('./master-data.factory');
const validate = (b) => requireFields(b, { name: { label: 'Name', required: true }, version: { label: 'Version' }, file_path: { label: 'File path' }, description: { label: 'Description' } });
module.exports = makeService(repo, { validate, createdBy: false, updatedBy: false });
