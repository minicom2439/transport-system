// Ultimate / Comprehensive Statistics: aggregate transport stats by a chosen
// axis (unit / route / region / period) — passengers & cargo, per doc.
const knex = require('../db/knex');
const { dataScopeClause } = require('./permission.service');
const AXES = {
  unit: { col: 'stat_transport_monthly.unit_id', join: (q) => q.leftJoin('units as k', 'k.id', 'stat_transport_monthly.unit_id'), name: 'k.name' },
  route: { col: 'stat_transport_monthly.route_id', join: (q) => q.leftJoin('routes as k', 'k.id', 'stat_transport_monthly.route_id'), name: 'k.name' },
  region: { col: 'stat_transport_monthly.region_id', join: (q) => q.leftJoin('regions as k', 'k.id', 'stat_transport_monthly.region_id'), name: 'k.name' },
};
async function transport(req) {
  const axisKey = ['unit', 'route', 'region', 'period'].includes(req.query.axis) ? req.query.axis : 'unit';
  const a = req.session.user.access;
  const scope = dataScopeClause({ isSuperAdmin: a.isSuperAdmin, dataScopes: a.dataScopes }, { unitColumn: 'stat_transport_monthly.unit_id' });
  let qb = knex('stat_transport_monthly');
  if (typeof scope === 'function') qb = scope(qb);
  if (req.query.year) qb = qb.where('stat_transport_monthly.stat_year', Number(req.query.year));
  const agg = [knex.raw('COALESCE(SUM(trips),0) as trips'), knex.raw('COALESCE(SUM(passengers_carried),0) as passengers'), knex.raw('COALESCE(SUM(cargo_weight),0) as cargo_weight'), knex.raw('COALESCE(SUM(revenue),0) as revenue')];
  let rows;
  if (axisKey === 'period') {
    rows = await qb.select(knex.raw("stat_transport_monthly.stat_year || '-' || substr('0' || stat_transport_monthly.stat_month, -2, 2) as key_name"), ...agg).groupByRaw('stat_transport_monthly.stat_year, stat_transport_monthly.stat_month').orderByRaw('stat_transport_monthly.stat_year, stat_transport_monthly.stat_month');
  } else {
    const ax = AXES[axisKey]; qb = ax.join(qb);
    rows = await qb.select(knex.raw(`${ax.name} as key_name`), ...agg).groupBy(ax.col).orderByRaw(`SUM(passengers_carried) DESC`);
  }
  return { axis: axisKey, data: rows.map((r) => ({ ...r, key_name: r.key_name || '—', trips: Number(r.trips), passengers: Number(r.passengers), cargo_weight: Number(r.cargo_weight), revenue: Number(r.revenue) })) };
}
module.exports = { transport };
