const repo = require('../repositories/equipment.repository');
const { makeService, requireFields } = require('./master-data.factory');
const validate = (b) => requireFields(b, { unit_id: { label: 'Unit', type: 'number' }, name: { label: 'Name', required: true }, code: { label: 'Code' }, category: { label: 'Category' }, serial_no: { label: 'Serial no' }, status: { label: 'Status' }, registered_on: { label: 'Registered on' } });
module.exports = makeService(repo, { scopeColumn: 'equipment.unit_id', validate });
