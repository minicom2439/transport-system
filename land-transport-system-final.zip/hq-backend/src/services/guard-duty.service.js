const repo = require('../repositories/guard-duty.repository');
const { makeService, requireFields } = require('./master-data.factory');
const validate = (b) => requireFields(b, { unit_id: { label: 'Unit', type: 'number' }, duty_date: { label: 'Date', required: true }, shift: { label: 'Shift' }, post: { label: 'Post' }, guard_name: { label: 'Guard' }, notes: { label: 'Notes' } });
module.exports = makeService(repo, { scopeColumn: 'guard_duties.unit_id', validate });
