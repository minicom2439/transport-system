// src/services/registration.service.js
const bcrypt = require('bcryptjs');
const reqRepo = require('../repositories/account-request.repository');
const userRepo = require('../repositories/user.repository');
const notifRepo = require('../repositories/notification.repository');
const knex = require('../db/knex');
const { ValidationError } = require('./errors');

// Public self-registration: creates a PENDING request (not a usable account).
async function register(body) {
  const fields = {};
  const username = String(body.username || '').trim();
  const full_name = String(body.full_name || '').trim();
  if (!username) fields.username = 'Username is required.';
  if (!full_name) fields.full_name = 'Full name is required.';
  if (!body.password || String(body.password).length < 6) fields.password = 'Password must be at least 6 characters.';
  if (!fields.username) {
    if (await userRepo.usernameExists(username)) fields.username = 'That username is taken.';
    else if (await reqRepo.pendingByUsername(username)) fields.username = 'A request with that username is already pending.';
  }
  if (Object.keys(fields).length) throw new ValidationError(fields);

  const password_hash = await bcrypt.hash(body.password, 10);
  const txt = (v, n) => (v ? String(v).trim().slice(0, n) : null);
  const created = await reqRepo.create({
    username, full_name, password_hash,
    position: txt(body.position, 120),
    mobile_phone: txt(body.mobile_phone, 50),
    office_phone: txt(body.office_phone, 50),
    certificate_id: txt(body.certificate_id, 120),
    note: txt(body.note, 500), status: 'pending',
  });

  // Notify all super admins so the request shows in their bell.
  const supers = await knex('users').where({ is_super_admin: 1, is_active: 1 }).pluck('id');
  if (supers.length) {
    await knex('notifications').insert(supers.map((uid) => ({
      user_id: uid, type: 'system', title: 'New account request',
      body: `${full_name} (${username}) is requesting access.`, link: '/admin/requests', is_read: 0,
    })));
  }
  return { id: created.id };
}

function listPending() { return reqRepo.listPending(); }
function approve(id, actorId) { return reqRepo.approve(id, actorId); }
function reject(id, actorId) { return reqRepo.reject(id, actorId); }

module.exports = { register, listPending, approve, reject };
