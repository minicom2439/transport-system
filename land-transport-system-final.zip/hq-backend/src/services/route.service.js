const repo = require('../repositories/route.repository');
const { makeService, requireFields } = require('./master-data.factory');
const validate = (b) => requireFields(b, {
  route_no: { label: 'Route no', required: true },
  unit_id: { label: 'Unit', required: true, type: 'number' },
  name: { label: 'Name' },
  start_region_id: { label: 'Start region', type: 'number' },
  end_region_id: { label: 'End region', type: 'number' },
  distance_km: { label: 'Distance', type: 'number' },
});
module.exports = makeService(repo, { scopeColumn: 'routes.unit_id', validate });
