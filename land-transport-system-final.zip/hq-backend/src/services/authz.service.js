// src/services/authz.service.js
// Computes a non-super actor's delegated-admin "domain":
//   - sectionIds: the sections they manage, plus all descendants (subtree)
//   - pairs: the (section:action) permissions they personally hold
// Used to enforce that a manager can only grant/revoke within their subtree and
// can never grant a right they don't themselves hold. Super admins bypass.
const knex = require('../db/knex');
const { ForbiddenError } = require('./errors');

async function loadDomain(actor) {
  if (actor.isSuperAdmin) return { all: true };

  const all = await knex('system_sections').where({ is_active: 1 }).select('id', 'parent_id');
  const childMap = new Map();
  all.forEach((s) => { const k = s.parent_id || 0; if (!childMap.has(k)) childMap.set(k, []); childMap.get(k).push(s.id); });

  const managed = await knex('section_managers').where({ user_id: actor.id }).pluck('section_id');
  const sectionIds = new Set();
  const stack = [...managed];
  while (stack.length) {
    const id = stack.pop();
    if (sectionIds.has(id)) continue;
    sectionIds.add(id);
    (childMap.get(id) || []).forEach((c) => stack.push(c));
  }

  const pairRows = await knex('user_roles as ur')
    .join('role_permissions as rp', 'rp.role_id', 'ur.role_id')
    .where('ur.user_id', actor.id).select('rp.section_id', 'rp.action_id');
  const pairs = new Set(pairRows.map((p) => `${p.section_id}:${p.action_id}`));

  return { all: false, sectionIds, pairs };
}

function pairAllowed(domain, sid, aid) {
  if (domain.all) return true;
  return domain.sectionIds.has(Number(sid)) && domain.pairs.has(`${Number(sid)}:${Number(aid)}`);
}

// A role is assignable only if every one of its permissions is within the actor's domain.
async function assertAssignableRoles(domain, roleIds) {
  if (domain.all || !roleIds || !roleIds.length) return;
  const perms = await knex('role_permissions').whereIn('role_id', roleIds).select('role_id', 'section_id', 'action_id');
  for (const p of perms) {
    if (!pairAllowed(domain, p.section_id, p.action_id)) {
      throw new ForbiddenError('You cannot assign a role whose permissions are outside your managed scope.');
    }
  }
}

module.exports = { loadDomain, pairAllowed, assertAssignableRoles };
