const repo = require('../repositories/no-accident.repository');
const { makeService, requireFields } = require('./master-data.factory');
const validate = (b) => requireFields(b, { unit_id: { label: 'Unit', type: 'number' }, as_of_date: { label: 'As of date', required: true }, accident_free_days: { label: 'Accident-free days', type: 'number' }, notes: { label: 'Notes' } });
module.exports = makeService(repo, { scopeColumn: 'no_accident_records.unit_id', validate });
