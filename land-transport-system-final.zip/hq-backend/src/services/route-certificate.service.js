const repo = require('../repositories/route-certificate.repository');
const { makeWorkflowService } = require('./workflow-resource.factory');
const { requireFields } = require('./master-data.factory');
const validate = (b) => requireFields(b, { route_id: { label: 'Route', required: true, type: 'number' }, unit_id: { label: 'Unit', required: true, type: 'number' }, certificate_no: { label: 'Certificate no' }, cert_type_id: { label: 'Type', type: 'number' }, valid_from: { label: 'Valid from' }, valid_to: { label: 'Valid to' } });
module.exports = makeWorkflowService(repo, { entity: 'route_certificate', scopeColumn: 'route_certificates.unit_id', validate });
