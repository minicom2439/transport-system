// src/services/role.service.js
const roleRepo = require('../repositories/role.repository');
const { parseListParams } = require('../repositories/list-query');
const { ValidationError, ForbiddenError } = require('./errors');
const { loadDomain, pairAllowed } = require('./authz.service');

async function list(req) {
  const params = parseListParams(req.query);
  const { data, total } = await roleRepo.search(params);
  return { data, total, page: params.page, limit: params.limit, sort: params.sort, dir: params.dir };
}

async function create(body) {
  const fields = {};
  if (!body.name || !String(body.name).trim()) fields.name = 'Name is required.';
  if (!body.code || !String(body.code).trim()) fields.code = 'Code is required.';
  if (Object.keys(fields).length) throw new ValidationError(fields);
  return roleRepo.create({ name: String(body.name).trim(), code: String(body.code).trim() });
}

async function update(id, body) {
  if (!body.name || !String(body.name).trim()) throw new ValidationError({ name: 'Name is required.' });
  return roleRepo.update(id, { name: String(body.name).trim() });
}

async function remove(id, actor) {
  const domain = await loadDomain(actor);
  if (!domain.all) {
    const perms = await roleRepo.getPermissions(id);
    if (perms.some((p) => !pairAllowed(domain, p.section_id, p.action_id))) {
      throw new ForbiddenError('This role has permissions outside your managed scope, so you cannot delete it.');
    }
  }
  return roleRepo.remove(id);
}

function getPermissions(id) { return roleRepo.getPermissions(id); }

async function setPermissions(id, body, actor) {
  const submitted = (Array.isArray(body.permissions) ? body.permissions : [])
    .filter((p) => p && p.section_id && p.action_id)
    .map((p) => ({ section_id: Number(p.section_id), action_id: Number(p.action_id) }));

  const domain = await loadDomain(actor);
  if (domain.all) return roleRepo.setPermissions(id, submitted);

  // Non-super manager: may only change pairs inside their domain; pairs outside
  // are preserved untouched, and adding an out-of-domain pair is rejected.
  const existing = await roleRepo.getPermissions(id);
  const inDomain = (p) => pairAllowed(domain, p.section_id, p.action_id);
  const existsAlready = (p) => existing.some((e) => e.section_id === p.section_id && e.action_id === p.action_id);

  const escalation = submitted.some((p) => !inDomain(p) && !existsAlready(p));
  if (escalation) throw new ForbiddenError('You tried to grant a permission outside your managed scope.');

  const keptOutside = existing.filter((p) => !inDomain(p));
  const submittedInside = submitted.filter((p) => inDomain(p));
  return roleRepo.setPermissions(id, [...keptOutside, ...submittedInside]);
}

module.exports = { list, create, update, remove, getPermissions, setPermissions };
