// src/services/meta.service.js
// Read-only reference/navigation data for the frontend.
const regionRepo = require('../repositories/region.repository');
const sectionRepo = require('../repositories/section.repository');

// Generic: turn a flat list of {id, parent_id, ...} into a nested tree.
function buildTree(rows, rootParent = null) {
  const byParent = new Map();
  for (const r of rows) {
    const key = r.parent_id == null ? 'root' : r.parent_id;
    if (!byParent.has(key)) byParent.set(key, []);
    byParent.get(key).push({ ...r, children: [] });
  }
  const attach = (node) => {
    const kids = byParent.get(node.id) || [];
    node.children = kids;
    kids.forEach(attach);
    return node;
  };
  const roots = byParent.get(rootParent == null ? 'root' : rootParent) || [];
  roots.forEach(attach);
  return roots;
}

async function regionsTree() {
  const rows = await regionRepo.allActive();
  return buildTree(rows);
}

// Navigation tree limited to what the user may view. Super admin sees all.
// For non-super users we include permitted sections AND their ancestors, so
// the tree stays navigable down to each permitted leaf.
async function navForUser(sessionUser) {
  const all = await sectionRepo.allActive();
  if (sessionUser.isSuperAdmin) return buildTree(all);

  const permitted = new Set(await sectionRepo.permittedSectionIds(sessionUser.id, 'view'));
  const byId = new Map(all.map((s) => [s.id, s]));
  const keep = new Set();
  for (const id of permitted) {
    let cur = byId.get(id);
    while (cur) { keep.add(cur.id); cur = cur.parent_id ? byId.get(cur.parent_id) : null; }
  }
  return buildTree(all.filter((s) => keep.has(s.id)));
}


async function allSectionsTree() {
  const rows = await sectionRepo.allActive();
  return buildTree(rows);
}
async function allActions() {
  const knex = require('../db/knex');
  return knex('actions').where({ is_active: 1 }).select('id', 'name', 'code').orderBy('id');
}
async function unitOptions() {
  const knex = require('../db/knex');
  return knex('units').where({ is_active: 1 }).select('id', 'name').orderBy('name');
}


async function myAdminDomain(sessionUser) {
  const { loadDomain } = require('./authz.service');
  const d = await loadDomain({ id: sessionUser.id, isSuperAdmin: sessionUser.isSuperAdmin });
  if (d.all) return { all: true };
  return { all: false, sectionIds: [...d.sectionIds], pairs: [...d.pairs] };
}


const LOOKUPS = {
  report_types: { table: 'report_types', label: 'name' },
  schedule_types: { table: 'schedule_types', label: 'name' },
  route_types: { table: 'route_types', label: 'name' },
  order_statuses: { table: 'order_statuses', label: 'name' },
  order_types: { table: 'order_types', label: 'name' },
  parks: { table: 'parks', label: 'name', active: true },
  routes: { table: 'routes', label: 'route_no', active: true },
  vehicle_types: { table: 'vehicle_types', label: 'name', active: true },
  vehicle_forms: { table: 'vehicle_forms', label: 'name', active: true },
  vehicle_uses: { table: 'vehicle_uses', label: 'name', active: true },
  technical_statuses: { table: 'technical_statuses', label: 'name', active: true },
  equipment_categories: { table: 'equipment_categories', label: 'name', active: true },
  register_categories: { table: 'register_categories', label: 'name', active: true },
  vehicle_statuses: { table: 'vehicle_statuses', label: 'name', active: true },
  structural_features: { table: 'structural_features', label: 'name', active: true },
  real_move_states: { table: 'real_move_states', label: 'name', active: true },
  safety_directives: { table: 'safety_directives', label: 'name', active: true },
  accident_severities: { table: 'accident_severities', label: 'name', active: true },
  vehicles: { table: 'vehicles', label: 'plate_no', active: true },
  finance_categories: { table: 'finance_categories', label: 'name', active: true },
  license_types: { table: 'license_types', label: 'name', active: true },
  equipment: { table: 'equipment', label: 'name', active: true },
};
async function lookup(name) {
  const cfg = LOOKUPS[name];
  if (!cfg) return [];
  const knex = require('../db/knex');
  let q = knex(cfg.table).select('id as value', `${cfg.label} as label`);
  if (cfg.active) q = q.where({ is_active: 1 });
  return q.orderBy('label');
}

module.exports = { regionsTree, navForUser, buildTree, allSectionsTree, allActions, unitOptions, myAdminDomain, lookup };
