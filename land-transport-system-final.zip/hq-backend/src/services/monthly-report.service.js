const repo = require('../repositories/monthly-report.repository');
const { makeWorkflowService } = require('./workflow-resource.factory');
const { requireFields } = require('./master-data.factory');
const validate = (b) => requireFields(b, { unit_id: { label: 'Unit', type: 'number' }, stat_year: { label: 'Year', required: true, type: 'number' }, stat_month: { label: 'Month', required: true, type: 'number' }, title: { label: 'Title', required: true }, content: { label: 'Content' } });
module.exports = makeWorkflowService(repo, { entity: 'monthly_report', scopeColumn: 'monthly_reports.unit_id', validate, commandColumn: 'command' });
