const repo = require('../repositories/accident.repository');
const { makeService, requireFields } = require('./master-data.factory');
const validate = (b) => requireFields(b, { unit_id: { label: 'Unit', required: true, type: 'number' }, occurred_at: { label: 'Occurred at', required: true }, vehicle_id: { label: 'Vehicle', type: 'number' }, severity_id: { label: 'Severity', type: 'number' }, status_id: { label: 'Status', type: 'number' }, location: { label: 'Location' }, description: { label: 'Description' } });
module.exports = makeService(repo, { scopeColumn: 'accident_notifications.unit_id', validate, updatedBy: false });
