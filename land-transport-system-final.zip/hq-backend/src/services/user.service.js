// src/services/user.service.js
const bcrypt = require('bcryptjs');
const userRepo = require('../repositories/user.repository');
const { parseListParams } = require('../repositories/list-query');
const { ValidationError, ForbiddenError } = require('./errors');
const { loadDomain, assertAssignableRoles } = require('./authz.service');
const userRepoRef = require('../repositories/user.repository');

async function list(req) {
  const params = parseListParams(req.query);
  const { data, total } = await userRepo.searchAdmin(params);
  return { data, total, page: params.page, limit: params.limit, sort: params.sort, dir: params.dir };
}

function getOne(id) { return userRepo.findFull(id); }

function normalizeAssignments(body) {
  const roleIds = Array.isArray(body.roleIds) ? body.roleIds.map(Number) : [];
  const managedSectionIds = Array.isArray(body.managedSectionIds) ? body.managedSectionIds.map(Number) : [];
  const scopes = [];
  (body.scopeUnitIds || []).forEach((id) => scopes.push({ scope_type: 1, scope_id: Number(id) }));
  (body.scopeRegionIds || []).forEach((id) => scopes.push({ scope_type: 2, scope_id: Number(id) }));
  return { roleIds, managedSectionIds, scopes };
}

async function create(body, actor) {
  const fields = {};
  if (!body.username || !String(body.username).trim()) fields.username = 'Username is required.';
  if (!body.full_name || !String(body.full_name).trim()) fields.full_name = 'Full name is required.';
  if (!body.password || String(body.password).length < 6) fields.password = 'Password must be at least 6 characters.';
  if (!fields.username && await userRepo.usernameExists(String(body.username).trim())) fields.username = 'That username is taken.';
  if (Object.keys(fields).length) throw new ValidationError(fields);

  const domain = await loadDomain(actor);
  if (!domain.all) {
    if (body.is_super_admin === true) throw new ForbiddenError('Only a super admin can grant super-admin access.');
    if (Array.isArray(body.managedSectionIds) && body.managedSectionIds.length) throw new ForbiddenError('Only a super admin can assign section managers.');
    await assertAssignableRoles(domain, (body.roleIds || []).map(Number));
  }

  const password_hash = await bcrypt.hash(body.password, 10);
  const data = {
    username: String(body.username).trim(),
    full_name: String(body.full_name).trim(),
    password_hash,
    is_active: body.is_active === false ? 0 : 1,
    is_super_admin: body.is_super_admin === true ? 1 : 0,
  };
  const id = await userRepo.createWithAssignments(data, normalizeAssignments(body), actor.id);
  return userRepo.findFull(id);
}

async function update(id, body, actor) {
  const fields = {};
  if (!body.full_name || !String(body.full_name).trim()) fields.full_name = 'Full name is required.';
  if (body.password && String(body.password).length < 6) fields.password = 'Password must be at least 6 characters.';
  if (Object.keys(fields).length) throw new ValidationError(fields);

  const domain = await loadDomain(actor);
  if (!domain.all) {
    const target = await userRepoRef.findFull(id);
    if (target && target.is_super_admin) throw new ForbiddenError('You cannot modify a super-admin account.');
    if (body.is_super_admin === true) throw new ForbiddenError('Only a super admin can grant super-admin access.');
    if (Array.isArray(body.managedSectionIds) && body.managedSectionIds.length) throw new ForbiddenError('Only a super admin can assign section managers.');
    await assertAssignableRoles(domain, (body.roleIds || []).map(Number));
  }

  const data = {
    full_name: String(body.full_name).trim(),
    is_active: body.is_active === false ? 0 : 1,
    is_super_admin: body.is_super_admin === true ? 1 : 0,
  };
  if (body.password) data.password_hash = await bcrypt.hash(body.password, 10);
  await userRepo.updateWithAssignments(id, data, normalizeAssignments(body), actor.id);
  return userRepo.findFull(id);
}

async function remove(id, actor) {
  if (!actor.isSuperAdmin) {
    const target = await userRepo.findFull(id);
    if (target && target.is_super_admin) throw new ForbiddenError('You cannot deactivate a super-admin account.');
  }
  return userRepo.remove(id);
}

module.exports = { list, getOne, create, update, remove };
