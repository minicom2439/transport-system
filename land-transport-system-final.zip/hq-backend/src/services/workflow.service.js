// src/services/workflow.service.js
// Reusable approval lifecycle over the approvals + approval_history tables.
// States: draft -> submitted -> approved | rejected ; (draft|submitted) -> cancelled ;
//         rejected -> draft (reopen on edit). Every transition is recorded.
const knex = require('../db/knex');
const { ValidationError } = require('./errors');

let cache = null;
async function statusMap() {
  if (!cache) {
    const rows = await knex('approval_statuses').select('id', 'code');
    cache = { byCode: {}, byId: {} };
    rows.forEach((r) => { cache.byCode[r.code] = r.id; cache.byId[r.id] = r.code; });
  }
  return cache;
}

const ALLOWED = { submit: ['draft'], approve: ['submitted'], reject: ['submitted'], cancel: ['draft', 'submitted'], reopen: ['rejected'] };
const TARGET = { submit: 'submitted', approve: 'approved', reject: 'rejected', cancel: 'cancelled', reopen: 'draft' };

async function createDraft(entityType, entityId, userId) {
  const st = await statusMap();
  const [id] = await knex('approvals').insert({ entity_type: entityType, entity_id: entityId, status_id: st.byCode.draft });
  await knex('approval_history').insert({ approval_id: id, from_status_id: null, to_status_id: st.byCode.draft, changed_by: userId, comment: 'created' });
  return id;
}

async function currentStatus(approvalId) {
  const st = await statusMap();
  const ap = await knex('approvals').where({ id: approvalId }).first();
  return ap ? st.byId[ap.status_id] : null;
}

async function transition(approvalId, action, userId, comment) {
  const st = await statusMap();
  const ap = await knex('approvals').where({ id: approvalId }).first();
  if (!ap) throw new ValidationError({ _: 'No approval record.' });
  const cur = st.byId[ap.status_id];
  if (!ALLOWED[action] || !ALLOWED[action].includes(cur)) {
    throw new ValidationError({ _: `Cannot ${action} a ${cur} item.` });
  }
  const toId = st.byCode[TARGET[action]];
  await knex.transaction(async (trx) => {
    const patch = { status_id: toId, comment: comment || null };
    if (action === 'submit') { patch.submitted_by = userId; patch.submitted_at = knex.fn.now(); }
    if (action === 'approve' || action === 'reject') { patch.decided_by = userId; patch.decided_at = knex.fn.now(); }
    await trx('approvals').where({ id: approvalId }).update(patch);
    await trx('approval_history').insert({ approval_id: approvalId, from_status_id: ap.status_id, to_status_id: toId, changed_by: userId, comment: comment || null });
  });
  return TARGET[action];
}

function history(approvalId) {
  return knex('approval_history as h')
    .leftJoin('approval_statuses as fs', 'fs.id', 'h.from_status_id')
    .leftJoin('approval_statuses as ts', 'ts.id', 'h.to_status_id')
    .leftJoin('users as u', 'u.id', 'h.changed_by')
    .where('h.approval_id', approvalId).orderBy('h.changed_at', 'asc')
    .select('h.changed_at', 'fs.code as from_status', 'ts.code as to_status', 'u.full_name as by', 'h.comment');
}

module.exports = { createDraft, transition, currentStatus, history };
