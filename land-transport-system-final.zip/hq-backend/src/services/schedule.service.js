const repo = require('../repositories/schedule.repository');
const { makeService, requireFields } = require('./master-data.factory');
const validate = (b) => requireFields(b, { schedule_type_id: { label: 'Schedule type', required: true, type: 'number' }, unit_id: { label: 'Unit', type: 'number' }, park_id: { label: 'Park', type: 'number' }, route_id: { label: 'Route', type: 'number' }, schedule_date: { label: 'Date' }, start_time: { label: 'Start time' }, end_time: { label: 'End time' }, notes: { label: 'Notes' } });
module.exports = makeService(repo, { scopeColumn: 'schedules.unit_id', validate, updatedBy: false }); // no updated_by col
