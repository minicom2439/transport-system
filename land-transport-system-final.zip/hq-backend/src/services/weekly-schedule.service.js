const repo = require('../repositories/weekly-schedule.repository');
const { makeService, requireFields } = require('./master-data.factory');
const validate = (b) => requireFields(b, { unit_id: { label: 'Unit', type: 'number' }, week_start: { label: 'Week start', required: true }, title: { label: 'Title', required: true }, content: { label: 'Content' } });
module.exports = makeService(repo, { scopeColumn: 'weekly_schedules.unit_id', validate });
