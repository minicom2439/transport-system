// src/services/transport.service.js
const transportRepo = require('../repositories/transport.repository');
const { dataScopeClause } = require('./permission.service');

async function statsByUnit(req) {
  const a = req.session.user.access;
  const access = { isSuperAdmin: a.isSuperAdmin, dataScopes: a.dataScopes };
  const scope = dataScopeClause(access, { unitColumn: 'tr.unit_id' });
  return transportRepo.statsByUnit({
    dateFrom: req.query.from,
    dateTo: req.query.to,
    scope,
  });
}

module.exports = { statsByUnit };
