// src/repositories/transport.repository.js
const BaseRepository = require('./base.repository');
const knex = require('../db/knex');

class TransportRepository extends BaseRepository {
  constructor() {
    super('transport_records', { timestamps: true }); // hard table, no soft delete
  }

  // Aggregated statistics over the per-vehicle-per-day grain.
  // Demonstrates the roll-up queries the analytics screens rely on.
  async statsByUnit({ dateFrom, dateTo, scope } = {}) {
    let q = knex('transport_records as tr')
      .leftJoin('units as u', 'u.id', 'tr.unit_id')
      .select('tr.unit_id', 'u.name as unit_name')
      .sum({ trips: 'tr.trips' })
      .sum({ distance_km: 'tr.distance_km' })
      .sum({ passengers_carried: 'tr.passengers_carried' })
      .sum({ cargo_weight: 'tr.cargo_weight' })
      .sum({ revenue: 'tr.revenue' })
      .groupBy('tr.unit_id', 'u.name');
    if (dateFrom) q = q.where('tr.record_date', '>=', dateFrom);
    if (dateTo) q = q.where('tr.record_date', '<=', dateTo);
    if (typeof scope === 'function') q = scope(q);
    return q;
  }
}

module.exports = new TransportRepository();
