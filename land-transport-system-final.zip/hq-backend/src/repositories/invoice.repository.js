const BaseRepository = require('./base.repository');
const { applyFiltersAndSearch, applySort } = require('./list-query');
const CFG = { columns: { invoice_no: 'invoices.invoice_no', unit: 'u.name', unit_id: 'invoices.unit_id', issued_at: 'invoices.issued_at', amount: 'invoices.amount' }, sortable: ['invoice_no', 'unit', 'issued_at', 'amount'], filterable: { invoice_no: ['contains'], unit_id: ['eq'] }, searchable: ['invoices.invoice_no', 'u.name'], defaultSort: 'issued_at' };
class R extends BaseRepository {
  constructor() { super('invoices', { softDelete: false, timestamps: true }); }
  base() { return this.qb().leftJoin('units as u', 'u.id', 'invoices.unit_id').leftJoin('order_statuses as os', 'os.id', 'invoices.status_id'); }
  async search(params, scope) { let qb = this.base(); if (typeof scope === 'function') qb = scope(qb); applyFiltersAndSearch(qb, params, CFG); const c = await qb.clone().clearSelect().clearOrder().count({ n: '*' }).first(); qb.select('invoices.*', 'u.name as unit_name', 'os.name as status_name'); applySort(qb, params, CFG); qb.limit(params.limit).offset(params.offset); return { data: await qb, total: Number(c.n) }; }
}
module.exports = new R();
