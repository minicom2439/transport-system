const BaseRepository = require('./base.repository');
const { applyFiltersAndSearch, applySort } = require('./list-query');
const CFG = { columns: { unit: 'u.name', unit_id: 'electricity_reports.unit_id', report_date: 'electricity_reports.report_date', consumption_kwh: 'electricity_reports.consumption_kwh' }, sortable: ['unit','report_date','consumption_kwh'], filterable: { unit_id: ['eq'] }, searchable: ['u.name'], defaultSort: 'report_date' };
class R extends BaseRepository {
  constructor() { super('electricity_reports', { softDelete: true, timestamps: true }); }
  base() { return this.qb().leftJoin('units as u','u.id','electricity_reports.unit_id').where('electricity_reports.is_active', 1); }
  async search(params, scope) { let qb = this.base(); if (typeof scope === 'function') qb = scope(qb); applyFiltersAndSearch(qb, params, CFG); const c = await qb.clone().clearSelect().clearOrder().count({ n: '*' }).first(); qb.select('electricity_reports.*','u.name as unit_name'); applySort(qb, params, CFG); qb.limit(params.limit).offset(params.offset); return { data: await qb, total: Number(c.n) }; }
}
module.exports = new R();
