const BaseRepository = require('./base.repository');
const { applyFiltersAndSearch, applySort } = require('./list-query');
const CFG = { columns: { title: 'weekly_schedules.title', unit: 'u.name', unit_id: 'weekly_schedules.unit_id', week_start: 'weekly_schedules.week_start' }, sortable: ['title','unit','week_start'], filterable: { unit_id: ['eq'] }, searchable: ['weekly_schedules.title','u.name'], defaultSort: 'week_start' };
class R extends BaseRepository {
  constructor() { super('weekly_schedules', { softDelete: true, timestamps: true }); }
  base() { return this.qb().leftJoin('units as u','u.id','weekly_schedules.unit_id').where('weekly_schedules.is_active', 1); }
  async search(params, scope) { let qb = this.base(); if (typeof scope === 'function') qb = scope(qb); applyFiltersAndSearch(qb, params, CFG); const c = await qb.clone().clearSelect().clearOrder().count({ n: '*' }).first(); qb.select('weekly_schedules.*','u.name as unit_name'); applySort(qb, params, CFG); qb.limit(params.limit).offset(params.offset); return { data: await qb, total: Number(c.n) }; }
}
module.exports = new R();
