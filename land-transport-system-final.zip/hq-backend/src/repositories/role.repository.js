// src/repositories/role.repository.js
const BaseRepository = require('./base.repository');
const knex = require('../db/knex');
const { applyFiltersAndSearch, applySort } = require('./list-query');

const LIST_CONFIG = {
  columns: { name: 'roles.name', code: 'roles.code' },
  sortable: ['name', 'code'],
  filterable: { name: ['contains'], code: ['contains'] },
  searchable: ['roles.name', 'roles.code'],
  defaultSort: 'name',
};

class RoleRepository extends BaseRepository {
  constructor() { super('roles', { softDelete: true, timestamps: true }); }

  async search(params) {
    let qb = this.qb().where('roles.is_active', 1);
    applyFiltersAndSearch(qb, params, LIST_CONFIG);
    const countRow = await qb.clone().clearSelect().clearOrder().count({ n: '*' }).first();
    const total = Number(countRow.n);
    qb.select('roles.*').leftJoin('role_permissions as rp', 'rp.role_id', 'roles.id')
      .countDistinct('rp.id as perm_count').groupBy('roles.id');
    applySort(qb, params, LIST_CONFIG);
    qb.limit(params.limit).offset(params.offset);
    const data = await qb;
    return { data, total };
  }

  getPermissions(roleId) { return knex('role_permissions').where({ role_id: roleId }).select('section_id', 'action_id'); }

  async setPermissions(roleId, pairs) {
    return knex.transaction(async (trx) => {
      await trx('role_permissions').where({ role_id: roleId }).del();
      if (pairs.length) {
        await trx('role_permissions').insert(pairs.map((p) => ({ role_id: roleId, section_id: p.section_id, action_id: p.action_id })));
      }
    });
  }
}

module.exports = new RoleRepository();
