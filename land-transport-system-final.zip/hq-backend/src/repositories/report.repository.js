const BaseRepository = require('./base.repository');
const { applyFiltersAndSearch, applySort } = require('./list-query');
const CFG = { columns: { title: 'reports.title', type: 'rt.name', report_date: 'reports.report_date', status: 'ast.code' }, sortable: ['title', 'type', 'report_date', 'status'], filterable: { title: ['contains'], status: ['eq'] }, searchable: ['reports.title', 'rt.name'], defaultSort: 'report_date' };
class R extends BaseRepository {
  constructor() { super('reports', { softDelete: false, timestamps: true }); }
  base() { return this.qb().leftJoin('report_types as rt', 'rt.id', 'reports.report_type_id').leftJoin('approvals as ap', 'ap.id', 'reports.approval_id').leftJoin('approval_statuses as ast', 'ast.id', 'ap.status_id'); }
  async search(params) { const qb = this.base(); applyFiltersAndSearch(qb, params, CFG); const c = await qb.clone().clearSelect().clearOrder().count({ n: '*' }).first(); qb.select('reports.*', 'rt.name as report_type_name', 'ast.code as status', 'ast.name as status_name'); applySort(qb, params, CFG); qb.limit(params.limit).offset(params.offset); return { data: await qb, total: Number(c.n) }; }
  detail(id) { return this.base().clearSelect().select('reports.*', 'rt.name as report_type_name', 'ast.code as status').where('reports.id', id).first(); }
}
module.exports = new R();
