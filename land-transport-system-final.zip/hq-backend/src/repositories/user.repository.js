// src/repositories/user.repository.js
const BaseRepository = require('./base.repository');
const knex = require('../db/knex');
const { applyFiltersAndSearch, applySort } = require('./list-query');

const LIST_CONFIG = {
  columns: { username: 'users.username', full_name: 'users.full_name' },
  sortable: ['username', 'full_name'],
  filterable: { username: ['contains'], full_name: ['contains'] },
  searchable: ['users.username', 'users.full_name'],
  defaultSort: 'username',
};

class UserRepository extends BaseRepository {
  constructor() { super('users', { softDelete: true, timestamps: true }); }

  // ---- auth-side (unchanged) -------------------------------------------
  findByUsername(username) { return this.qb().where({ username, is_active: 1 }).first(); }
  updateLastLogin(id) { return this.qb().where({ id }).update({ last_login_at: knex.fn.now() }); }

  async permissions(userId) {
    const rows = await knex('user_roles as ur')
      .join('role_permissions as rp', 'rp.role_id', 'ur.role_id')
      .join('system_sections as s', 's.id', 'rp.section_id')
      .join('actions as a', 'a.id', 'rp.action_id')
      .where('ur.user_id', userId)
      .select('s.code as section', 'a.code as action');
    return rows.map((r) => `${r.section}:${r.action}`);
  }
  dataScopes(userId) { return knex('user_data_scopes').where({ user_id: userId }).select('scope_type', 'scope_id'); }
  managedSections(userId) {
    return knex('section_managers as sm').join('system_sections as s', 's.id', 'sm.section_id')
      .where('sm.user_id', userId).select('s.id', 's.code');
  }

  // ---- admin-side ------------------------------------------------------
  async searchAdmin(params) {
    let qb = this.qb().where('users.is_active', 1);
    applyFiltersAndSearch(qb, params, LIST_CONFIG);
    const countRow = await qb.clone().clearSelect().clearOrder().count({ n: '*' }).first();
    const total = Number(countRow.n);
    qb.select('users.id', 'users.username', 'users.full_name', 'users.is_active', 'users.is_super_admin', 'users.last_login_at');
    applySort(qb, params, LIST_CONFIG);
    qb.limit(params.limit).offset(params.offset);
    const data = await qb;
    // attach role names
    const ids = data.map((u) => u.id);
    if (ids.length) {
      const roles = await knex('user_roles as ur').join('roles as r', 'r.id', 'ur.role_id')
        .whereIn('ur.user_id', ids).select('ur.user_id', 'r.id as role_id', 'r.name');
      const byUser = new Map();
      roles.forEach((r) => { if (!byUser.has(r.user_id)) byUser.set(r.user_id, []); byUser.get(r.user_id).push(r.name); });
      data.forEach((u) => { u.role_names = byUser.get(u.id) || []; });
    }
    return { data, total };
  }

  async findFull(id) {
    const user = await this.qb().where({ id })
      .select('id', 'username', 'full_name', 'is_active', 'is_super_admin').first();
    if (!user) return null;
    const [roles, scopes, managed] = await Promise.all([
      knex('user_roles').where({ user_id: id }).pluck('role_id'),
      knex('user_data_scopes').where({ user_id: id }).select('scope_type', 'scope_id'),
      knex('section_managers').where({ user_id: id }).pluck('section_id'),
    ]);
    return { ...user, roleIds: roles, scopes, managedSectionIds: managed };
  }

  async createWithAssignments(data, { roleIds = [], scopes = [], managedSectionIds = [] }, actorId) {
    return knex.transaction(async (trx) => {
      const [id] = await trx('users').insert({ ...data, created_by: actorId });
      if (roleIds.length) await trx('user_roles').insert(roleIds.map((r) => ({ user_id: id, role_id: r })));
      if (scopes.length) await trx('user_data_scopes').insert(scopes.map((s) => ({ user_id: id, scope_type: s.scope_type, scope_id: s.scope_id })));
      if (managedSectionIds.length) await trx('section_managers').insert(managedSectionIds.map((s) => ({ user_id: id, section_id: s, created_by: actorId })));
      return id;
    });
  }

  async updateWithAssignments(id, data, { roleIds, scopes, managedSectionIds }, actorId) {
    return knex.transaction(async (trx) => {
      await trx('users').where({ id }).update({ ...data, updated_by: actorId, updated_at: knex.fn.now() });
      if (roleIds) {
        await trx('user_roles').where({ user_id: id }).del();
        if (roleIds.length) await trx('user_roles').insert(roleIds.map((r) => ({ user_id: id, role_id: r })));
      }
      if (scopes) {
        await trx('user_data_scopes').where({ user_id: id }).del();
        if (scopes.length) await trx('user_data_scopes').insert(scopes.map((s) => ({ user_id: id, scope_type: s.scope_type, scope_id: s.scope_id })));
      }
      if (managedSectionIds) {
        await trx('section_managers').where({ user_id: id }).del();
        if (managedSectionIds.length) await trx('section_managers').insert(managedSectionIds.map((s) => ({ user_id: id, section_id: s, created_by: actorId })));
      }
    });
  }

  setPassword(id, password_hash) { return this.qb().where({ id }).update({ password_hash, updated_at: knex.fn.now() }); }
  usernameExists(username) { return this.qb().where({ username }).first(); }
}

module.exports = new UserRepository();
