const BaseRepository = require('./base.repository');
const { applyFiltersAndSearch, applySort } = require('./list-query');
const CFG = { columns: { title: 'tech_data_submissions.title', unit: 'u.name', unit_id: 'tech_data_submissions.unit_id', submitted_at: 'tech_data_submissions.submitted_at', status: 'ast.code' }, sortable: ['title', 'unit', 'submitted_at', 'status'], filterable: { title: ['contains'], unit_id: ['eq'], status: ['eq'] }, searchable: ['tech_data_submissions.title', 'u.name'], defaultSort: 'submitted_at' };
class R extends BaseRepository {
  constructor() { super('tech_data_submissions', { softDelete: false, timestamps: false }); }
  base() { return this.qb().leftJoin('units as u', 'u.id', 'tech_data_submissions.unit_id').leftJoin('users as su', 'su.id', 'tech_data_submissions.submitted_by').leftJoin('approvals as ap', 'ap.id', 'tech_data_submissions.approval_id').leftJoin('approval_statuses as ast', 'ast.id', 'ap.status_id'); }
  async search(params, scope) { let qb = this.base(); if (typeof scope === 'function') qb = scope(qb); applyFiltersAndSearch(qb, params, CFG); const c = await qb.clone().clearSelect().clearOrder().count({ n: '*' }).first(); qb.select('tech_data_submissions.*', 'u.name as unit_name', 'su.full_name as submitted_by_name', 'ast.code as status', 'ast.name as status_name'); applySort(qb, params, CFG); qb.limit(params.limit).offset(params.offset); return { data: await qb, total: Number(c.n) }; }
  detail(id) { return this.base().clearSelect().select('tech_data_submissions.*', 'u.name as unit_name', 'ast.code as status').where('tech_data_submissions.id', id).first(); }
}
module.exports = new R();
