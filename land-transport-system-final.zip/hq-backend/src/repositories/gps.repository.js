const BaseRepository = require('./base.repository');
const { applyFiltersAndSearch, applySort } = require('./list-query');
const CFG = { columns: { device_no: 'gps_devices.device_no', vehicle: 'v.plate_no', unit: 'u.name', unit_id: 'v.unit_id', installed_on: 'gps_devices.installed_on' }, sortable: ['device_no', 'vehicle', 'unit', 'installed_on'], filterable: { device_no: ['contains'], unit_id: ['eq'] }, searchable: ['gps_devices.device_no', 'v.plate_no', 'u.name'], defaultSort: 'device_no' };
class R extends BaseRepository {
  constructor() { super('gps_devices', { softDelete: true, timestamps: true }); }
  base() { return this.qb().leftJoin('vehicles as v', 'v.id', 'gps_devices.vehicle_id').leftJoin('units as u', 'u.id', 'v.unit_id').where('gps_devices.is_active', 1); }
  async search(params, scope) { let qb = this.base(); if (typeof scope === 'function') qb = scope(qb); applyFiltersAndSearch(qb, params, CFG); const c = await qb.clone().clearSelect().clearOrder().count({ n: '*' }).first(); qb.select('gps_devices.*', 'v.plate_no as vehicle_plate', 'u.name as unit_name'); applySort(qb, params, CFG); qb.limit(params.limit).offset(params.offset); return { data: await qb, total: Number(c.n) }; }
}
module.exports = new R();
