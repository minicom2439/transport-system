const BaseRepository = require('./base.repository');
const { applyFiltersAndSearch, applySort } = require('./list-query');
const CFG = { columns: { title: 'notices.title', is_published: 'notices.is_published', published_at: 'notices.published_at' }, sortable: ['title', 'is_published', 'published_at'], filterable: { title: ['contains'], is_published: ['eq'] }, searchable: ['notices.title', 'notices.body'], defaultSort: 'published_at' };
class R extends BaseRepository {
  constructor() { super('notices', { softDelete: false, timestamps: true }); }
  base() { return this.qb().leftJoin('users as a', 'a.id', 'notices.author_id'); }
  async search(params) { const qb = this.base(); applyFiltersAndSearch(qb, params, CFG); const c = await qb.clone().clearSelect().clearOrder().count({ n: '*' }).first(); qb.select('notices.*', 'a.full_name as author_name'); applySort(qb, params, CFG); qb.limit(params.limit).offset(params.offset); return { data: await qb, total: Number(c.n) }; }
}
module.exports = new R();
