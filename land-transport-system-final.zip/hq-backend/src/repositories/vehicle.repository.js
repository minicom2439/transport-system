const BaseRepository = require('./base.repository');
const { applyFiltersAndSearch, applySort } = require('./list-query');
const CFG = {
  columns: { plate_no: 'vehicles.plate_no', unit: 'u.name', unit_id: 'vehicles.unit_id', park: 'p.name', park_id: 'vehicles.park_id', type: 'vt.name', status: 'vs.name', seat_count: 'vehicles.seat_count' },
  sortable: ['plate_no', 'unit', 'park', 'type', 'status', 'seat_count'],
  filterable: { plate_no: ['contains', 'eq'], unit_id: ['eq'], park_id: ['eq'], seat_count: ['gte', 'lte', 'between'] },
  searchable: ['vehicles.plate_no', 'u.name', 'vt.name'],
  defaultSort: 'plate_no',
};
class VehicleRepository extends BaseRepository {
  constructor() { super('vehicles', { softDelete: true, timestamps: true }); }
  base() {
    return this.qb()
      .leftJoin('units as u', 'u.id', 'vehicles.unit_id')
      .leftJoin('parks as p', 'p.id', 'vehicles.park_id')
      .leftJoin('vehicle_types as vt', 'vt.id', 'vehicles.vehicle_type_id')
      .leftJoin('vehicle_statuses as vs', 'vs.id', 'vehicles.vehicle_status_id')
      .where('vehicles.is_active', 1);
  }
  async search(params, scope) {
    let qb = this.base(); if (typeof scope === 'function') qb = scope(qb);
    applyFiltersAndSearch(qb, params, CFG);
    const c = await qb.clone().clearSelect().clearOrder().count({ n: '*' }).first();
    qb.select('vehicles.*', 'u.name as unit_name', 'p.name as park_name', 'vt.name as vehicle_type_name', 'vs.name as vehicle_status_name');
    applySort(qb, params, CFG); qb.limit(params.limit).offset(params.offset);
    return { data: await qb, total: Number(c.n) };
  }
}
module.exports = new VehicleRepository();
