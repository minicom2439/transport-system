const BaseRepository = require('./base.repository');
const { applyFiltersAndSearch, applySort } = require('./list-query');
const CFG = { columns: { name: 'equipment.name', code: 'equipment.code', unit: 'u.name', unit_id: 'equipment.unit_id', category: 'equipment.category', status: 'equipment.status' }, sortable: ['name','code','unit','category'], filterable: { name: ['contains'], unit_id: ['eq'] }, searchable: ['equipment.name','equipment.code','equipment.serial_no','u.name'], defaultSort: 'name' };
class R extends BaseRepository {
  constructor() { super('equipment', { softDelete: true, timestamps: true }); }
  base() { return this.qb().leftJoin('units as u','u.id','equipment.unit_id').where('equipment.is_active', 1); }
  async search(params, scope) { let qb = this.base(); if (typeof scope === 'function') qb = scope(qb); applyFiltersAndSearch(qb, params, CFG); const c = await qb.clone().clearSelect().clearOrder().count({ n: '*' }).first(); qb.select('equipment.*','u.name as unit_name'); applySort(qb, params, CFG); qb.limit(params.limit).offset(params.offset); return { data: await qb, total: Number(c.n) }; }
}
module.exports = new R();
