const BaseRepository = require('./base.repository');
const { applyFiltersAndSearch, applySort } = require('./list-query');
const CFG = { columns: { order_no: 'transport_orders.order_no', unit: 'u.name', unit_id: 'transport_orders.unit_id', status: 'os.code', type: 'ot.name', order_date: 'transport_orders.order_date' }, sortable: ['order_no', 'unit', 'status', 'order_date'], filterable: { order_no: ['contains'], unit_id: ['eq'], status: ['eq'] }, searchable: ['transport_orders.order_no', 'u.name'], defaultSort: 'order_date' };
class R extends BaseRepository {
  constructor() { super('transport_orders', { softDelete: false, timestamps: true }); }
  base() { return this.qb().leftJoin('units as u', 'u.id', 'transport_orders.unit_id').leftJoin('order_statuses as os', 'os.id', 'transport_orders.status_id').leftJoin('order_types as ot', 'ot.id', 'transport_orders.order_type_id').leftJoin('regions as og', 'og.id', 'transport_orders.origin_region_id').leftJoin('regions as dg', 'dg.id', 'transport_orders.dest_region_id'); }
  async search(params, scope) { let qb = this.base(); if (typeof scope === 'function') qb = scope(qb); applyFiltersAndSearch(qb, params, CFG); const c = await qb.clone().clearSelect().clearOrder().count({ n: '*' }).first(); qb.select('transport_orders.*', 'u.name as unit_name', 'os.name as status_name', 'os.code as status', 'ot.name as order_type_name', 'og.name as origin_region_name', 'dg.name as dest_region_name'); applySort(qb, params, CFG); qb.limit(params.limit).offset(params.offset); return { data: await qb, total: Number(c.n) }; }
}
module.exports = new R();
