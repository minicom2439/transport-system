// src/repositories/base.repository.js
// The reusable data-access template. ALL database access goes through
// repositories like this one — services and routes never touch knex directly.
// That isolation is what makes the SQLite -> MySQL switch a config change.
const knex = require('../db/knex');

class BaseRepository {
  /**
   * @param {string} table
   * @param {object} [opts]
   * @param {boolean} [opts.softDelete=false]  use is_active flag instead of hard delete
   * @param {boolean} [opts.timestamps=false]  table has updated_at to bump on update
   */
  constructor(table, opts = {}) {
    this.table = table;
    this.softDelete = opts.softDelete === true;
    this.timestamps = opts.timestamps === true;
  }

  qb() { return knex(this.table); }

  async findById(id) {
    return this.qb().where({ id }).first();
  }

  /**
   * List with optional equality filters, pagination, and a data-scope clause.
   * NOTE: filter KEYS are used as SQL identifiers, so callers must pass only
   * trusted/whitelisted column names (services do — never raw req.query).
   */
  async list(filters = {}, options = {}) {
    const { limit = 50, offset = 0, orderBy = 'id', scope } = options;
    let q = this.qb();
    if (this.softDelete) q = q.where(`${this.table}.is_active`, 1);
    Object.entries(filters).forEach(([k, v]) => {
      if (v !== undefined && v !== null && v !== '') q = q.where(k, v);
    });
    if (typeof scope === 'function') q = scope(q);
    return q.orderBy(orderBy).limit(limit).offset(offset);
  }

  async count(filters = {}, scope) {
    let q = this.qb();
    if (this.softDelete) q = q.where(`${this.table}.is_active`, 1);
    Object.entries(filters).forEach(([k, v]) => {
      if (v !== undefined && v !== null && v !== '') q = q.where(k, v);
    });
    if (typeof scope === 'function') q = scope(q);
    const row = await q.count({ n: '*' }).first();
    return Number(row.n);
  }

  async create(data) {
    const [id] = await this.qb().insert(data);
    return this.findById(id);
  }

  async update(id, data) {
    // Explicitly bump updated_at so dev (SQLite) and prod (MySQL) behave the
    // same; MySQL would auto-update it, SQLite would not.
    const payload = this.timestamps ? { ...data, updated_at: knex.fn.now() } : data;
    await this.qb().where({ id }).update(payload);
    return this.findById(id);
  }

  async remove(id) {
    if (this.softDelete) {
      const payload = this.timestamps
        ? { is_active: 0, updated_at: knex.fn.now() }
        : { is_active: 0 };
      return this.qb().where({ id }).update(payload);
    }
    return this.qb().where({ id }).del();
  }

  get knex() { return knex; }
}

module.exports = BaseRepository;
