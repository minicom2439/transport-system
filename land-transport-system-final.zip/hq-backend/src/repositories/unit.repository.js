// src/repositories/unit.repository.js
const BaseRepository = require('./base.repository');
const { applyFiltersAndSearch, applySort } = require('./list-query');

// Whitelist: logical field -> real column, plus what's sortable/filterable/searchable.
const LIST_CONFIG = {
  columns: {
    name: 'units.name', code: 'units.code',
    region: 'r.name', region_id: 'units.region_id',
    classification: 'uc.name',
  },
  sortable: ['name', 'code', 'region', 'classification'],
  filterable: { name: ['contains', 'eq'], code: ['contains', 'eq'], region_id: ['eq'] },
  searchable: ['units.name', 'units.code', 'r.name'],
  defaultSort: 'name',
};

class UnitRepository extends BaseRepository {
  constructor() { super('units', { softDelete: true, timestamps: true }); }

  base() {
    return this.qb()
      .leftJoin('regions as r', 'r.id', 'units.region_id')
      .leftJoin('unit_types as ut', 'ut.id', 'units.unit_type_id')
      .leftJoin('unit_classifications as uc', 'uc.id', 'units.classification_id')
      .where('units.is_active', 1);
  }

  // Server-side sort + filter + search + pagination, with optional data scope.
  async search(params, scope) {
    let qb = this.base();
    if (typeof scope === 'function') qb = scope(qb);
    applyFiltersAndSearch(qb, params, LIST_CONFIG);

    const countRow = await qb.clone().clearSelect().clearOrder().count({ n: '*' }).first();
    const total = Number(countRow.n);

    qb.select('units.*', 'r.name as region_name', 'ut.name as unit_type_name', 'uc.name as classification_name');
    applySort(qb, params, LIST_CONFIG);
    qb.limit(params.limit).offset(params.offset);
    const data = await qb;
    return { data, total };
  }
}

module.exports = new UnitRepository();
