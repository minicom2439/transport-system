const BaseRepository = require('./base.repository');
const { applyFiltersAndSearch, applySort } = require('./list-query');
const CFG = { columns: { certificate_no: 'route_certificates.certificate_no', route: 'rt.route_no', unit: 'u.name', unit_id: 'route_certificates.unit_id', status: 'ast.code', cert_type_id: 'route_certificates.cert_type_id' }, sortable: ['certificate_no', 'route', 'unit', 'status'], filterable: { certificate_no: ['contains'], unit_id: ['eq'], status: ['eq'], cert_type_id: ['eq'] }, searchable: ['route_certificates.certificate_no', 'rt.route_no', 'u.name'], defaultSort: 'certificate_no' };
class R extends BaseRepository {
  constructor() { super('route_certificates', { softDelete: true, timestamps: true }); }
  base() { return this.qb().leftJoin('routes as rt', 'rt.id', 'route_certificates.route_id').leftJoin('units as u', 'u.id', 'route_certificates.unit_id').leftJoin('approvals as ap', 'ap.id', 'route_certificates.approval_id').leftJoin('approval_statuses as ast', 'ast.id', 'ap.status_id').leftJoin('route_types as ct', 'ct.id', 'route_certificates.cert_type_id').where('route_certificates.is_active', 1); }
  async search(params, scope) { let qb = this.base(); if (typeof scope === 'function') qb = scope(qb); applyFiltersAndSearch(qb, params, CFG); const c = await qb.clone().clearSelect().clearOrder().count({ n: '*' }).first(); qb.select('route_certificates.*', 'rt.route_no as route_no', 'u.name as unit_name', 'ast.code as status', 'ast.name as status_name', 'ct.name as cert_type_name'); applySort(qb, params, CFG); qb.limit(params.limit).offset(params.offset); return { data: await qb, total: Number(c.n) }; }
  detail(id) { return this.base().clearSelect().select('route_certificates.*', 'rt.route_no as route_no', 'u.name as unit_name', 'ast.code as status').where('route_certificates.id', id).first(); }
}
module.exports = new R();
