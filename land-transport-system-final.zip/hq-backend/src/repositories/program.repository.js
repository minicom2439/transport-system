const BaseRepository = require('./base.repository');
const { applyFiltersAndSearch, applySort } = require('./list-query');
const CFG = { columns: { name: 'programs.name', version: 'programs.version' }, sortable: ['name', 'version'], filterable: { name: ['contains'] }, searchable: ['programs.name', 'programs.description'], defaultSort: 'name' };
class R extends BaseRepository {
  constructor() { super('programs', { softDelete: true, timestamps: true }); }
  base() { return this.qb().where('programs.is_active', 1); }
  async search(params) { const qb = this.base(); applyFiltersAndSearch(qb, params, CFG); const c = await qb.clone().clearSelect().clearOrder().count({ n: '*' }).first(); qb.select('programs.*'); applySort(qb, params, CFG); qb.limit(params.limit).offset(params.offset); return { data: await qb, total: Number(c.n) }; }
}
module.exports = new R();
