// src/repositories/section.repository.js
const BaseRepository = require('./base.repository');
const knex = require('../db/knex');
const config = require('../config');

class SectionRepository extends BaseRepository {
  constructor() { super('system_sections', { softDelete: true }); }

  allActive() {
    return this.qb().where({ is_active: 1, system_code: config.systemCode })
      .select('id', 'parent_id', 'name', 'code', 'node_type', 'sort_order', 'system_code')
      .orderBy(['sort_order', 'name']);
  }

  // Section ids where the user holds a given action (default 'view'), via roles.
  async permittedSectionIds(userId, actionCode = 'view') {
    const rows = await knex('user_roles as ur')
      .join('role_permissions as rp', 'rp.role_id', 'ur.role_id')
      .join('actions as a', 'a.id', 'rp.action_id')
      .where('ur.user_id', userId)
      .where('a.code', actionCode)
      .distinct('rp.section_id as id');
    return rows.map((r) => r.id);
  }
}

module.exports = new SectionRepository();
