const BaseRepository = require('./base.repository');
const { applyFiltersAndSearch, applySort } = require('./list-query');
const CFG = { columns: { unit: 'u.name', unit_id: 'no_accident_records.unit_id', as_of_date: 'no_accident_records.as_of_date', accident_free_days: 'no_accident_records.accident_free_days' }, sortable: ['unit','as_of_date','accident_free_days'], filterable: { unit_id: ['eq'] }, searchable: ['u.name'], defaultSort: 'as_of_date' };
class R extends BaseRepository {
  constructor() { super('no_accident_records', { softDelete: true, timestamps: true }); }
  base() { return this.qb().leftJoin('units as u','u.id','no_accident_records.unit_id').where('no_accident_records.is_active', 1); }
  async search(params, scope) { let qb = this.base(); if (typeof scope === 'function') qb = scope(qb); applyFiltersAndSearch(qb, params, CFG); const c = await qb.clone().clearSelect().clearOrder().count({ n: '*' }).first(); qb.select('no_accident_records.*','u.name as unit_name'); applySort(qb, params, CFG); qb.limit(params.limit).offset(params.offset); return { data: await qb, total: Number(c.n) }; }
}
module.exports = new R();
