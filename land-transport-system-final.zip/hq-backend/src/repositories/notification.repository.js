// src/repositories/notification.repository.js
const BaseRepository = require('./base.repository');

class NotificationRepository extends BaseRepository {
  constructor() { super('notifications'); }

  listForUser(userId, limit = 20) {
    return this.qb().where({ user_id: userId }).orderBy('created_at', 'desc').limit(limit);
  }
  async unreadCount(userId) {
    const row = await this.qb().where({ user_id: userId, is_read: 0 }).count({ n: '*' }).first();
    return Number(row.n);
  }
  markRead(id, userId) {
    return this.qb().where({ id, user_id: userId }).update({ is_read: 1 });
  }
  markAllRead(userId) {
    return this.qb().where({ user_id: userId, is_read: 0 }).update({ is_read: 1 });
  }
}

module.exports = new NotificationRepository();
