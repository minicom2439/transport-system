const BaseRepository = require('./base.repository');
const { applyFiltersAndSearch, applySort } = require('./list-query');
const CFG = { columns: { question: 'faqs.question', sort_order: 'faqs.sort_order' }, sortable: ['question', 'sort_order'], filterable: { question: ['contains'] }, searchable: ['faqs.question', 'faqs.answer'], defaultSort: 'sort_order' };
class R extends BaseRepository {
  constructor() { super('faqs', { softDelete: true, timestamps: true }); }
  base() { return this.qb().where('faqs.is_active', 1); }
  async search(params) { const qb = this.base(); applyFiltersAndSearch(qb, params, CFG); const c = await qb.clone().clearSelect().clearOrder().count({ n: '*' }).first(); qb.select('faqs.*'); applySort(qb, params, CFG); qb.limit(params.limit).offset(params.offset); return { data: await qb, total: Number(c.n) }; }
}
module.exports = new R();
