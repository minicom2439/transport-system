// src/repositories/audit.repository.js
const BaseRepository = require('./base.repository');

class AuditRepository extends BaseRepository {
  constructor() {
    super('audit_log');
  }

  write({ userId, action, entityType, entityId, before, after, host }) {
    return this.qb().insert({
      user_id: userId || null,
      action,
      entity_type: entityType,
      entity_id: entityId || null,
      before_json: before ? JSON.stringify(before) : null,
      after_json: after ? JSON.stringify(after) : null,
      ip_or_host: host || null,
    });
  }
}

module.exports = new AuditRepository();
