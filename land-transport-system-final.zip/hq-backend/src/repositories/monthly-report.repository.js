const BaseRepository = require('./base.repository');
const { applyFiltersAndSearch, applySort } = require('./list-query');
const CFG = { columns: { title: 'monthly_reports.title', unit: 'u.name', unit_id: 'monthly_reports.unit_id', stat_year: 'monthly_reports.stat_year', status: 'ast.code' }, sortable: ['title', 'unit', 'stat_year', 'status'], filterable: { unit_id: ['eq'], stat_year: ['eq'], status: ['eq'] }, searchable: ['monthly_reports.title', 'u.name'], defaultSort: 'stat_year' };
class R extends BaseRepository {
  constructor() { super('monthly_reports', { softDelete: true, timestamps: true }); }
  base() { return this.qb().leftJoin('units as u', 'u.id', 'monthly_reports.unit_id').leftJoin('approvals as ap', 'ap.id', 'monthly_reports.approval_id').leftJoin('approval_statuses as ast', 'ast.id', 'ap.status_id').where('monthly_reports.is_active', 1); }
  async search(params, scope) { let qb = this.base(); if (typeof scope === 'function') qb = scope(qb); applyFiltersAndSearch(qb, params, CFG); const c = await qb.clone().clearSelect().clearOrder().count({ n: '*' }).first(); qb.select('monthly_reports.*', 'u.name as unit_name', 'ast.code as status', 'ast.name as status_name'); applySort(qb, params, CFG); qb.limit(params.limit).offset(params.offset); return { data: await qb, total: Number(c.n) }; }
  detail(id) { return this.base().clearSelect().select('monthly_reports.*', 'u.name as unit_name', 'ast.code as status').where('monthly_reports.id', id).first(); }
}
module.exports = new R();
