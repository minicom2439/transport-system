// src/repositories/account-request.repository.js
const BaseRepository = require('./base.repository');
const knex = require('../db/knex');

class AccountRequestRepository extends BaseRepository {
  constructor() { super('account_requests'); }

  pendingByUsername(username) { return this.qb().where({ username, status: 'pending' }).first(); }
  listPending() { return this.qb().where({ status: 'pending' }).orderBy('requested_at', 'desc'); }

  // Approve: create the real user and mark the request, atomically.
  async approve(id, actorId) {
    return knex.transaction(async (trx) => {
      const reqRow = await trx('account_requests').where({ id, status: 'pending' }).first();
      if (!reqRow) throw new Error('Request not found or already decided.');
      const clash = await trx('users').where({ username: reqRow.username }).first();
      if (clash) throw new Error('Username is now taken; cannot approve.');
      const [userId] = await trx('users').insert({
        username: reqRow.username, full_name: reqRow.full_name, password_hash: reqRow.password_hash,
        position: reqRow.position, mobile_phone: reqRow.mobile_phone, office_phone: reqRow.office_phone,
        certificate_id: reqRow.certificate_id, unit_id: reqRow.unit_id || null,
        is_active: 1, is_super_admin: 0, created_by: actorId,
      });
      await trx('account_requests').where({ id }).update({
        status: 'approved', decided_by: actorId, decided_at: knex.fn.now(), created_user_id: userId,
      });
      return userId;
    });
  }

  reject(id, actorId) {
    return this.qb().where({ id, status: 'pending' }).update({ status: 'rejected', decided_by: actorId, decided_at: knex.fn.now() });
  }
}

module.exports = new AccountRequestRepository();
