const BaseRepository = require('./base.repository');
const { applyFiltersAndSearch, applySort } = require('./list-query');
const CFG = { columns: { title: 'business_daily_reports.title', department: 'business_daily_reports.department', unit: 'u.name', unit_id: 'business_daily_reports.unit_id', report_date: 'business_daily_reports.report_date', status: 'ast.code' }, sortable: ['title', 'department', 'unit', 'report_date', 'status'], filterable: { department: ['eq'], unit_id: ['eq'], status: ['eq'] }, searchable: ['business_daily_reports.title', 'u.name'], defaultSort: 'report_date' };
class R extends BaseRepository {
  constructor() { super('business_daily_reports', { softDelete: true, timestamps: true }); }
  base() { return this.qb().leftJoin('units as u', 'u.id', 'business_daily_reports.unit_id').leftJoin('approvals as ap', 'ap.id', 'business_daily_reports.approval_id').leftJoin('approval_statuses as ast', 'ast.id', 'ap.status_id').where('business_daily_reports.is_active', 1); }
  async search(params, scope) { let qb = this.base(); if (typeof scope === 'function') qb = scope(qb); applyFiltersAndSearch(qb, params, CFG); const c = await qb.clone().clearSelect().clearOrder().count({ n: '*' }).first(); qb.select('business_daily_reports.*', 'u.name as unit_name', 'ast.code as status', 'ast.name as status_name'); applySort(qb, params, CFG); qb.limit(params.limit).offset(params.offset); return { data: await qb, total: Number(c.n) }; }
  detail(id) { return this.base().clearSelect().select('business_daily_reports.*', 'u.name as unit_name', 'ast.code as status').where('business_daily_reports.id', id).first(); }
}
module.exports = new R();
