// src/repositories/operating-condition.repository.js
const BaseRepository = require('./base.repository');
const { applyFiltersAndSearch, applySort } = require('./list-query');

const LIST_CONFIG = {
  columns: {
    title: 'operating_conditions.title', unit: 'u.name', unit_id: 'operating_conditions.unit_id',
    status: 'ast.code',
  },
  sortable: ['title', 'unit', 'status'],
  filterable: { title: ['contains'], unit_id: ['eq'], status: ['eq'] },
  searchable: ['operating_conditions.title', 'u.name'],
  defaultSort: 'title',
};

class OperatingConditionRepository extends BaseRepository {
  constructor() { super('operating_conditions', { softDelete: true, timestamps: true }); }

  base() {
    return this.qb()
      .leftJoin('units as u', 'u.id', 'operating_conditions.unit_id')
      .leftJoin('approvals as ap', 'ap.id', 'operating_conditions.approval_id')
      .leftJoin('approval_statuses as ast', 'ast.id', 'ap.status_id')
      .where('operating_conditions.is_active', 1);
  }

  async search(params, scope) {
    let qb = this.base();
    if (typeof scope === 'function') qb = scope(qb);
    applyFiltersAndSearch(qb, params, LIST_CONFIG);
    const countRow = await qb.clone().clearSelect().clearOrder().count({ n: '*' }).first();
    const total = Number(countRow.n);
    qb.select('operating_conditions.*', 'u.name as unit_name', 'ast.code as status', 'ast.name as status_name', 'ap.comment as approval_comment');
    applySort(qb, params, LIST_CONFIG);
    qb.limit(params.limit).offset(params.offset);
    const data = await qb;
    return { data, total };
  }

  detail(id) {
    return this.base().clearSelect()
      .select('operating_conditions.*', 'u.name as unit_name', 'ast.code as status')
      .where('operating_conditions.id', id).first();
  }
}

module.exports = new OperatingConditionRepository();
