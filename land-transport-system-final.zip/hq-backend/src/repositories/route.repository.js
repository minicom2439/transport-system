const BaseRepository = require('./base.repository');
const { applyFiltersAndSearch, applySort } = require('./list-query');
const LIST_CONFIG = {
  columns: { route_no: 'routes.route_no', name: 'routes.name', unit: 'u.name', unit_id: 'routes.unit_id', distance_km: 'routes.distance_km' },
  sortable: ['route_no', 'name', 'unit', 'distance_km'],
  filterable: { route_no: ['contains'], name: ['contains'], unit_id: ['eq'] },
  searchable: ['routes.route_no', 'routes.name', 'u.name'],
  defaultSort: 'route_no',
};
class RouteRepository extends BaseRepository {
  constructor() { super('routes', { softDelete: true, timestamps: true }); }
  base() {
    return this.qb()
      .leftJoin('units as u', 'u.id', 'routes.unit_id')
      .leftJoin('route_types as rt', 'rt.id', 'routes.route_type_id')
      .leftJoin('regions as sr', 'sr.id', 'routes.start_region_id')
      .leftJoin('regions as er', 'er.id', 'routes.end_region_id')
      .where('routes.is_active', 1);
  }
  async search(params, scope) {
    let qb = this.base(); if (typeof scope === 'function') qb = scope(qb);
    applyFiltersAndSearch(qb, params, LIST_CONFIG);
    const c = await qb.clone().clearSelect().clearOrder().count({ n: '*' }).first();
    qb.select('routes.*', 'u.name as unit_name', 'rt.name as route_type_name', 'sr.name as start_region_name', 'er.name as end_region_name');
    applySort(qb, params, LIST_CONFIG);
    qb.limit(params.limit).offset(params.offset);
    return { data: await qb, total: Number(c.n) };
  }
}
module.exports = new RouteRepository();
