const BaseRepository = require('./base.repository');
const { applyFiltersAndSearch, applySort } = require('./list-query');
const CFG = { columns: { name: 'transport_indicators.name', code: 'transport_indicators.code', unit_of_measure: 'transport_indicators.unit_of_measure' }, sortable: ['name', 'code'], filterable: { name: ['contains'] }, searchable: ['transport_indicators.name', 'transport_indicators.code'], defaultSort: 'name' };
class R extends BaseRepository {
  constructor() { super('transport_indicators', { softDelete: true, timestamps: true }); }
  base() { return this.qb().where('transport_indicators.is_active', 1); }
  async search(params) { const qb = this.base(); applyFiltersAndSearch(qb, params, CFG); const c = await qb.clone().clearSelect().clearOrder().count({ n: '*' }).first(); qb.select('transport_indicators.*'); applySort(qb, params, CFG); qb.limit(params.limit).offset(params.offset); return { data: await qb, total: Number(c.n) }; }
}
module.exports = new R();
