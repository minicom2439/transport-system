// src/repositories/list-query.js
// Generic, WHITELISTED list query helpers: sorting, filtering, and global
// search. Client field names are mapped through a per-resource config to real
// (possibly joined) columns; anything not whitelisted is ignored — so client
// input can never inject column names or operators.

const ALLOWED_OPS = new Set(['eq', 'contains', 'gte', 'lte', 'between', 'in']);

// Parse Express req.query into a normalized params object.
function parseListParams(query = {}) {
  const page = Math.max(0, Number(query.page) || 0);
  const limit = Math.min(200, Math.max(1, Number(query.limit) || 25));
  const sort = query.sort || null;
  const dir = query.dir === 'desc' ? 'desc' : 'asc';
  const q = (query.q || '').toString().trim();
  let filters = [];
  if (query.filters) {
    try { const p = JSON.parse(query.filters); if (Array.isArray(p)) filters = p; } catch { filters = []; }
  }
  return { page, limit, offset: page * limit, sort, dir, q, filters };
}

// Apply filters + global search to a query builder (NOT sort/limit, so the
// result can be cloned for an accurate COUNT).
function applyFiltersAndSearch(qb, params, config) {
  const { filters = [], q } = params;
  for (const f of filters) {
    if (!f || typeof f !== 'object') continue;
    const col = config.columns[f.field];
    const allowedOps = config.filterable && config.filterable[f.field];
    if (!col || !allowedOps || !allowedOps.includes(f.op) || !ALLOWED_OPS.has(f.op)) continue;
    const v = f.value;
    if (v === '' || v === null || v === undefined) continue;
    if (f.op === 'contains') qb.where(col, 'like', `%${v}%`);
    else if (f.op === 'eq') qb.where(col, v);
    else if (f.op === 'gte') qb.where(col, '>=', v);
    else if (f.op === 'lte') qb.where(col, '<=', v);
    else if (f.op === 'between' && Array.isArray(v) && v.length === 2) qb.whereBetween(col, [v[0], v[1]]);
    else if (f.op === 'in' && Array.isArray(v)) qb.whereIn(col, v);
  }
  if (q && Array.isArray(config.searchable) && config.searchable.length) {
    qb.where((b) => {
      config.searchable.forEach((c, i) => {
        if (i === 0) b.where(c, 'like', `%${q}%`);
        else b.orWhere(c, 'like', `%${q}%`);
      });
    });
  }
  return qb;
}

// Apply sorting (whitelisted) with a default fallback.
function applySort(qb, params, config) {
  const { sort, dir } = params;
  if (sort && config.sortable.includes(sort)) {
    qb.orderBy(config.columns[sort] || sort, dir === 'desc' ? 'desc' : 'asc');
  } else if (config.defaultSort) {
    qb.orderBy(config.columns[config.defaultSort] || config.defaultSort, 'asc');
  }
  return qb;
}

module.exports = { parseListParams, applyFiltersAndSearch, applySort };
