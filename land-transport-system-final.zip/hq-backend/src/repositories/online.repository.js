const BaseRepository = require('./base.repository');
const { applyFiltersAndSearch, applySort } = require('./list-query');
const CFG = { columns: { unit: 'u.name', unit_id: 'unit_online_status.unit_id', is_online: 'unit_online_status.is_online', last_seen_at: 'unit_online_status.last_seen_at' }, sortable: ['unit', 'is_online', 'last_seen_at'], filterable: { unit_id: ['eq'], is_online: ['eq'] }, searchable: ['u.name'], defaultSort: 'unit' };
class R extends BaseRepository {
  constructor() { super('unit_online_status', { softDelete: false, timestamps: false }); }
  base() { return this.qb().leftJoin('units as u', 'u.id', 'unit_online_status.unit_id'); }
  async search(params, scope) { let qb = this.base(); if (typeof scope === 'function') qb = scope(qb); applyFiltersAndSearch(qb, params, CFG); const c = await qb.clone().clearSelect().clearOrder().count({ n: '*' }).first(); qb.select('unit_online_status.*', 'u.name as unit_name'); applySort(qb, params, CFG); qb.limit(params.limit).offset(params.offset); return { data: await qb, total: Number(c.n) }; }
}
module.exports = new R();
