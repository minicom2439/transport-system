const BaseRepository = require('./base.repository');
const { applyFiltersAndSearch, applySort } = require('./list-query');
const CFG = { columns: { title: 'effort_plans.title', unit: 'u.name', unit_id: 'effort_plans.unit_id', period: 'effort_plans.period', status: 'ast.code' }, sortable: ['title', 'unit', 'period', 'status'], filterable: { unit_id: ['eq'], status: ['eq'] }, searchable: ['effort_plans.title', 'u.name'], defaultSort: 'period' };
class R extends BaseRepository {
  constructor() { super('effort_plans', { softDelete: true, timestamps: true }); }
  base() { return this.qb().leftJoin('units as u', 'u.id', 'effort_plans.unit_id').leftJoin('approvals as ap', 'ap.id', 'effort_plans.approval_id').leftJoin('approval_statuses as ast', 'ast.id', 'ap.status_id').where('effort_plans.is_active', 1); }
  async search(params, scope) { let qb = this.base(); if (typeof scope === 'function') qb = scope(qb); applyFiltersAndSearch(qb, params, CFG); const c = await qb.clone().clearSelect().clearOrder().count({ n: '*' }).first(); qb.select('effort_plans.*', 'u.name as unit_name', 'ast.code as status', 'ast.name as status_name'); applySort(qb, params, CFG); qb.limit(params.limit).offset(params.offset); return { data: await qb, total: Number(c.n) }; }
  detail(id) { return this.base().clearSelect().select('effort_plans.*', 'u.name as unit_name', 'ast.code as status').where('effort_plans.id', id).first(); }
}
module.exports = new R();
