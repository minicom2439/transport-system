const BaseRepository = require('./base.repository');
const { applyFiltersAndSearch, applySort } = require('./list-query');
const CFG = { columns: { license_no: 'licenses.license_no', unit: 'u.name', unit_id: 'licenses.unit_id', type: 'lt.name', status: 'ast.code' }, sortable: ['license_no', 'unit', 'type', 'status'], filterable: { license_no: ['contains'], unit_id: ['eq'], status: ['eq'] }, searchable: ['licenses.license_no', 'u.name', 'lt.name'], defaultSort: 'license_no' };
class R extends BaseRepository {
  constructor() { super('licenses', { softDelete: true, timestamps: true }); }
  base() { return this.qb().leftJoin('units as u', 'u.id', 'licenses.unit_id').leftJoin('license_types as lt', 'lt.id', 'licenses.license_type_id').leftJoin('approvals as ap', 'ap.id', 'licenses.approval_id').leftJoin('approval_statuses as ast', 'ast.id', 'ap.status_id').where('licenses.is_active', 1); }
  async search(params, scope) { let qb = this.base(); if (typeof scope === 'function') qb = scope(qb); applyFiltersAndSearch(qb, params, CFG); const c = await qb.clone().clearSelect().clearOrder().count({ n: '*' }).first(); qb.select('licenses.*', 'u.name as unit_name', 'lt.name as license_type_name', 'ast.code as status', 'ast.name as status_name'); applySort(qb, params, CFG); qb.limit(params.limit).offset(params.offset); return { data: await qb, total: Number(c.n) }; }
  detail(id) { return this.base().clearSelect().select('licenses.*', 'u.name as unit_name', 'lt.name as license_type_name', 'ast.code as status').where('licenses.id', id).first(); }
}
module.exports = new R();
