const BaseRepository = require('./base.repository');
const { applyFiltersAndSearch, applySort } = require('./list-query');
const LIST_CONFIG = {
  columns: { full_name: 'staff.full_name', staff_no: 'staff.staff_no', position: 'staff.position', unit: 'u.name', unit_id: 'staff.unit_id' },
  sortable: ['full_name', 'staff_no', 'position', 'unit'],
  filterable: { full_name: ['contains'], position: ['contains'], unit_id: ['eq'] },
  searchable: ['staff.full_name', 'staff.staff_no', 'staff.position', 'u.name'],
  defaultSort: 'full_name',
};
class StaffRepository extends BaseRepository {
  constructor() { super('staff', { softDelete: true, timestamps: true }); }
  base() { return this.qb().leftJoin('units as u', 'u.id', 'staff.unit_id').where('staff.is_active', 1); }
  async search(params, scope) {
    let qb = this.base(); if (typeof scope === 'function') qb = scope(qb);
    applyFiltersAndSearch(qb, params, LIST_CONFIG);
    const c = await qb.clone().clearSelect().clearOrder().count({ n: '*' }).first();
    qb.select('staff.*', 'u.name as unit_name'); applySort(qb, params, LIST_CONFIG);
    qb.limit(params.limit).offset(params.offset);
    return { data: await qb, total: Number(c.n) };
  }
}
module.exports = new StaffRepository();
