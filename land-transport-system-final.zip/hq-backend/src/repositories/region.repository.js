// src/repositories/region.repository.js
const BaseRepository = require('./base.repository');

class RegionRepository extends BaseRepository {
  constructor() { super('regions', { softDelete: true }); }

  allActive() {
    return this.qb().where({ is_active: 1 })
      .select('id', 'parent_id', 'name', 'level', 'code')
      .orderBy(['level', 'name']);
  }
}

module.exports = new RegionRepository();
