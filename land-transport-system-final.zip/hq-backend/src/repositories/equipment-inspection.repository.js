const BaseRepository = require('./base.repository');
const { applyFiltersAndSearch, applySort } = require('./list-query');
const CFG = { columns: { inspection_date: 'equipment_inspections.inspection_date', equipment: 'e.name', unit: 'u.name', unit_id: 'equipment_inspections.unit_id', inspection_type: 'equipment_inspections.inspection_type', result: 'equipment_inspections.result' }, sortable: ['inspection_date','equipment','unit','result'], filterable: { unit_id: ['eq'] }, searchable: ['e.name','u.name','equipment_inspections.inspector'], defaultSort: 'inspection_date' };
class R extends BaseRepository {
  constructor() { super('equipment_inspections', { softDelete: true, timestamps: true }); }
  base() { return this.qb().leftJoin('equipment as e','e.id','equipment_inspections.equipment_id').leftJoin('units as u','u.id','equipment_inspections.unit_id').where('equipment_inspections.is_active', 1); }
  async search(params, scope) { let qb = this.base(); if (typeof scope === 'function') qb = scope(qb); applyFiltersAndSearch(qb, params, CFG); const c = await qb.clone().clearSelect().clearOrder().count({ n: '*' }).first(); qb.select('equipment_inspections.*','e.name as equipment_name','u.name as unit_name'); applySort(qb, params, CFG); qb.limit(params.limit).offset(params.offset); return { data: await qb, total: Number(c.n) }; }
}
module.exports = new R();
