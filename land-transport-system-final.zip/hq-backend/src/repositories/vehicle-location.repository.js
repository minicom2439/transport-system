const BaseRepository = require('./base.repository');
const { applyFiltersAndSearch, applySort } = require('./list-query');
const CFG = { columns: { vehicle: 'v.plate_no', unit: 'u.name', unit_id: 'v.unit_id', recorded_at: 'vehicle_locations.recorded_at', speed: 'vehicle_locations.speed' }, sortable: ['recorded_at', 'vehicle', 'speed'], filterable: { unit_id: ['eq'] }, searchable: ['v.plate_no', 'u.name'], defaultSort: 'recorded_at' };
class R extends BaseRepository {
  constructor() { super('vehicle_locations', { softDelete: false, timestamps: false }); }
  base() { return this.qb().leftJoin('vehicles as v', 'v.id', 'vehicle_locations.vehicle_id').leftJoin('units as u', 'u.id', 'v.unit_id'); }
  async search(params, scope) { let qb = this.base(); if (typeof scope === 'function') qb = scope(qb); applyFiltersAndSearch(qb, params, CFG); const c = await qb.clone().clearSelect().clearOrder().count({ n: '*' }).first(); qb.select('vehicle_locations.*', 'v.plate_no as vehicle_plate', 'u.name as unit_name'); applySort(qb, params, CFG); qb.limit(params.limit).offset(params.offset); return { data: await qb, total: Number(c.n) }; }
}
module.exports = new R();
