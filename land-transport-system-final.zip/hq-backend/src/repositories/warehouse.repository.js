const BaseRepository = require('./base.repository');
const { applyFiltersAndSearch, applySort } = require('./list-query');
const CFG = { columns: { name: 'warehouses.name', code: 'warehouses.code', unit: 'u.name', unit_id: 'warehouses.unit_id', region: 'r.name', capacity: 'warehouses.capacity' }, sortable: ['name', 'code', 'unit', 'region', 'capacity'], filterable: { name: ['contains'], unit_id: ['eq'] }, searchable: ['warehouses.name', 'warehouses.code', 'u.name'], defaultSort: 'name' };
class R extends BaseRepository {
  constructor() { super('warehouses', { softDelete: true, timestamps: true }); }
  base() { return this.qb().leftJoin('units as u', 'u.id', 'warehouses.unit_id').leftJoin('regions as r', 'r.id', 'warehouses.region_id').where('warehouses.is_active', 1); }
  async search(params, scope) { let qb = this.base(); if (typeof scope === 'function') qb = scope(qb); applyFiltersAndSearch(qb, params, CFG); const c = await qb.clone().clearSelect().clearOrder().count({ n: '*' }).first(); qb.select('warehouses.*', 'u.name as unit_name', 'r.name as region_name'); applySort(qb, params, CFG); qb.limit(params.limit).offset(params.offset); return { data: await qb, total: Number(c.n) }; }
}
module.exports = new R();
