const BaseRepository = require('./base.repository');
const { applyFiltersAndSearch, applySort } = require('./list-query');
const LIST_CONFIG = {
  columns: { name: 'parks.name', code: 'parks.code', unit: 'u.name', unit_id: 'parks.unit_id', region: 'r.name', region_id: 'parks.region_id', capacity: 'parks.capacity' },
  sortable: ['name', 'code', 'unit', 'region', 'capacity'],
  filterable: { name: ['contains'], unit_id: ['eq'], region_id: ['eq'] },
  searchable: ['parks.name', 'parks.code', 'u.name'],
  defaultSort: 'name',
};
class ParkRepository extends BaseRepository {
  constructor() { super('parks', { softDelete: true, timestamps: true }); }
  base() { return this.qb().leftJoin('units as u', 'u.id', 'parks.unit_id').leftJoin('regions as r', 'r.id', 'parks.region_id').where('parks.is_active', 1); }
  async search(params, scope) {
    let qb = this.base(); if (typeof scope === 'function') qb = scope(qb);
    applyFiltersAndSearch(qb, params, LIST_CONFIG);
    const c = await qb.clone().clearSelect().clearOrder().count({ n: '*' }).first();
    qb.select('parks.*', 'u.name as unit_name', 'r.name as region_name'); applySort(qb, params, LIST_CONFIG);
    qb.limit(params.limit).offset(params.offset);
    return { data: await qb, total: Number(c.n) };
  }
}
module.exports = new ParkRepository();
