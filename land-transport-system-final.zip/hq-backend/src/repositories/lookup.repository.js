// src/repositories/lookup.repository.js — generic CRUD for standard lookup tables
// (name, code, description, is_active). The table name is validated by the
// service against a whitelist before reaching here.
const knex = require('../db/knex');
function lookupRepo(table) {
  return {
    list: () => knex(table).where({ is_active: 1 }).select('id', 'name', 'code', 'description').orderBy('name'),
    create: (d) => knex(table).insert(d).then(([id]) => knex(table).where({ id }).first()),
    update: (id, d) => knex(table).where({ id }).update(d).then(() => knex(table).where({ id }).first()),
    remove: (id) => knex(table).where({ id }).update({ is_active: 0 }),
  };
}
module.exports = { lookupRepo };
