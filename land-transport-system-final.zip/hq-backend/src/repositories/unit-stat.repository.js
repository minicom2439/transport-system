const BaseRepository = require('./base.repository');
const { applyFiltersAndSearch, applySort } = require('./list-query');
const CFG = { columns: { unit: 'u.name', unit_id: 'stat_transport_monthly.unit_id', stat_year: 'stat_transport_monthly.stat_year', stat_month: 'stat_transport_monthly.stat_month', trips: 'stat_transport_monthly.trips', revenue: 'stat_transport_monthly.revenue' }, sortable: ['unit', 'stat_year', 'stat_month', 'trips', 'revenue'], filterable: { unit_id: ['eq'], stat_year: ['eq'] }, searchable: ['u.name'], defaultSort: 'stat_year' };
class R extends BaseRepository {
  constructor() { super('stat_transport_monthly', { softDelete: false, timestamps: false }); }
  base() { return this.qb().leftJoin('units as u', 'u.id', 'stat_transport_monthly.unit_id'); }
  async search(params, scope) { let qb = this.base(); if (typeof scope === 'function') qb = scope(qb); applyFiltersAndSearch(qb, params, CFG); const c = await qb.clone().clearSelect().clearOrder().count({ n: '*' }).first(); qb.select('stat_transport_monthly.*', 'u.name as unit_name'); applySort(qb, params, CFG); qb.limit(params.limit).offset(params.offset); return { data: await qb, total: Number(c.n) }; }
}
module.exports = new R();
