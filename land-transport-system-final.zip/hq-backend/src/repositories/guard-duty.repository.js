const BaseRepository = require('./base.repository');
const { applyFiltersAndSearch, applySort } = require('./list-query');
const CFG = { columns: { duty_date: 'guard_duties.duty_date', unit: 'u.name', unit_id: 'guard_duties.unit_id', shift: 'guard_duties.shift', post: 'guard_duties.post', guard_name: 'guard_duties.guard_name' }, sortable: ['duty_date', 'unit', 'shift', 'post'], filterable: { unit_id: ['eq'], shift: ['eq'] }, searchable: ['guard_duties.post', 'guard_duties.guard_name', 'u.name'], defaultSort: 'duty_date' };
class R extends BaseRepository {
  constructor() { super('guard_duties', { softDelete: true, timestamps: true }); }
  base() { return this.qb().leftJoin('units as u', 'u.id', 'guard_duties.unit_id').where('guard_duties.is_active', 1); }
  async search(params, scope) { let qb = this.base(); if (typeof scope === 'function') qb = scope(qb); applyFiltersAndSearch(qb, params, CFG); const c = await qb.clone().clearSelect().clearOrder().count({ n: '*' }).first(); qb.select('guard_duties.*', 'u.name as unit_name'); applySort(qb, params, CFG); qb.limit(params.limit).offset(params.offset); return { data: await qb, total: Number(c.n) }; }
}
module.exports = new R();
