const BaseRepository = require('./base.repository');
const { applyFiltersAndSearch, applySort } = require('./list-query');
const CFG = { columns: { subject: 'feedback.subject', is_read: 'feedback.is_read', submitted_at: 'feedback.submitted_at' }, sortable: ['subject', 'is_read', 'submitted_at'], filterable: { is_read: ['eq'] }, searchable: ['feedback.subject', 'feedback.body'], defaultSort: 'submitted_at' };
class R extends BaseRepository {
  constructor() { super('feedback', { softDelete: false, timestamps: false }); }
  base() { return this.qb().leftJoin('users as u', 'u.id', 'feedback.submitted_by'); }
  async search(params) { const qb = this.base(); applyFiltersAndSearch(qb, params, CFG); const c = await qb.clone().clearSelect().clearOrder().count({ n: '*' }).first(); qb.select('feedback.*', 'u.full_name as submitted_by_name'); applySort(qb, params, CFG); qb.limit(params.limit).offset(params.offset); return { data: await qb, total: Number(c.n) }; }
}
module.exports = new R();
