const BaseRepository = require('./base.repository');
const { applyFiltersAndSearch, applySort } = require('./list-query');
const CFG = { columns: { name: 'transfer_sections.name', start: 'sr.name', end: 'er.name' }, sortable: ['name', 'start', 'end'], filterable: { name: ['contains'] }, searchable: ['transfer_sections.name'], defaultSort: 'name' };
class R extends BaseRepository {
  constructor() { super('transfer_sections', { softDelete: true, timestamps: true }); }
  base() { return this.qb().leftJoin('regions as sr', 'sr.id', 'transfer_sections.start_region_id').leftJoin('regions as er', 'er.id', 'transfer_sections.end_region_id').where('transfer_sections.is_active', 1); }
  async search(params) { const qb = this.base(); applyFiltersAndSearch(qb, params, CFG); const c = await qb.clone().clearSelect().clearOrder().count({ n: '*' }).first(); qb.select('transfer_sections.*', 'sr.name as start_region_name', 'er.name as end_region_name'); applySort(qb, params, CFG); qb.limit(params.limit).offset(params.offset); return { data: await qb, total: Number(c.n) }; }
}
module.exports = new R();
