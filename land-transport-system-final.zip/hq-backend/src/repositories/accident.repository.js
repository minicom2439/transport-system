const BaseRepository = require('./base.repository');
const { applyFiltersAndSearch, applySort } = require('./list-query');
const CFG = { columns: { occurred_at: 'accident_notifications.occurred_at', unit: 'u.name', unit_id: 'accident_notifications.unit_id', severity: 'sev.name' }, sortable: ['occurred_at', 'unit', 'severity'], filterable: { unit_id: ['eq'] }, searchable: ['u.name', 'v.plate_no', 'accident_notifications.location'], defaultSort: 'occurred_at' };
class R extends BaseRepository {
  constructor() { super('accident_notifications', { softDelete: false, timestamps: true }); }
  base() { return this.qb().leftJoin('units as u', 'u.id', 'accident_notifications.unit_id').leftJoin('vehicles as v', 'v.id', 'accident_notifications.vehicle_id').leftJoin('accident_severities as sev', 'sev.id', 'accident_notifications.severity_id').leftJoin('order_statuses as os', 'os.id', 'accident_notifications.status_id'); }
  async search(params, scope) { let qb = this.base(); if (typeof scope === 'function') qb = scope(qb); applyFiltersAndSearch(qb, params, CFG); const c = await qb.clone().clearSelect().clearOrder().count({ n: '*' }).first(); qb.select('accident_notifications.*', 'u.name as unit_name', 'v.plate_no as vehicle_plate', 'sev.name as severity_name', 'os.name as status_name'); applySort(qb, params, CFG); qb.limit(params.limit).offset(params.offset); return { data: await qb, total: Number(c.n) }; }
}
module.exports = new R();
