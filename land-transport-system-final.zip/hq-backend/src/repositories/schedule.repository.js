const BaseRepository = require('./base.repository');
const { applyFiltersAndSearch, applySort } = require('./list-query');
const CFG = { columns: { type: 'st.name', unit: 'u.name', unit_id: 'schedules.unit_id', park_id: 'schedules.park_id', schedule_date: 'schedules.schedule_date' }, sortable: ['type', 'unit', 'schedule_date'], filterable: { unit_id: ['eq'], park_id: ['eq'] }, searchable: ['st.name', 'u.name', 'schedules.notes'], defaultSort: 'schedule_date' };
class R extends BaseRepository {
  constructor() { super('schedules', { softDelete: false, timestamps: true }); }
  base() { return this.qb().leftJoin('schedule_types as st', 'st.id', 'schedules.schedule_type_id').leftJoin('units as u', 'u.id', 'schedules.unit_id').leftJoin('parks as p', 'p.id', 'schedules.park_id').leftJoin('routes as r', 'r.id', 'schedules.route_id'); }
  async search(params, scope) { let qb = this.base(); if (typeof scope === 'function') qb = scope(qb); applyFiltersAndSearch(qb, params, CFG); const c = await qb.clone().clearSelect().clearOrder().count({ n: '*' }).first(); qb.select('schedules.*', 'st.name as schedule_type_name', 'u.name as unit_name', 'p.name as park_name', 'r.route_no as route_no'); applySort(qb, params, CFG); qb.limit(params.limit).offset(params.offset); return { data: await qb, total: Number(c.n) }; }
}
module.exports = new R();
