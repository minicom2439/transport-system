const BaseRepository = require('./base.repository');
const { applyFiltersAndSearch, applySort } = require('./list-query');
const CFG = { columns: { title: 'command_orders.title', unit: 'u.name', unit_id: 'command_orders.target_unit_id', order_date: 'command_orders.order_date', status: 'os.code' }, sortable: ['title', 'unit', 'order_date'], filterable: { title: ['contains'], unit_id: ['eq'] }, searchable: ['command_orders.title', 'u.name'], defaultSort: 'order_date' };
class R extends BaseRepository {
  constructor() { super('command_orders', { softDelete: false, timestamps: true }); }
  base() { return this.qb().leftJoin('units as u', 'u.id', 'command_orders.target_unit_id').leftJoin('order_statuses as os', 'os.id', 'command_orders.status_id'); }
  async search(params, scope) { let qb = this.base(); if (typeof scope === 'function') qb = scope(qb); applyFiltersAndSearch(qb, params, CFG); const c = await qb.clone().clearSelect().clearOrder().count({ n: '*' }).first(); qb.select('command_orders.*', 'u.name as unit_name', 'os.name as status_name'); applySort(qb, params, CFG); qb.limit(params.limit).offset(params.offset); return { data: await qb, total: Number(c.n) }; }
}
module.exports = new R();
