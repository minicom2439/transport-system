const crypto = require('crypto');
const knex = require('../db/knex');
async function insert({ buffer, content_type, created_by }) {
  const sha256 = crypto.createHash('sha256').update(buffer).digest('hex');
  const [id] = await knex('file_blobs').insert({ sha256, byte_size: buffer.length, content_type: content_type || null, content: buffer, created_by: created_by || null });
  return { id, sha256, byte_size: buffer.length };
}
function get(id) { return knex('file_blobs').where({ id }).first(); }
module.exports = { insert, get };
