const BaseRepository = require('./base.repository');
const { applyFiltersAndSearch, applySort } = require('./list-query');
const CFG = { columns: { record_date: 'finance_records.record_date', unit: 'u.name', unit_id: 'finance_records.unit_id', category: 'fc.name', amount: 'finance_records.amount' }, sortable: ['record_date', 'unit', 'category', 'amount'], filterable: { unit_id: ['eq'] }, searchable: ['u.name', 'fc.name', 'finance_records.note'], defaultSort: 'record_date' };
class R extends BaseRepository {
  constructor() { super('finance_records', { softDelete: false, timestamps: true }); }
  base() { return this.qb().leftJoin('units as u', 'u.id', 'finance_records.unit_id').leftJoin('finance_categories as fc', 'fc.id', 'finance_records.category_id'); }
  async search(params, scope) { let qb = this.base(); if (typeof scope === 'function') qb = scope(qb); applyFiltersAndSearch(qb, params, CFG); const c = await qb.clone().clearSelect().clearOrder().count({ n: '*' }).first(); qb.select('finance_records.*', 'u.name as unit_name', 'fc.name as category_name'); applySort(qb, params, CFG); qb.limit(params.limit).offset(params.offset); return { data: await qb, total: Number(c.n) }; }
}
module.exports = new R();
