# HQ Land Transport Management System — Backend

Express + Knex backend for the HQ system. Runs **fully offline / air-gapped**.
Develops against **SQLite**; deploys against the DB team's **MySQL** with a one-line config change.

---

## Architecture (why it's structured this way)

The guiding rule: **only the repository layer touches the database.** Everything
else calls services, which call repositories. That isolation is what makes the
SQLite → MySQL switch a config change instead of a rewrite.

```
request
  → routes/         HTTP only: auth gate, permission gate, audit, call a service
    → services/     business logic, data-scope decisions, transactions
      → repositories/  the ONLY place that uses knex (the DB)
        → db/knex.js   single connection, built from knexfile + NODE_ENV
```

Supporting pieces:
- `middleware/` — `requireLogin`, `requirePermission(section, action)`, `audit`, error handling
- `services/permission.service.js` — resolves a user's permissions, data scope, and managed sections (the RBAC + scoped-manager + data-scope model)
- `db/session-store.js` — server-side sessions persisted in the DB (no external service)
- `db/schema.sqlite.sql` — the dev schema, generated from the canonical `schema.mysql.sql`

## Running it (development)

```bash
npm install --nodedir=/usr        # see "Air-gapped install" below
cp .env.example .env              # adjust SESSION_SECRET
npm run db:reset                  # build + seed the SQLite dev DB
npm start                         # http://localhost:4000
```

Seeded login: **admin / admin123** (super admin). **Change this immediately** in any real use.

### Quick check
```bash
curl localhost:4000/health
curl -c cj -X POST localhost:4000/api/auth/login -H 'Content-Type: application/json' \
  -d '{"username":"admin","password":"admin123"}'
curl -b cj localhost:4000/api/units
```

## Switching to MySQL (when the DB team delivers)

1. The DB team builds the database from `schema.mysql.sql` (the canonical schema).
2. Set in `.env`:
   ```
   NODE_ENV=production
   MYSQL_HOST=...  MYSQL_USER=...  MYSQL_PASSWORD=...  MYSQL_DATABASE=hq_transport
   ```
3. Create the `sessions` infra table once (see `init-dev-db.js` for its shape).
4. `npm start`. **No application code changes** — only `knexfile.js` selects the driver.

## Air-gapped install (important)

Native modules (`better-sqlite3`, and `mysql2`'s optional bits) compile at install
time. On a machine with **no internet**, `npm install` cannot download Node headers,
so the build fails. Two supported options:

1. **Vendor `node_modules`** — run `npm install` once on a connected build machine
   with the *same OS, architecture, and Node version*, then copy the whole
   `node_modules/` (with compiled `.node` binaries) to the air-gapped server.
   This is the standard approach and what we recommend.
2. **Build against local headers** — if the offline server has the Node dev headers
   installed (Debian/Ubuntu: the `nodejs` dev headers land in `/usr/include/node`),
   build with `npm install --nodedir=/usr`. node-gyp appends `include/node`, so the
   value is `/usr`, **not** `/usr/include/node`. (This is how this scaffold was built.)

## API surface in this scaffold

This is the **structural foundation**, not every screen. One complete vertical
slice is wired through all layers as the pattern to replicate:

| Method | Path | Permission |
|---|---|---|
| POST | `/api/auth/login` | — |
| POST | `/api/auth/logout` | — |
| GET | `/api/auth/me` | login |
| GET/POST/PUT/DELETE | `/api/units` | `land_ops_units:{view,add,edit,remove}` |
| GET/POST | `/api/vehicles` | `vehicle_admin_register:{view,add}` |
| GET | `/api/transport/stats/by-unit` | `integration_traveler_stats:view` |

List endpoints return a paginated envelope: `{ data, total, limit, offset }`. Detail/create return `{ data }`.

To add a new resource: create a repository (extend `BaseRepository`), a service,
and a route file; register the route in `routes/index.js`; and add its screen node
+ permissions in the seed/`system_sections`.

## Security model — decisions worth your confirmation

These are deliberate policy choices (not bugs). Confirm they match your intent:

1. **No data-scope rows = unrestricted.** A non-super user with roles but no
   `user_data_scopes` rows can see all units/regions allowed by their screen
   permissions (intended for HQ-wide staff). Scopes *narrow* access; their
   absence does not. If you'd rather **fail closed** (no scope = no rows),
   that's a one-line change in `permission.service.js`.
2. **Region scope is enforced even on tables without a region column.** It is
   resolved to the units in those regions, so it can't be bypassed. If a query
   exposes no column the scope can apply to, access is **denied** (fail closed).
3. **Permissions are cached on the session at login.** If an admin changes a
   user's roles/permissions, it takes effect on that user's **next login**.
   If you need immediate revocation, we can reload access per request (small
   cost) or add a "permissions version" check.

## Security notes
- Passwords hashed with bcrypt (`bcryptjs`, pure JS — no native build).
- Sessions are httpOnly cookies; `secure` is enabled automatically in production (serve over HTTPS).
- Super admin bypasses permission checks; all other users are gated by `role_permissions`.
- Every successful write is recorded in `audit_log` (who/what/when).
- Session ID is regenerated on login (anti-fixation); anonymous requests get no session.
- `/health` verifies DB connectivity; server shuts down gracefully on SIGINT/SIGTERM.
- DB constraint violations return HTTP 400 (not 500) without leaking table names.
- Delegated admin is enforced: a non-super section manager can only grant/revoke
  permissions within their managed subtree, can only assign roles whose rights are
  within that subtree, cannot create super admins or other managers, and cannot
  modify super-admin accounts. Out-of-scope permissions are preserved, not wiped.
- Self-registration (`POST /api/auth/register`) creates a PENDING request, not a
  usable account; pending users cannot log in. A super admin (or holder of the
  Account Requests permission) approves to create the active account.

## Single-server production deploy (one process on the isolated LAN)

The backend can serve the built frontend so there's just one process to run.

1. Build the frontend:  `cd ../frontend && npm install && npm run build`
2. Put the build where the server can find it (either option):
   - copy it in:  `cp -r ../frontend/dist ./public`   (default location), or
   - point at it: set `CLIENT_DIST=/abs/path/to/frontend/dist`
3. Backend `.env`: set `NODE_ENV=production`, `SERVE_CLIENT=true`,
   `SESSION_SECRET=<long random>`, the `MYSQL_*` values, and
   `COOKIE_SECURE=false` if you serve over plain HTTP on the LAN.
4. Install and run:  `npm install --omit=dev` then `npm start`.

Now `http://<host>:<PORT>/` serves the UI and `/api/*` serves the API from the
same origin (so the session cookie just works — no proxy or CORS needed).

Node: pinned to 18–22 (see `.nvmrc` = 22). The only native dependency
(better-sqlite3) is **development only**; production uses mysql2 (pure JS), so an
air-gapped production install has no native build step.
