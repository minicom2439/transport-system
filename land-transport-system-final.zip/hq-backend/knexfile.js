// knexfile.js
// The ENTIRE difference between the development stand-in and the final
// MySQL database lives here. The application code never changes.
require('dotenv').config();

const path = require('path');

module.exports = {
  development: {
    client: 'better-sqlite3',
    connection: {
      filename: process.env.SQLITE_FILE || './dev.db',
    },
    useNullAsDefault: true,
    // Enforce foreign keys on every SQLite connection.
    pool: {
      afterCreate: (conn, done) => {
        conn.pragma('foreign_keys = ON');
        done(null, conn);
      },
    },
  },

  production: {
    client: 'mysql2',
    connection: {
      host: process.env.MYSQL_HOST || '127.0.0.1',
      port: Number(process.env.MYSQL_PORT) || 3306,
      user: process.env.MYSQL_USER,
      password: process.env.MYSQL_PASSWORD,
      database: process.env.MYSQL_DATABASE,
      charset: 'utf8mb4',
      timezone: 'Z',
      decimalNumbers: true, // return DECIMAL as JS numbers (matches SQLite dev)
    },
    pool: { min: 2, max: 20 },
  },
};
