# Land Transport Management System

Two web applications that share one database:

- **HQ Transport** — the headquarters oversight system. Issues directives, reviews
  reports and statistics across all subordinate units, manages reference data.
- **Unit Operations** — the subordinate-unit operational system. Daily data entry,
  transport planning, employee/attendance, payments, reservations, file exchange,
  and receiving/responding to HQ directives.

Both run entirely on a local network with **no internet connection** required.

---

## At a glance

| | HQ Transport | Unit Operations |
|---|---|---|
| Backend | `hq-backend/` (Node + Express) | `unit-backend/` (Node + Express) |
| Frontend | `hq-frontend/` (React + Vite) | `unit-frontend/` (React + Vite) |
| `SYSTEM_CODE` | `hq` | `unit` |
| Suggested port | 4000 | 4001 |

Both backends connect to **one shared MariaDB/MySQL database** (default port 3306).
The database schema is the single file **`schema.mysql.sql`**.

## Technology

- **Frontend:** React 18 + Vite 5 (plain JavaScript, plain CSS with design tokens).
- **Backend:** Node.js 20/22 + Express 4 + Knex 3, sessions stored in the database.
- **Database:** MariaDB 10.4+ (e.g. via XAMPP) or MySQL 5.7/8.0. A SQLite stand-in
  is used only for local development.
- **No external services:** no CDNs, no web fonts, no map tiles, no cloud storage.
  Uploaded files are stored as bytes inside the shared database.

## Repository layout

```
.
├── README.md                ← this file
├── DEPLOYMENT_GUIDE.md      ← how to install and run (start here)
├── ARCHITECTURE.md          ← how the system is built (for developers)
├── schema.mysql.sql         ← the shared database schema (import once)
├── hq-backend/              ← HQ API server
├── hq-frontend/             ← HQ web client
├── unit-backend/            ← Unit Operations API server
└── unit-frontend/           ← Unit Operations web client
```

## Quick start

See **`DEPLOYMENT_GUIDE.md`** for the full step-by-step. In short: install Node.js
and XAMPP, create the shared database and import `schema.mysql.sql`, configure each
backend's `.env`, install dependencies, seed the database, build the two frontends,
then start the two backends.

## Default login

After seeding, sign in with the super-administrator account:

- **Username:** `admin`
- **Password:** `admin123`

Change this password immediately after first login. Additional sample accounts are
created for demonstration with the password `test123` (see the deployment guide).

## Requirements summary

- **Node.js 22 LTS** (supported range: 18 up to, but not including, 23) + npm.
- **XAMPP 8.2.12** (bundles **MariaDB 10.4.32**) — only the MariaDB component is used.
- A modern web browser (Chrome, Edge, or Firefox).
- For an air-gapped machine: the dependencies must be installed from a vendored
  `node_modules` bundle or a local npm mirror (see the deployment guide).
